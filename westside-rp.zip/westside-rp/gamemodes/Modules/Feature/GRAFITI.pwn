#define MAX_GRAFFITI_POINTS         200

enum graffitiData {
	graffitiID,
	graffitiExists,
	Float:graffitiPos[4],
	graffitiIcon,
	graffitiObject,
	graffitiColor,
	graffitiText[64]
};
new GraffitiData[MAX_GRAFFITI_POINTS][graffitiData];

Graffiti_Refresh(id)
{
    if (id != -1 && GraffitiData[id][graffitiExists])
    {
        if (IsValidDynamicMapIcon(GraffitiData[id][graffitiIcon]))
            DestroyDynamicMapIcon(GraffitiData[id][graffitiIcon]);

        if (IsValidDynamicObject(GraffitiData[id][graffitiObject]))
            DestroyDynamicObject(GraffitiData[id][graffitiObject]);

        GraffitiData[id][graffitiObject] = CreateDynamicObject(19482, GraffitiData[id][graffitiPos][0], GraffitiData[id][graffitiPos][1], GraffitiData[id][graffitiPos][2], 0.0, 0.0, GraffitiData[id][graffitiPos][3]);
        SetDynamicObjectMaterial(GraffitiData[id][graffitiObject], 0, 0, "none", "none", 0);
        SetDynamicObjectMaterialText(GraffitiData[id][graffitiObject], 0, GraffitiData[id][graffitiText], OBJECT_MATERIAL_SIZE_256x128, "Diploma", 24, 1, GraffitiData[id][graffitiColor], 0, 0);
    }
    return 1;
}

IsSprayingInProgress(id)
{
    foreach (new i : Player)
    {
        if (pData[i][pGraffiti] == id && IsPlayerInRangeOfPoint(i, 5.0, GraffitiData[id][graffitiPos][0], GraffitiData[id][graffitiPos][1], GraffitiData[id][graffitiPos][2]))
            return 1;
    }
    return 0;
}

Graffiti_Nearest(playerid)
{
    for (new i = 0; i < MAX_GRAFFITI_POINTS; i++)
        if (GraffitiData[i][graffitiExists] && IsPlayerInRangeOfPoint(playerid, 5.0, GraffitiData[i][graffitiPos][0], GraffitiData[i][graffitiPos][1], GraffitiData[i][graffitiPos][2]))
            return i;
    return -1;
}

Graffiti_Delete(id)
{
    if (id != -1 && GraffitiData[id][graffitiExists])
    {
        if (IsValidDynamicMapIcon(GraffitiData[id][graffitiIcon]))
            DestroyDynamicMapIcon(GraffitiData[id][graffitiIcon]);

        if (IsValidDynamicObject(GraffitiData[id][graffitiObject]))
            DestroyDynamicObject(GraffitiData[id][graffitiObject]);

        new query[128];
        format(query, sizeof(query), "DELETE FROM `graffiti` WHERE `graffitiID` = '%d'", GraffitiData[id][graffitiID]);
        mysql_tquery(g_SQL, query);

        GraffitiData[id][graffitiExists] = false;
        GraffitiData[id][graffitiText][0] = 0;
        GraffitiData[id][graffitiID] = 0;
    }
    return 1;
}

Graffiti_Save(id)
{
    new escapedText[128];
    mysql_escape_string(GraffitiData[id][graffitiText], escapedText);

    new query[384];
    format(query, sizeof(query), "UPDATE `graffiti` SET `graffitiX` = '%.4f', `graffitiY` = '%.4f', `graffitiZ` = '%.4f', `graffitiAngle` = '%.4f', `graffitiColor` = '%d', `graffitiText` = '%s' WHERE `graffitiID` = '%d'",
        GraffitiData[id][graffitiPos][0],
        GraffitiData[id][graffitiPos][1],
        GraffitiData[id][graffitiPos][2],
        GraffitiData[id][graffitiPos][3],
        GraffitiData[id][graffitiColor],
        escapedText,
        GraffitiData[id][graffitiID]
    );
    return mysql_tquery(g_SQL, query);
}

Graffiti_Create(Float:x, Float:y, Float:z, Float:angle)
{
    for (new i = 0; i < MAX_GRAFFITI_POINTS; i++)
    {
        if (!GraffitiData[i][graffitiExists])
        {
            GraffitiData[i][graffitiExists] = 1;
            GraffitiData[i][graffitiPos][0] = x;
            GraffitiData[i][graffitiPos][1] = y;
            GraffitiData[i][graffitiPos][2] = z;
            GraffitiData[i][graffitiPos][3] = angle - 90.0;
            GraffitiData[i][graffitiColor] = 0xFFFFFFFF;
            format(GraffitiData[i][graffitiText], 32, "Graffiti");

            Graffiti_Refresh(i);
            mysql_tquery(g_SQL, "INSERT INTO `graffiti` (`graffitiColor`) VALUES(0)", "OnGraffitiCreated", "d", i);
            return i;
        }
    }
    return -1;
}

forward OnGraffitiCreated(id);
public OnGraffitiCreated(id)
{
    GraffitiData[id][graffitiID] = cache_insert_id();
    Graffiti_Save(id);
    return 1;
}

forward Graffiti_Load();
public Graffiti_Load()
{
    new rows, fields;
    cache_get_data(rows, fields);

    for (new i = 0; i < rows && i < MAX_GRAFFITI_POINTS; i++)
    {
        cache_get_field_content(i, "graffitiText", GraffitiData[i][graffitiText], 64);
        GraffitiData[i][graffitiExists] = 1;
        GraffitiData[i][graffitiID] = cache_get_field_content_int(i, "graffitiID");
        GraffitiData[i][graffitiPos][0] = cache_get_field_content_float(i, "graffitiX");
        GraffitiData[i][graffitiPos][1] = cache_get_field_content_float(i, "graffitiY");
        GraffitiData[i][graffitiPos][2] = cache_get_field_content_float(i, "graffitiZ");
        GraffitiData[i][graffitiPos][3] = cache_get_field_content_float(i, "graffitiAngle");
        GraffitiData[i][graffitiColor] = cache_get_field_content_int(i, "graffitiColor");

        Graffiti_Refresh(i);
    }
    return 1;
}

CMD:creategangtag(playerid, params[])
{
	static
	    id = -1,
		Float:x,
		Float:y,
		Float:z,
		Float:angle;

	if(pData[playerid][pAdmin] < 5)
			return PermissionError(playerid);

	if(GetPlayerInterior(playerid) > 0 || GetPlayerVirtualWorld(playerid) > 0)
	{
 		return SCM(playerid, COLOR_SYNTAX, "kamu hanya dapat membuat poin grafiti di luar interior.");
	}

	GetPlayerPos(playerid, x, y, z);
	GetPlayerFacingAngle(playerid, angle);

	id = Graffiti_Create(x, y, z, angle);

	if(id == -1)
	{
	    return SCM(playerid, COLOR_SYNTAX, "Server telah mencapai batas untuk poin grafiti.");
	}

	EditDynamicObject(playerid, GraffitiData[id][graffitiObject]);

	pData[playerid][pEditGraffiti] = id;
	SM(playerid, COLOR_SYNTAX, "kamu telah berhasil membuat ID grafiti: %d.", id);
	return 1;
}

CMD:editgangtag(playerid, params[])
{
	static
	    id = 0;

	if(pData[playerid][pAdmin] < 5)
			return PermissionError(playerid);

	if(sscanf(params, "d", id))
	{
	    return SCM(playerid, COLOR_LIGHTBLUE, "[USAGE]:{ffffff} /editgangtag [graffiti id]");
	}

	EditDynamicObject(playerid, GraffitiData[id][graffitiObject]);
	pData[playerid][pEditGraffiti] = id;
	SM(playerid, COLOR_SYNTAX, "kamu telah berhasil mengedit ID grafiti: %d.", id);
	return 1;
}

CMD:destroygangtag(playerid, params[])
{
	static
	    id = 0;

	if(pData[playerid][pAdmin] < 5)
			return PermissionError(playerid);

	if(sscanf(params, "d", id))
	{
	    return SCM(playerid, COLOR_LIGHTBLUE, "[USAGE]:{ffffff} /destroygraffiti [graffiti id]");
	}

	if((id < 0 || id >= MAX_GRAFFITI_POINTS) || !GraffitiData[id][graffitiExists])
	{
	    return SCM(playerid, COLOR_SYNTAX, "kamu telah menentukan ID grafiti yang tidak valid.");
	}
	Graffiti_Delete(id);
	SM(playerid, COLOR_SYNTAX, "kamu telah berhasil menghancurkan ID Graffiti: %d.", id);
	return 1;
}

CMD:gspray(playerid, params[])
{
	new id = Graffiti_Nearest(playerid);

	if (id == -1)
	    return SCM(playerid, COLOR_SYNTAX, "kamu tidak dekat dengan titik grafiti.");

	ShowPlayerDialog(playerid, DIALOG_GRAFFITICOLOR, DIALOG_STYLE_LIST, "Pilih Warna", ""WHITE"Putih\n{FF0000}Merah\n{FFFF00}Kuning\n{33CC33}Hijau\n{33CCFF}Biru Muda\n"SVRCLR"Oren\n{1394BF}Biru Tua\n{000000}Hitam", "Pilih", "Batal");
	return 1;
}
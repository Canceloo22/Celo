#include <YSI\y_hooks>

#define MAX_FLAT (30)
#define MAX_FLAT_ROOM (MAX_FLAT*20)

enum flatData {
  flatID,
  flatName[32],
  flatType,
  flatInterior,
  flatWorld,
  flatIntWorld,
  flatIntInterior,
  Float:flatPos[3],
  Float:flatIntPos[3],
  Float:flatGaragePos[3],
  STREAMER_TAG_CP:flatCPExt,
  STREAMER_TAG_CP:flatCPInt,
  STREAMER_TAG_PICKUP:flatPickup,
  STREAMER_TAG_3D_TEXT_LABEL:flatText,
  STREAMER_TAG_PICKUP:flatGaragePickup,
  STREAMER_TAG_3D_TEXT_LABEL:flatGarageText
};
new FlatData[MAX_FLAT][flatData],
  Iterator:Flat<MAX_FLAT>;

enum flatRoom {
  flatRoomID,
  flatID,
  flatRoomOwner,
  flatRoomLocked,
  flatRoomPrice,
  flatRoomSeal,
  Float:flatRoomPos[3],
  Float:flatRoomAreaPos[5],
  flatRoomWeapon[3],
  flatRoomAmmo[3],
  flatRoomDurability[3],
  flatRoomTypeAmmo[3],
  flatRoomMoney,
  flatRoomWorld,
  flatRoomInterior,
  flatRoomBuilder,
  flatRoomBuilderTime,
  flatRoomLastVisited,
  STREAMER_TAG_PICKUP:flatRoomPickup,
  STREAMER_TAG_3D_TEXT_LABEL:flatRoomText,
  STREAMER_TAG_AREA:flatRoomArea
};
new FlatRoom[MAX_FLAT_ROOM][flatRoom],
  Iterator:FlatRooms<MAX_FLAT_ROOM>;

enum
{
  FLAT_TYPE_NONE = 0,
  FLAT_TYPE_LOW,
  FLAT_TYPE_MEDIUM,
  FLAT_TYPE_HIGH
}

#define MAX_FLAT_STRUCTURE (100)
#define MAX_STATIC_STRUCTURE (50)

enum structEnum {
  structID,
  structModel,
  Float:structPos[3],
  Float:structRot[3],
  structMaterial,
  structColor,
  STREAMER_TAG_OBJECT:structObject
};
new FlatStructure[MAX_FLAT_ROOM][MAX_FLAT_STRUCTURE][structEnum],
  Iterator:FlatStructures[MAX_FLAT_ROOM]<MAX_FLAT_STRUCTURE>;

new FlatStaticStruct[MAX_FLAT_ROOM][MAX_STATIC_STRUCTURE][structEnum],
  Iterator:FlatStaticStructs[MAX_FLAT_ROOM]<MAX_STATIC_STRUCTURE>;

new ListedFlatStructures[MAX_PLAYERS][MAX_FLAT_STRUCTURE+MAX_STATIC_STRUCTURE] = {-1, ...};

enum {
  SAVE_STRUCTURE_ALL = 0,
  SAVE_STRUCTURE_MATERIAL,
  SAVE_STRUCTURE_MODEL,
  SAVE_STRUCTURE_POS
}

enum 
{
  INVALID_AREA_INDEX = 0,
  FLAT_AREA_INDEX
}

#define MAX_FLAT_FURNITURE (100)

enum flatFurniture {
  furnID,
  furnModel,
  furnName[32],
  Float:furnPos[3],
  Float:furnRot[3],
  furnMaterials[MAX_MATERIALS],
  STREAMER_TAG_OBJECT:furnObject,
  furnUnused
};
new FlatFurniture[MAX_FLAT_ROOM][MAX_FLAT_FURNITURE][flatFurniture],
  Iterator:FlatFurnitures[MAX_FLAT_ROOM]<MAX_FLAT_FURNITURE>;

new ListedFlatFurnitures[MAX_PLAYERS][MAX_FLAT_FURNITURE];

function Flat_Load() {
  new str[128];

  Iter_Init(Flat);
  if (cache_num_rows()) {
    for (new i = 0; i < cache_num_rows(); i ++) {
      Iter_Add(Flat, i);
      cache_get_value_int(i, "ID", FlatData[i][flatID]);
      cache_get_value(i, "Name", FlatData[i][flatName]);
      cache_get_value_int(i, "Type", FlatData[i][flatType]);
      cache_get_value_int(i, "World", FlatData[i][flatWorld]);
      cache_get_value_int(i, "Interior", FlatData[i][flatInterior]);
      cache_get_value_int(i, "IntWorld", FlatData[i][flatIntWorld]);
      cache_get_value_int(i, "IntInterior", FlatData[i][flatIntInterior]);

      cache_get_value(i, "Position", str);
      sscanf(str, "p<|>fff", FlatData[i][flatPos][0], FlatData[i][flatPos][1], FlatData[i][flatPos][2]);

      cache_get_value(i, "IntPosition", str);
      sscanf(str, "p<|>fff", FlatData[i][flatIntPos][0], FlatData[i][flatIntPos][1], FlatData[i][flatIntPos][2]);

      cache_get_value(i, "GaragePos", str);
      sscanf(str, "p<|>fff", FlatData[i][flatGaragePos][0], FlatData[i][flatGaragePos][1], FlatData[i][flatGaragePos][2]);

      Flat_Refresh(i);
    }
  }
  printf("*** [Database: Loaded] flat data loaded (%d count)", cache_num_rows());
  return 1;
}

function FlatRoom_Load() {
  new str[128];

  Iter_Init(FlatRooms);
  if (cache_num_rows()) {
    for (new i = 0; i < cache_num_rows(); i ++) {
      Iter_Add(FlatRooms, i);

      cache_get_value_int(i, "ID", FlatRoom[i][flatRoomID]);
      cache_get_value_int(i, "FlatID", FlatRoom[i][flatID]);
      cache_get_value_int(i, "Owner", FlatRoom[i][flatRoomOwner]);
      cache_get_value_int(i, "Locked", FlatRoom[i][flatRoomLocked]);
      cache_get_value_int(i, "Price", FlatRoom[i][flatRoomPrice]);
      cache_get_value_int(i, "World", FlatRoom[i][flatRoomWorld]);
      cache_get_value_int(i, "Interior", FlatRoom[i][flatRoomInterior]);
      cache_get_value_int(i, "Seal", FlatRoom[i][flatRoomSeal]);
      cache_get_value_int(i, "Money", FlatRoom[i][flatRoomMoney]);
      cache_get_value_int(i, "LastVisited", FlatRoom[i][flatRoomLastVisited]);
      
      cache_get_value(i, "Builder", str);
      sscanf(str, "p<|>dd", FlatRoom[i][flatRoomBuilder], FlatRoom[i][flatRoomBuilderTime]);

      cache_get_value(i, "Position", str);
      sscanf(str, "p<|>fff", FlatRoom[i][flatRoomPos][0], FlatRoom[i][flatRoomPos][1], FlatRoom[i][flatRoomPos][2]);

      cache_get_value(i, "AreaPos", str);
      sscanf(str, "p<|>fffff", FlatRoom[i][flatRoomAreaPos][0], FlatRoom[i][flatRoomAreaPos][1], FlatRoom[i][flatRoomAreaPos][2], FlatRoom[i][flatRoomAreaPos][3], FlatRoom[i][flatRoomAreaPos][4]);


      FlatRoom_Refresh(i);
      foreach (new flatroom : FlatRooms) 
      {
        mysql_tquery(g_SQL, sprintf("SELECT * FROM `flat_weapon` WHERE `flatroomid` = '%d' ORDER BY `id` DESC LIMIT 3;", FlatRoom[flatroom][flatRoomID]), "OnFlatLoadWeapon", "d", flatroom);
  
        mysql_tquery(g_SQL, sprintf("SELECT * FROM `flat_storage` WHERE `ID` = '%d';", FlatRoom[flatroom][flatRoomID]), "OnLoadFlatStorage", "d", flatroom);

        mysql_tquery(g_SQL, sprintf("SELECT * FROM `flat_furniture` WHERE `Flatid` = '%d';", FlatRoom[flatroom][flatRoomID]), "OnLoadFlatFurniture", "d", flatroom);
        
        mysql_tquery(g_SQL, sprintf("SELECT * FROM `flat_structure` WHERE `Flatid` = '%d' AND `Static`='1';", FlatRoom[flatroom][flatRoomID]), "OnLoadStaticStructure", "d", flatroom);

        mysql_tquery(g_SQL, sprintf("SELECT * FROM `flat_structure` WHERE `Flatid` = '%d' AND `Static`='0';", FlatRoom[flatroom][flatRoomID]), "OnLoadFlatStructure", "d", flatroom);

      }
    }
  }
  printf("*** [Database: Loaded] flat room data loaded (%d count)", cache_num_rows());
  return 1;
}

Flat_GetType(flatid, dest[], len = sizeof(dest)) {
  if (Iter_Contains(Flat, flatid)) {
    switch (FlatData[flatid][flatType]) {
      case FLAT_TYPE_NONE: format(dest,len,"Unknown");
      case FLAT_TYPE_LOW: format(dest,len,"Low");
      case FLAT_TYPE_MEDIUM: format(dest,len,"Medium");
      case FLAT_TYPE_HIGH: format(dest,len,"High");
    }
  }
}

Flat_GetType2(type, dest[], len = sizeof(dest)) {
  switch (type) {
    case FLAT_TYPE_NONE: format(dest,len,"Unknown");
    case FLAT_TYPE_LOW: format(dest,len,"Low");
    case FLAT_TYPE_MEDIUM: format(dest,len,"Medium");
    case FLAT_TYPE_HIGH: format(dest,len,"High");
  }
}

Flat_Refresh(flatid) {
  if (!Iter_Contains(Flat, flatid))
    return 0;
  
  new Float:PosX = FlatData[flatid][flatPos][0],
    Float:PosY = FlatData[flatid][flatPos][1],
    Float:PosZ = FlatData[flatid][flatPos][2],
    World = FlatData[flatid][flatWorld],
    Interior = FlatData[flatid][flatInterior];
  
  new Float:IntPosX = FlatData[flatid][flatIntPos][0],
    Float:IntPosY = FlatData[flatid][flatIntPos][1],
    Float:IntPosZ = FlatData[flatid][flatIntPos][2],
    IntWorld = FlatData[flatid][flatIntWorld],
    IntInterior = FlatData[flatid][flatIntInterior];
  
  new Float:garagePosX = FlatData[flatid][flatGaragePos][0],
    Float:garagePosY = FlatData[flatid][flatGaragePos][1],
    Float:garagePosZ = FlatData[flatid][flatGaragePos][2];
  
  new type[12];

  if (IsValidDynamicPickup(FlatData[flatid][flatGaragePickup])) {
    Streamer_SetFloatData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatGaragePickup], E_STREAMER_X, garagePosX);
    Streamer_SetFloatData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatGaragePickup], E_STREAMER_Y, garagePosY);
    Streamer_SetFloatData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatGaragePickup], E_STREAMER_Z, garagePosZ);
    Streamer_SetIntData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatGaragePickup], E_STREAMER_WORLD_ID, World);
    Streamer_SetIntData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatGaragePickup], E_STREAMER_INTERIOR_ID, Interior);
  } else {
    FlatData[flatid][flatGaragePickup] = CreateDynamicPickup(1239, 23, garagePosX, garagePosY, garagePosZ, World, Interior, -1, 10);
  }

  if (IsValidDynamic3DTextLabel(FlatData[flatid][flatGarageText])) {
    Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatGarageText], E_STREAMER_X, garagePosX);
    Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatGarageText], E_STREAMER_Y, garagePosY);
    Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatGarageText], E_STREAMER_Z, garagePosZ+0.5);
    Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatGarageText], E_STREAMER_DRAW_DISTANCE, 10.0);
    Streamer_SetIntData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatGarageText], E_STREAMER_TEST_LOS, 1);
    Streamer_SetIntData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatGarageText], E_STREAMER_WORLD_ID, World);
    Streamer_SetIntData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatGarageText], E_STREAMER_INTERIOR_ID, Interior);

    new string[212];
    format(string, sizeof(string), "{3BBD44}[Flat Garage ID:%d]\n"WHITE_E"Use '/storeveh' to store vehicle\nUse '/takeveh' to take vehicle",flatid);
    UpdateDynamic3DTextLabelText(FlatData[flatid][flatGarageText], COLOR_ARWIN, string);
  } else {
    new string[212];
    format(string, sizeof(string), "{3BBD44}[Flat Garage ID:%d]\n"WHITE_E"Use '/storeveh' to store vehicle\nUse '/takeveh' to take vehicle",flatid);
    FlatData[flatid][flatGarageText] = CreateDynamic3DTextLabel(string, COLOR_ARWIN, garagePosX, garagePosY, garagePosZ+0.8, 10.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1, World, Interior);
  }

  if (IsValidDynamicPickup(FlatData[flatid][flatPickup])) {
    Streamer_SetFloatData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatPickup], E_STREAMER_X, PosX);
    Streamer_SetFloatData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatPickup], E_STREAMER_Y, PosY);
    Streamer_SetFloatData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatPickup], E_STREAMER_Z, PosZ);
    Streamer_SetIntData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatPickup], E_STREAMER_WORLD_ID, World);
    Streamer_SetIntData(STREAMER_TYPE_PICKUP, FlatData[flatid][flatPickup], E_STREAMER_INTERIOR_ID, Interior);
  } else {
    FlatData[flatid][flatPickup] = CreateDynamicPickup(19130, 23, PosX, PosY, PosZ, World, Interior, -1, 10);
  }

  if (IsValidDynamicCP(FlatData[flatid][flatCPExt])) {
    Streamer_SetFloatData(STREAMER_TYPE_CP, FlatData[flatid][flatCPExt], E_STREAMER_X, PosX);
    Streamer_SetFloatData(STREAMER_TYPE_CP, FlatData[flatid][flatCPExt], E_STREAMER_Y, PosY);
    Streamer_SetFloatData(STREAMER_TYPE_CP, FlatData[flatid][flatCPExt], E_STREAMER_Z, PosZ);
    Streamer_SetFloatData(STREAMER_TYPE_CP, FlatData[flatid][flatCPExt], E_STREAMER_SIZE, 1.5);
    Streamer_SetIntData(STREAMER_TYPE_CP, FlatData[flatid][flatCPExt], E_STREAMER_WORLD_ID, World);
    Streamer_SetIntData(STREAMER_TYPE_CP, FlatData[flatid][flatCPExt], E_STREAMER_INTERIOR_ID, Interior);
  } else {
    FlatData[flatid][flatCPExt] = CreateDynamicCP(PosX, PosY, PosZ, 1.5, World, Interior, -1, 2);
  }

  if (IsValidDynamicCP(FlatData[flatid][flatCPInt])) {
    Streamer_SetFloatData(STREAMER_TYPE_CP, FlatData[flatid][flatCPInt], E_STREAMER_X, IntPosX);
    Streamer_SetFloatData(STREAMER_TYPE_CP, FlatData[flatid][flatCPInt], E_STREAMER_Y, IntPosY);
    Streamer_SetFloatData(STREAMER_TYPE_CP, FlatData[flatid][flatCPInt], E_STREAMER_Z, IntPosZ);
    Streamer_SetFloatData(STREAMER_TYPE_CP, FlatData[flatid][flatCPInt], E_STREAMER_SIZE, 1.5);
    Streamer_SetIntData(STREAMER_TYPE_CP, FlatData[flatid][flatCPInt], E_STREAMER_WORLD_ID, IntWorld);
    Streamer_SetIntData(STREAMER_TYPE_CP, FlatData[flatid][flatCPInt], E_STREAMER_INTERIOR_ID, IntInterior);
  } else {
    FlatData[flatid][flatCPInt] = CreateDynamicCP(IntPosX, IntPosY, IntPosZ, 1.5, IntWorld, IntInterior, -1, 2);
  }

  if (IsValidDynamic3DTextLabel(FlatData[flatid][flatText])) {
    Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatText], E_STREAMER_X, PosX);
    Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatText], E_STREAMER_Y, PosY);
    Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatText], E_STREAMER_Z, PosZ+0.5);
    Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatText], E_STREAMER_DRAW_DISTANCE, 10.0);
    Streamer_SetIntData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatText], E_STREAMER_TEST_LOS, 1);
    Streamer_SetIntData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatText], E_STREAMER_WORLD_ID, World);
    Streamer_SetIntData(STREAMER_TYPE_3D_TEXT_LABEL, FlatData[flatid][flatText], E_STREAMER_INTERIOR_ID, Interior);

    Flat_GetType(flatid, type);
    new string[212];
    format(string, sizeof(string), "{00FFFF}[FB:%d]\n"ARWIN_E"%s",flatid,FlatData[flatid][flatName]);
    UpdateDynamic3DTextLabelText(FlatData[flatid][flatText], COLOR_ARWIN, string);
  } else {
    Flat_GetType(flatid, type);
    new string[212];
    format(string, sizeof(string), "{00FFFF}[FB:%d]\n"ARWIN_E"%s",flatid,FlatData[flatid][flatName]);
    FlatData[flatid][flatText] = CreateDynamic3DTextLabel(string, COLOR_ARWIN, PosX, PosY, PosZ+0.10, 10.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1, World, Interior);
  }
  return 1;
}

Flat_Save(flatid) {
  if (!Iter_Contains(Flat, flatid))
    return 0;
  
  new query[1024];
  format(query,sizeof(query),"UPDATE `flat` SET `Name`='%s', `Type`='%d', `World`='%d', `Interior`='%d', `IntWorld`='%d', `IntInterior`='%d', `Position`='%.2f|%.2f|%.2f', `IntPosition`='%.2f|%.2f|%.2f', `GaragePos`='%.2f|%.2f|%.2f' WHERE `ID`='%d'",
    FlatData[flatid][flatName],
    FlatData[flatid][flatType],
    FlatData[flatid][flatWorld],
    FlatData[flatid][flatInterior],
    FlatData[flatid][flatIntWorld],
    FlatData[flatid][flatIntInterior],
    FlatData[flatid][flatPos][0],
    FlatData[flatid][flatPos][1],
    FlatData[flatid][flatPos][2],
    FlatData[flatid][flatIntPos][0],
    FlatData[flatid][flatIntPos][1],
    FlatData[flatid][flatIntPos][2],
    FlatData[flatid][flatGaragePos][0],
    FlatData[flatid][flatGaragePos][1],
    FlatData[flatid][flatGaragePos][2],
    FlatData[flatid][flatID]
  );

  return mysql_tquery(g_SQL, query);
}

function OnFlatCreated(flatid) {
  if (!Iter_Contains(Flat, flatid))
    return 0;
  
  FlatData[flatid][flatID] = cache_insert_id();
  Flat_Refresh(flatid);
  Flat_Save(flatid);
  return 1;
}

Flat_Create(name[], type, Float:x, Float:y, Float:z, world = 0, interior = 0) {
  new flatid = cellmin;

  if ((flatid = Iter_Free(Flat)) != cellmin) {
    Iter_Add(Flat, flatid);

    format(FlatData[flatid][flatName], 32, name);
    FlatData[flatid][flatType] = type;
    FlatData[flatid][flatWorld] = world;
    FlatData[flatid][flatInterior] = interior;
    FlatData[flatid][flatPos][0] = x;
    FlatData[flatid][flatPos][1] = y;
    FlatData[flatid][flatPos][2] = z;
    if(type == 1)
    {
      FlatData[flatid][flatIntPos][0] = 1434.5381;
      FlatData[flatid][flatIntPos][1] = 1560.2947;
      FlatData[flatid][flatIntPos][2] = 10.9503;
      FlatData[flatid][flatIntWorld] = flatid;
      FlatData[flatid][flatIntInterior] = 34;
    }
    else if(type == 2)
    {
      FlatData[flatid][flatIntPos][0] = 1433.0850;
      FlatData[flatid][flatIntPos][1] = 1461.1018;
      FlatData[flatid][flatIntPos][2] = 10.8403;
      FlatData[flatid][flatIntWorld] = flatid;
      FlatData[flatid][flatIntInterior] = 33;
    }
    else if(type == 3)
    {
      FlatData[flatid][flatIntPos][0] = 1761.9714;
      FlatData[flatid][flatIntPos][1] = -2511.2937;
      FlatData[flatid][flatIntPos][2] = 13.7406;
      FlatData[flatid][flatIntWorld] = flatid;
      FlatData[flatid][flatIntInterior] = 32;
    }
    new string[212];
    mysql_format(g_SQL, string, sizeof(string), "INSERT INTO `flat` (`Type`) VALUES ('%d')", FlatData[flatid][flatType]);
    mysql_tquery(g_SQL, string, "OnFlatCreated", "d", flatid);
    return flatid;
  }
  return cellmin;
}

Flat_Delete(flatid){
  if (!Iter_Contains(Flat, flatid))
    return 0;
  
  if (IsValidDynamicPickup(FlatData[flatid][flatPickup])) DestroyDynamicPickup(FlatData[flatid][flatPickup]);
  if (IsValidDynamicPickup(FlatData[flatid][flatGaragePickup])) DestroyDynamicPickup(FlatData[flatid][flatGaragePickup]);
  if (IsValidDynamic3DTextLabel(FlatData[flatid][flatText])) DestroyDynamic3DTextLabel(FlatData[flatid][flatText]);
  if (IsValidDynamic3DTextLabel(FlatData[flatid][flatGarageText])) DestroyDynamic3DTextLabel(FlatData[flatid][flatGarageText]);
  if (IsValidDynamicCP(FlatData[flatid][flatCPExt])) DestroyDynamicCP(FlatData[flatid][flatCPExt]);
  if (IsValidDynamicCP(FlatData[flatid][flatCPInt])) DestroyDynamicCP(FlatData[flatid][flatCPInt]);
  
  FlatData[flatid][flatPickup] = STREAMER_TAG_PICKUP:INVALID_STREAMER_ID;
  FlatData[flatid][flatCPExt] = STREAMER_TAG_CP:INVALID_STREAMER_ID;
  FlatData[flatid][flatCPInt] = STREAMER_TAG_CP:INVALID_STREAMER_ID;
  FlatData[flatid][flatGaragePickup] = STREAMER_TAG_PICKUP:INVALID_STREAMER_ID;
  FlatData[flatid][flatText] = STREAMER_TAG_3D_TEXT_LABEL:INVALID_STREAMER_ID;
  FlatData[flatid][flatGarageText] = Text3D:INVALID_STREAMER_ID;

  new query[128];
  mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat` WHERE `ID`='%d'", FlatData[flatid][flatID]);
  mysql_tquery(g_SQL, query);
  
  new tmp_FlatData[flatData];
  FlatData[flatid] = tmp_FlatData;

  Iter_Remove(Flat, flatid);
  return 1;
}

Flat_ReturnID(roomid) {
  foreach (new i : Flat) if (FlatData[i][flatID] == FlatRoom[roomid][flatID]) {
    return i;
  }
  return -1;
}

FlatRoom_GetCount(playerid) {
  new count = 0;
  foreach (new i : FlatRooms) if (FlatRoom_IsOwner(playerid, i)) {
    count++;
  }
  return count;
}

FlatRoom_GetMaxCount(playerid) {
  new count = (pData[playerid][pVip] > 1 && pData[playerid][pVipTime]) ? (2) : (1);
  return count;
}

FlatRoom_GetAddress(flatroom, address[], len = sizeof(address)) {
  new flatid = Flat_ReturnID(flatroom);
  if (flatid != -1) format(address, len, "%s", FlatData[flatid][flatName]);
}

FlatRoom_GetLocation(flatroom, location[], len = sizeof(location)) {
  new flatid = Flat_ReturnID(flatroom);
  if (flatid != -1) format(location, len, "%s", GetLocation(FlatData[flatid][flatPos][0], FlatData[flatid][flatPos][1], FlatData[flatid][flatPos][2]));
}

FlatRoom_CreateDoor(flatroom, bool:locked = false) {
  new modelid = (locked) ? (1536) : (1502);

  foreach (new i : FlatStaticStructs[flatroom]) if (IsValidDynamicObject(FlatStaticStruct[flatroom][i][structObject])) {
    new curModel = Streamer_GetIntData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_MODEL_ID);

    if (curModel == 1536 || curModel == 1502) {
      FlatStaticStruct[flatroom][i][structModel] = modelid;
      Streamer_SetIntData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_MODEL_ID, modelid);

      Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_X, FlatStaticStruct[flatroom][i][structPos][0]);
      Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_Y, FlatStaticStruct[flatroom][i][structPos][1]);
      Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_Z, FlatStaticStruct[flatroom][i][structPos][2]);
      Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_R_X, FlatStaticStruct[flatroom][i][structRot][0]);
      Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_R_Y, FlatStaticStruct[flatroom][i][structRot][1]);
      Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_R_Z, FlatStaticStruct[flatroom][i][structRot][2]);
      Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_STREAM_DISTANCE, 100.00);
      Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_DRAW_DISTANCE, 100.00);
      Streamer_SetIntData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_WORLD_ID, FlatRoom[flatroom][flatRoomWorld]);
      Streamer_SetIntData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_INTERIOR_ID, FlatRoom[flatroom][flatRoomInterior]);

      if (FlatStaticStruct[flatroom][i][structMaterial] > 0) SetDynamicObjectMaterial(FlatStaticStruct[flatroom][i][structObject], (FlatStaticStruct[flatroom][i][structModel] == 1502) ? (1) : (0), GetTModel(FlatStaticStruct[flatroom][i][structMaterial]), GetTXDName(FlatStaticStruct[flatroom][i][structMaterial]), GetTextureName(FlatStaticStruct[flatroom][i][structMaterial]), FlatStaticStruct[flatroom][i][structColor]);
      FlatStructure_Save(flatroom, i, false, SAVE_STRUCTURE_MODEL);
    }
  }

  return 1;
}

FlatRoom_Refresh(flatroom) {
  if (!Iter_Contains(FlatRooms, flatroom))
    return 0;
  
  new Float:areaMinX = FlatRoom[flatroom][flatRoomAreaPos][0],
    Float:areaMinY = FlatRoom[flatroom][flatRoomAreaPos][1],
    Float:areaMaxX = FlatRoom[flatroom][flatRoomAreaPos][2],
    Float:areaMaxY = FlatRoom[flatroom][flatRoomAreaPos][3],
    Float:areaZ = FlatRoom[flatroom][flatRoomAreaPos][4],
    World = FlatRoom[flatroom][flatRoomWorld],
    Interior = FlatRoom[flatroom][flatRoomInterior],
    Float:PosX = FlatRoom[flatroom][flatRoomPos][0],
    Float:PosY = FlatRoom[flatroom][flatRoomPos][1],
    Float:PosZ = FlatRoom[flatroom][flatRoomPos][2];
  
  if (IsValidDynamicArea(FlatRoom[flatroom][flatRoomArea])) {
    Streamer_SetFloatData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_MIN_X, areaMinX);
    Streamer_SetFloatData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_MIN_Y, areaMinY);
    Streamer_SetFloatData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_MAX_X, areaMaxX);
    Streamer_SetFloatData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_MAX_Y, areaMaxY);

    Streamer_SetFloatData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_MIN_Z, areaZ - 1.2);
    Streamer_SetFloatData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_MAX_Z, areaZ + 4.0);
    Streamer_SetIntData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_WORLD_ID, World);
    Streamer_SetIntData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_INTERIOR_ID, Interior);

    new info[2];
    info[0] = FLAT_AREA_INDEX;
    info[1] = flatroom;
    Streamer_SetArrayData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_EXTRA_ID, info);
  } else {
    FlatRoom[flatroom][flatRoomArea] = CreateDynamicCuboid(areaMinX, areaMinY, areaZ - 1.5, areaMaxX, areaMaxY, areaZ + 4.0, World, Interior);

    new info[2];
    info[0] = FLAT_AREA_INDEX;
    info[1] = flatroom;
    Streamer_SetArrayData(STREAMER_TYPE_AREA, FlatRoom[flatroom][flatRoomArea], E_STREAMER_EXTRA_ID, info);
  }

  if (!FlatRoom[flatroom][flatRoomOwner]) {
    if (IsValidDynamicPickup(FlatRoom[flatroom][flatRoomPickup])) {
      Streamer_SetFloatData(STREAMER_TYPE_PICKUP, FlatRoom[flatroom][flatRoomPickup], E_STREAMER_X, PosX);
      Streamer_SetFloatData(STREAMER_TYPE_PICKUP, FlatRoom[flatroom][flatRoomPickup], E_STREAMER_Y, PosY);
      Streamer_SetFloatData(STREAMER_TYPE_PICKUP, FlatRoom[flatroom][flatRoomPickup], E_STREAMER_Z, PosZ);
      Streamer_SetIntData(STREAMER_TYPE_PICKUP, FlatRoom[flatroom][flatRoomPickup], E_STREAMER_WORLD_ID, World);
      Streamer_SetIntData(STREAMER_TYPE_PICKUP, FlatRoom[flatroom][flatRoomPickup], E_STREAMER_INTERIOR_ID, Interior);
    } else FlatRoom[flatroom][flatRoomPickup] = CreateDynamicPickup(1273, 23, PosX, PosY, PosZ, World, Interior, -1, 10);
    if (IsValidDynamic3DTextLabel(FlatRoom[flatroom][flatRoomText])) {
      Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatRoom[flatroom][flatRoomText], E_STREAMER_X, PosX);
      Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatRoom[flatroom][flatRoomText], E_STREAMER_Y, PosY);
      Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatRoom[flatroom][flatRoomText], E_STREAMER_Z, PosZ);
      Streamer_SetFloatData(STREAMER_TYPE_3D_TEXT_LABEL, FlatRoom[flatroom][flatRoomText], E_STREAMER_DRAW_DISTANCE, 10.0);
      Streamer_SetIntData(STREAMER_TYPE_3D_TEXT_LABEL, FlatRoom[flatroom][flatRoomText], E_STREAMER_TEST_LOS, 1);
      Streamer_SetIntData(STREAMER_TYPE_3D_TEXT_LABEL, FlatRoom[flatroom][flatRoomText], E_STREAMER_WORLD_ID, World);
      Streamer_SetIntData(STREAMER_TYPE_3D_TEXT_LABEL, FlatRoom[flatroom][flatRoomText], E_STREAMER_INTERIOR_ID, Interior);

      new string[212];
      format(string, sizeof(string), "[Flat:%d]\n"WHITE_E"Price: "GREEN_E"%s\n"WHITE_E"Use "YELLOW_E"/buyflat "WHITE_E"for buy flatroom",flatroom,FormatMoney(FlatRoom[flatroom][flatRoomPrice]));
      UpdateDynamic3DTextLabelText(FlatRoom[flatroom][flatRoomText], COLOR_ARWIN, string);
    } else {
      new string[212];
      format(string, sizeof(string), "[Flat:%d]\n"WHITE_E"Price: "GREEN_E"%s\n"WHITE_E"Use "YELLOW_E"/buyflat "WHITE_E"for buy flatroom",flatroom,FormatMoney(FlatRoom[flatroom][flatRoomPrice]));
      FlatRoom[flatroom][flatRoomText] = CreateDynamic3DTextLabel(string, COLOR_ARWIN, PosX, PosY, PosZ, 10.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1, World, Interior);
    }
    
    FlatRoom_CreateDoor(flatroom);
  } else {
    if (FlatRoom[flatroom][flatRoomSeal]) {
      FlatRoom_CreateDoor(flatroom, true);

      if (IsValidDynamic3DTextLabel(FlatRoom[flatroom][flatRoomText])){
        new string[212];
        format(string, sizeof(string), "[Flat:%d]\n"WHITE_E"This flat is sealed by "RED_E"authority",flatroom,FlatRoom[flatroom][flatRoomOwner]);
        UpdateDynamic3DTextLabelText(FlatRoom[flatroom][flatRoomText], COLOR_ARWIN, string);
      } else {
        new string[212];
        format(string, sizeof(string), "[Flat:%d]\n"WHITE_E"This flat is sealed by "RED_E"authority",flatroom,FlatRoom[flatroom][flatRoomOwner]);
        FlatRoom[flatroom][flatRoomText] = CreateDynamic3DTextLabel(string, COLOR_ARWIN, PosX, PosY, PosZ, 10.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1, World, Interior);
      }
    } else {
      if (IsValidDynamicPickup(FlatRoom[flatroom][flatRoomPickup]))
        DestroyDynamicPickup(FlatRoom[flatroom][flatRoomPickup]), FlatRoom[flatroom][flatRoomPickup] = INVALID_STREAMER_ID;
    
      if (IsValidDynamic3DTextLabel(FlatRoom[flatroom][flatRoomText]))
        DestroyDynamic3DTextLabel(FlatRoom[flatroom][flatRoomText]), FlatRoom[flatroom][flatRoomText] = Text3D:INVALID_STREAMER_ID;
    }
    if (FlatRoom[flatroom][flatRoomLocked]) {
      FlatRoom_CreateDoor(flatroom, true);
    } else {
      FlatRoom_CreateDoor(flatroom);
    }
  }
  return 1;
}

FlatRoom_Save(flatroom) {
  if (!Iter_Contains(FlatRooms, flatroom))
    return 0;
  
  new query[2000];
  format(query,sizeof(query),"UPDATE `flatroom` SET `FlatID`='%d', `Owner`='%d', `Locked`='%d', `Price`='%d', `World`='%d', `Interior`='%d', `Seal`='%d', `Money`='%d', `Position`='%.2f|%.2f|%.2f', `AreaPos`='%.2f|%.2f|%.2f|%.2f|%.2f', `Builder`='%d|%d', `LastVisited`='%d' WHERE `ID`='%d'",
    FlatRoom[flatroom][flatID],
    FlatRoom[flatroom][flatRoomOwner],
    FlatRoom[flatroom][flatRoomLocked],
    FlatRoom[flatroom][flatRoomPrice],
    FlatRoom[flatroom][flatRoomWorld],
    FlatRoom[flatroom][flatRoomInterior],
    FlatRoom[flatroom][flatRoomSeal],
    FlatRoom[flatroom][flatRoomMoney],
    FlatRoom[flatroom][flatRoomPos][0],
    FlatRoom[flatroom][flatRoomPos][1],
    FlatRoom[flatroom][flatRoomPos][2],
    FlatRoom[flatroom][flatRoomAreaPos][0],
    FlatRoom[flatroom][flatRoomAreaPos][1],
    FlatRoom[flatroom][flatRoomAreaPos][2],
    FlatRoom[flatroom][flatRoomAreaPos][3],
    FlatRoom[flatroom][flatRoomAreaPos][4],
    FlatRoom[flatroom][flatRoomBuilder],
    FlatRoom[flatroom][flatRoomBuilderTime],
    FlatRoom[flatroom][flatRoomLastVisited],
    FlatRoom[flatroom][flatRoomID]
  );

  return mysql_tquery(g_SQL, query);
}

function OnFlatRoomCreated(flatroom) {
  if (!Iter_Contains(FlatRooms, flatroom))
    return 0;
  
  FlatRoom[flatroom][flatRoomID] = cache_insert_id();
  FlatRoom_Refresh(flatroom);
  FlatRoom_Save(flatroom);
  return 1;
}

FlatRoom_Create(price, Float:x, Float:y, Float:z, world, interior, flatid) {
  new flatroom = cellmin;

  if ((flatroom = Iter_Free(FlatRooms)) != cellmin) {
    Iter_Add(FlatRooms, flatroom);

    FlatRoom[flatroom][flatID] = FlatData[flatid][flatID];
    FlatRoom[flatroom][flatRoomPrice] = price;
    FlatRoom[flatroom][flatRoomOwner] = 0;
    FlatRoom[flatroom][flatRoomSeal] = 0;
    FlatRoom[flatroom][flatRoomBuilder] = 0;
    FlatRoom[flatroom][flatRoomBuilderTime] = 0;
    FlatRoom[flatroom][flatRoomLastVisited] = gettime();
    FlatRoom[flatroom][flatRoomPos][0] = x;
    FlatRoom[flatroom][flatRoomPos][1] = y;
    FlatRoom[flatroom][flatRoomPos][2] = z;
    FlatRoom[flatroom][flatRoomWorld] = world;
    FlatRoom[flatroom][flatRoomInterior] = interior;
    FlatRoom[flatroom][flatRoomAreaPos][0] = x;
    FlatRoom[flatroom][flatRoomAreaPos][1] = y;
    FlatRoom[flatroom][flatRoomAreaPos][2] = x;
    FlatRoom[flatroom][flatRoomAreaPos][3] = y;
    FlatRoom[flatroom][flatRoomAreaPos][4] = z;

    FlatStructure_Create(flatroom, 1502, x, y, z, 0.0, 0.0, 0.0, false);
    new string[212];
    mysql_format(g_SQL, string, sizeof(string), "INSERT INTO `flatroom` (`Owner`) VALUES ('%d')", FlatRoom[flatroom][flatRoomOwner]);
    mysql_tquery(g_SQL, string, "OnFlatRoomCreated", "d", flatroom);
    return flatroom;
  }
  return cellmin;
}

FlatRoom_Delete(flatroom) {
  if(!Iter_Contains(FlatRooms, flatroom))
    return 0;
  
  if (IsValidDynamicArea(FlatRoom[flatroom][flatRoomArea]))
    DestroyDynamicArea(FlatRoom[flatroom][flatRoomArea]);

  if (IsValidDynamicPickup(FlatRoom[flatroom][flatRoomPickup]))
    DestroyDynamicPickup(FlatRoom[flatroom][flatRoomPickup]);
  
  if (IsValidDynamic3DTextLabel(FlatRoom[flatroom][flatRoomText]))
    DestroyDynamic3DTextLabel(FlatRoom[flatroom][flatRoomText]);
  
  FlatRoom[flatroom][flatRoomArea] = STREAMER_TAG_AREA:INVALID_STREAMER_ID;
  FlatRoom[flatroom][flatRoomPickup] = STREAMER_TAG_PICKUP:INVALID_STREAMER_ID;
  FlatRoom[flatroom][flatRoomText] = STREAMER_TAG_3D_TEXT_LABEL:INVALID_STREAMER_ID;

  Flat_RemoveAllItems(flatroom);
  new query[128];
  mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flatroom` WHERE `ID`='%d'", FlatRoom[flatroom][flatRoomID]);
  mysql_tquery(g_SQL, query);
  FlatStructure_DeleteAll(flatroom, false);
  FlatStructure_DeleteAll(flatroom, true);
  FlatFurniture_DeleteAll(flatroom);

  new tmp_FlatRoom[flatRoom];
  FlatRoom[flatroom] = tmp_FlatRoom;
  Iter_Remove(FlatRooms, flatroom);
  return 1;
}

FlatRoom_Inside(playerid) {
  foreach (new flatroom : FlatRooms) if (IsPlayerInDynamicArea(playerid, FlatRoom[flatroom][flatRoomArea]) && GetPlayerVirtualWorld(playerid) == FlatRoom[flatroom][flatRoomWorld] && GetPlayerInterior(playerid) == FlatRoom[flatroom][flatRoomInterior]) {
    return flatroom;
  }
  return -1;
}

FlatRoom_Nearest(playerid) {
  foreach (new flatroom : FlatRooms) if (IsPlayerInRangeOfPoint(playerid,3.0,FlatRoom[flatroom][flatRoomPos][0],FlatRoom[flatroom][flatRoomPos][1],FlatRoom[flatroom][flatRoomPos][2]) && GetPlayerVirtualWorld(playerid) == FlatRoom[flatroom][flatRoomWorld] && GetPlayerInterior(playerid) == FlatRoom[flatroom][flatRoomInterior]) {
    return flatroom;
  }
  return -1;
}

FlatRoom_IsOwner(playerid, flatroom) {
  if (!Iter_Contains(FlatRooms, flatroom))
    return 0;
  
  if(pData[playerid][pID] == -1)
    return 0;
  
  if (FlatRoom[flatroom][flatRoomOwner] != 0 && FlatRoom[flatroom][flatRoomOwner] == pData[playerid][pID])
    return 1;
  
  return 0;
}

FlatRoom_IsBuilder(playerid, flatroom) {
  if (!Iter_Contains(FlatRooms, flatroom))
    return 0;
  
  if(pData[playerid][pID] == -1)
    return 0;
  
  if (FlatRoom[flatroom][flatRoomBuilder] != 0 && FlatRoom[flatroom][flatRoomBuilder] == pData[playerid][pID])
    return 1;
  
  return 0;
}

FlatRoom_GetItemsMax(flatroom) {
  new flatBase = Flat_ReturnID(flatroom), maxItems = 0;

  switch (FlatData[flatBase][flatType]) {
    case FLAT_TYPE_NONE: maxItems = 0;
    case FLAT_TYPE_LOW: maxItems = 50;
    case FLAT_TYPE_MEDIUM: maxItems = 80;
    case FLAT_TYPE_HIGH: maxItems = 100;
  }

  return maxItems;
}

// Admin Commands
new testZone[MAX_FLAT_ROOM] = {-1, ...},
  editDoorFlat[MAX_PLAYERS] = {-1, ...};

static GetFreeZone() {
  for (new i = 0; i < MAX_FLAT_ROOM; i++) {
    if (testZone[i] == -1) {
      return i;
    }
  }
  return -1;
}

SSCANF:FlatMenu(string[]) {
  if (!strcmp(string, "create", true)) return 1;
  else if (!strcmp(string, "type", true)) return 2;
  else if (!strcmp(string, "name", true)) return 3;
  else if (!strcmp(string, "location", true)) return 4;
  else if (!strcmp(string, "interior", true)) return 5;
  else if (!strcmp(string, "goto", true)) return 6;
  else if (!strcmp(string, "garagepos", true)) return 7;
  else if (!strcmp(string, "delete", true)) return 8;
  return 0;
}

CMD:flat(playerid, params[]) {
  if (pData[playerid][pAdmin] < 5)
    return PermissionError(playerid);

  new menus, extendstr[128];
  if (sscanf(params, "k<FlatMenu>S()[128]", menus, extendstr)) {
    Usage(playerid, "/flat [menu]");
    SendClientMessage(playerid, COLOR_YELLOW, "[MENUS]: "WHITE_E"create, delete, type, name, location, interior, goto, garagepos");
    return 1;
  }

  switch (menus) {
    case 1: { // Create
      new name[32], type;
      if (sscanf(extendstr, "ds[32]", type, name))
        return Usage(playerid, "/flat create [type] [name]");
      
      new Float:position[3];
      GetPlayerPos(playerid, position[0], position[1], position[2]);

      new flatid = Flat_Create(name, type, position[0], position[1], position[2], GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid));
      
      if (flatid == cellmin)
        return Error(playerid, "Cannot create more flat!");
      
      SendCustomMessage(playerid, "FLAT","You've created flat ID: "YELLOW_E"%d", flatid);
    }
    case 2: { // Type
      new flatid, type;
      if (sscanf(extendstr, "dd", flatid, type))
        return Usage(playerid, "/flat type [flat id] [type]"), SendClientMessage(playerid, COLOR_YELLOW, "[TYPES]: "WHITE_E"1 = low, 2 = medium, 3 = high");
      
      if (!Iter_Contains(Flat, flatid))
        return Error(playerid, "Invalid flat ID");
      
      new typeName[12];
      FlatData[flatid][flatType] = type;
      Flat_GetType(flatid, typeName);
      Flat_Refresh(flatid);
      Flat_Save(flatid);

      SendCustomMessage(playerid, "FLAT", "You've changed type of flat ID: "YELLOW_E"%d "WHITE_E"to "YELLOW_E"%s", flatid, typeName);
    }
    case 3: { // Name
      new flatid, name[32];
      if (sscanf(extendstr, "ds[32]", flatid, name))
        return Usage(playerid, "/flat name [flat id] [flat name]");
      
      if (!Iter_Contains(Flat, flatid))
        return Error(playerid, "Invalid flat ID");
      
      if (strlen(name) > 32)
        return Error(playerid, "Maximum character name is 32 characters");
      
      format(FlatData[flatid][flatName], 32, name);
      Flat_Refresh(flatid);
      Flat_Save(flatid);

      SendCustomMessage(playerid, "FLAT","You've changed name of flat ID: "YELLOW_E"%d "WHITE_E"to "YELLOW_E"%s", flatid, FlatData[flatid][flatName]);
    }
    case 4: { // location
      new flatid;
      if (sscanf(extendstr, "d", flatid))
        return Usage(playerid, "/flat location [flat id]");
      
      if (!Iter_Contains(Flat, flatid))
        return Error(playerid, "Invalid flat ID");
      
      new Float:playerPos[3];
      GetPlayerPos(playerid, playerPos[0], playerPos[1], playerPos[2]);

      FlatData[flatid][flatPos][0] = playerPos[0];
      FlatData[flatid][flatPos][1] = playerPos[1];
      FlatData[flatid][flatPos][2] = playerPos[2];
      FlatData[flatid][flatWorld] = GetPlayerVirtualWorld(playerid);
      FlatData[flatid][flatInterior] = GetPlayerInterior(playerid);
      Flat_Refresh(flatid);
      Flat_Save(flatid);

      SendCustomMessage(playerid, "FLAT", "You've changed location of flat ID: "YELLOW_E"%d "WHITE_E"to your current location", flatid);
    }
    case 5: { // interior
      new flatid;
      if (sscanf(extendstr, "d", flatid))
        return Usage(playerid, "/flat interior [flat id]");
      
      if (!Iter_Contains(Flat, flatid))
        return Error(playerid, "Invalid flat ID");
      
      new Float:playerPos[3];
      GetPlayerPos(playerid, playerPos[0], playerPos[1], playerPos[2]);

      FlatData[flatid][flatIntPos][0] = playerPos[0];
      FlatData[flatid][flatIntPos][1] = playerPos[1];
      FlatData[flatid][flatIntPos][2] = playerPos[2];
      FlatData[flatid][flatIntWorld] = GetPlayerVirtualWorld(playerid);
      FlatData[flatid][flatIntInterior] = GetPlayerInterior(playerid);
      Flat_Refresh(flatid);
      Flat_Save(flatid);

      SendCustomMessage(playerid, "FLAT", "You've changed interior of flat ID: "YELLOW_E"%d "WHITE_E"to your current interior", flatid);
    }
    case 6: { // goto
      new flatid;
      if (sscanf(extendstr, "d", flatid))
        return Usage(playerid, "/flat goto [flat id]");
      
      if (!Iter_Contains(Flat, flatid))
        return Error(playerid, "Invalid flat ID");
      
      SetPlayerPos(playerid, FlatData[flatid][flatPos][0],FlatData[flatid][flatPos][1],FlatData[flatid][flatPos][2]);
      SetPlayerVirtualWorld(playerid, FlatData[flatid][flatWorld]);
      SetPlayerInterior(playerid, FlatData[flatid][flatInterior]);

      SendCustomMessage(playerid, "FLAT", "You've been teleported to flat ID: "YELLOW_E"%d", flatid);
    }
    case 7: { // garagepos
      new flatid;
      if (sscanf(extendstr, "d", flatid))
        return Usage(playerid, "/flat garagepos [flat id]");
      
      if (!Iter_Contains(Flat, flatid))
        return Error(playerid, "Invalid flat ID");
      
      new Float:gPos[3];
      GetPlayerPos(playerid, gPos[0], gPos[1], gPos[2]);
      FlatData[flatid][flatGaragePos][0] = gPos[0];
      FlatData[flatid][flatGaragePos][1] = gPos[1];
      FlatData[flatid][flatGaragePos][2] = gPos[2];
      Flat_Refresh(flatid);
      Flat_Save(flatid);

      SendCustomMessage(playerid, "FLAT", "You've changed garage position of flat ID: "YELLOW_E"%d", flatid);
    }
    case 8: { // delete
      new flatid;
      if (sscanf(extendstr, "d", flatid))
        return Usage(playerid, "/flat delete [flat id]");
      
      if (!Iter_Contains(Flat, flatid))
        return Error(playerid, "Invalid flat ID");
      
      if (Flat_Delete(flatid)){
        foreach (new flatroom : FlatRooms) if (FlatRoom[flatroom][flatID] == FlatData[flatid][flatID]) {
          FlatRoom_Delete(flatroom);
        }
        SendCustomMessage(playerid, "FLAT","You've deleted flat ID: "YELLOW_E"%d", flatid);
      } else return Error(playerid, "Unable to delete flat ID: "YELLOW_E"%d", flatid);
    }
    default: {
      Usage(playerid, "/flat [menu]");
      SendClientMessage(playerid, COLOR_YELLOW, "[MENUS]: "WHITE_E"create, delete, type, name, location, interior, goto, garagepos");
      return 1;
    }
  }
  return 1;
}

SSCANF:FlatRoomMenu(string[]) {
  if (!strcmp(string,"create",true)) return 1;
  else if (!strcmp(string,"delete",true)) return 2;
  else if (!strcmp(string,"editdoor",true)) return 3;
  else if (!strcmp(string,"areapos",true)) return 4;
  else if (!strcmp(string,"price",true)) return 5;
  else if (!strcmp(string,"location",true)) return 6;
  else if (!strcmp(string,"resetowner",true)) return 7;
  else if (!strcmp(string,"gangzone",true)) return 8;
  else if (!strcmp(string,"structure",true)) return 9;
  else if (!strcmp(string,"editstructure",true)) return 10;
  else if (!strcmp(string,"createinterior",true)) return 11;
  else if (!strcmp(string,"goto",true)) return 12;
  return 0;
}

CMD:flatroommenu(playerid, params[]) {
  if (pData[playerid][pAdmin] < 5)
    return PermissionError(playerid);
  
  new menus, extendstr[128];
  if (sscanf(params,"k<FlatRoomMenu>S()[128]",menus,extendstr)) {
    Usage(playerid, "/flatroommenu [menu]");
    SendClientMessage(playerid, COLOR_YELLOW, "[MENUS]: "WHITE_E"create, delete, editdoor, areapos, price, location, resetowner, structure, editstructure, createinterior, goto");
    return 1;
  }

  switch (menus) {
    case 1: { // create
      new price, flatid = pData[playerid][pInFlat];
      if (sscanf(extendstr,"d",price))
        return Usage(playerid, "/flatroommenu create [price]");
      
      if (price < 1)
        return Error(playerid, "Price cannot go below 1");
      
      if (flatid == -1)
        return Error(playerid, "You're not on inside flat");
      
      new Float:pos[3];
      GetPlayerPos(playerid, pos[0], pos[1], pos[2]);

      new flatroom = FlatRoom_Create(price, pos[0], pos[1], pos[2], GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid), flatid);

      if (flatroom == cellmin)
        return Error(playerid, "Cannot create more flat room");
      
      SendCustomMessage(playerid,"FLATROOM","You've created flat room ID: "YELLOW_E"%d", flatroom);
    }
    case 2: { // delete
      new flatroom;
      if (sscanf(extendstr, "d", flatroom))
        return Usage(playerid, "/flatroommenu delete [flatroom id]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      if (FlatRoom_Delete(flatroom))
        SendCustomMessage(playerid,"FLATROOM","You've deleted flat room ID: "YELLOW_E"%d", flatroom);
      else
        return Error(playerid, "Unable to delete flat room");
    }
    case 3: { // editdoor
      new flatroom;
      if (sscanf(extendstr, "d", flatroom))
        return Usage(playerid, "/flatroommenu editdoor [flatroom id]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      foreach (new i : FlatStaticStructs[flatroom]) if (IsValidDynamicObject(FlatStaticStruct[flatroom][i][structObject])) {
        new model = Streamer_GetIntData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_MODEL_ID);

        if (model == 1502 || model == 19430) {
          editDoorFlat[playerid] = flatroom;
          pData[playerid][pEditStaticStructure] = i;
          EditDynamicObject(playerid, FlatStaticStruct[flatroom][i][structObject]);
          SendCustomMessage(playerid, "FLATROOM","You're now editing flat room door ID: "YELLOW_E"%d", flatroom);
          break;
        }
      }
    }
    case 4: { // areapos
      new flatroom, Float:minPos[2], Float:maxPos[2], Float:height;
      if (sscanf(extendstr, "dfffff", flatroom, minPos[0], minPos[1], maxPos[0], maxPos[1], height))
        return Usage(playerid, "/flatroommenu areapos [flatroom id] [minx/barat] [miny/selatan] [maxx/timur] [maxy/utara] [z/tinggi]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");

      FlatRoom[flatroom][flatRoomAreaPos][0] = minPos[0];
      FlatRoom[flatroom][flatRoomAreaPos][1] = minPos[1];
      FlatRoom[flatroom][flatRoomAreaPos][2] = maxPos[0];
      FlatRoom[flatroom][flatRoomAreaPos][3] = maxPos[1];
      FlatRoom[flatroom][flatRoomAreaPos][4] = height;

      FlatRoom_Refresh(flatroom);
      FlatRoom_Save(flatroom);

      SendCustomMessage(playerid, "FLATROOM","You've set flat room ID: "YELLOW_E"%d"WHITE_E" area pos to: "YELLOW_E"%.2f, %.2f, %.2f, %.2f", flatroom, minPos[0], minPos[1], maxPos[0], maxPos[1]);
    }
    case 5: { // price
      new flatroom, price;
      if (sscanf(extendstr, "dd", flatroom, price))
        return Usage(playerid, "/flatroommenu price [flatroom id] [price]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      if (price < 1)
        return Error(playerid, "Price cannot go below 1");
      
      FlatRoom[flatroom][flatRoomPrice] = price;
      FlatRoom_Refresh(flatroom);
      FlatRoom_Save(flatroom);

      SendCustomMessage(playerid,"FLATROOM","You've set new price of flat room ID: "YELLOW_E"%d "WHITE_E"to "GREEN_E"%s",flatroom,FormatMoney(FlatRoom[flatroom][flatRoomPrice]));
    }
    case 6: { // location
      new flatroom;
      if (sscanf(extendstr, "d", flatroom))
        return Usage(playerid, "/flatroommenu location [flatroom id]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      new Float:fPos[3];
      GetPlayerPos(playerid, fPos[0], fPos[1], fPos[2]);
      FlatRoom[flatroom][flatRoomPos][0] = fPos[0];
      FlatRoom[flatroom][flatRoomPos][1] = fPos[1];
      FlatRoom[flatroom][flatRoomPos][2] = fPos[2];
      FlatRoom[flatroom][flatRoomWorld] = GetPlayerVirtualWorld(playerid);
      FlatRoom[flatroom][flatRoomInterior] = GetPlayerInterior(playerid);

      foreach (new i : FlatStaticStructs[flatroom]) if (IsValidDynamicObject(FlatStaticStruct[flatroom][i][structObject])) {
        new curModel = Streamer_GetIntData(STREAMER_TYPE_OBJECT, FlatStaticStruct[flatroom][i][structObject], E_STREAMER_MODEL_ID);

        if (curModel == 1536 || curModel == 1502) {
          FlatStaticStruct[flatroom][i][structPos][0] = fPos[0];
          FlatStaticStruct[flatroom][i][structPos][1] = fPos[1];
          FlatStaticStruct[flatroom][i][structPos][2] = fPos[2];
          FlatStructure_Refresh(flatroom, i, false);
          FlatStructure_Save(flatroom, i, false, SAVE_STRUCTURE_POS);
        }
      }

      FlatRoom_Refresh(flatroom);
      FlatRoom_Save(flatroom);

      SendCustomMessage(playerid,"FLATROOM","You've changed location of flat room ID: "YELLOW_E"%d", flatroom);
    }
    case 7: { // resetowner
      new flatroom;
      if (sscanf(extendstr, "d", flatroom))
        return Usage(playerid, "/flatroommenu resetowner [flatroom id]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      FlatRoom[flatroom][flatRoomOwner] = 0;
      FlatRoom_Refresh(flatroom);
      FlatRoom_Save(flatroom);

      SendCustomMessage(playerid,"FLATROOM","You've reset owner of flat room ID: "YELLOW_E"%d", flatroom);
    }
    case 8: { // gangzone
      new flatroom;
      if (sscanf(extendstr, "d", flatroom))
        return Usage(playerid, "/flatroommenu gangzone [flatroom id]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      new gangID = GetFreeZone();
      if (gangID == -1)
        return Error(playerid, "No free gang zones available");
      
      testZone[gangID] = GangZoneCreate(FlatRoom[flatroom][flatRoomAreaPos][0], FlatRoom[flatroom][flatRoomAreaPos][1], FlatRoom[flatroom][flatRoomAreaPos][2], FlatRoom[flatroom][flatRoomAreaPos][3]);
      GangZoneShowForAll(testZone[gangID], 0xFF0000FF);
      GangZoneFlashForAll(testZone[gangID], 0xFF0000FF);

      SendCustomMessage(playerid,"FLATROOM","You've created gang zone ID: "YELLOW_E"%d"WHITE_E" for flat room ID: "YELLOW_E"%d", gangID, flatroom);
    }
    case 9: { // create Structure
      new flatroom, modelid;
      if (sscanf(extendstr, "dd", flatroom, modelid))
        return Usage(playerid, "/flatroommenu structure [flatroom id] [modelid]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      static
        Float:x,
        Float:y,
        Float:z,
        Float:angle
      ;

      GetPlayerPos(playerid, z, z, z);
      GetPlayerFacingAngle(playerid, angle);

      new slot = FlatStructure_Create(flatroom, modelid, x, y, z, 0.0, 0.0, angle, false);

      if (slot == cellmin)
        return Error(playerid, "You can't create more structure in this flat");

      pData[playerid][pEditStaticStructure] = slot;
      pData[playerid][pEditFlatStructure] = flatroom;
      EditDynamicObject(playerid, FlatStaticStruct[flatroom][slot][structObject]);
    }
    case 10: { // edit Structure
      new flatroom;
      if (sscanf(extendstr, "d", flatroom))
        return Usage(playerid, "/flatroommenu editstructure [flatroom id]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      new info[256], count = 0;

      strcat(info,"Model\tDistance\n");
      foreach (new i : FlatStaticStructs[flatroom]) if (IsValidDynamicObject(FlatStaticStruct[flatroom][i][structObject])) {
        format(info, sizeof(info), "%s%d\t%.1f\n", info, FlatStaticStruct[flatroom][i][structModel], GetPlayerDistanceFromPoint(playerid, FlatStaticStruct[flatroom][i][structPos][0], FlatStaticStruct[flatroom][i][structPos][1], FlatStaticStruct[flatroom][i][structPos][2]));
        ListedFlatStructures[playerid][count++] = i;
      }

      if (count) Dialog_Show(playerid, Flat_EditStatic, DIALOG_STYLE_TABLIST_HEADERS, "Edit Static Structures", info, "Select", "Cancel");
      else Error(playerid, "There are no static structure on this flat");
    }
    case 11: { // Create Interior
      new flatroom, roomid;
      if (sscanf(extendstr, "dd", flatroom, roomid))
        return Usage(playerid, "/flatroommenu createinterior [flatroom id] [room id]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      if (roomid < 1)
        return Error(playerid, "Invalid Room ID!");
      
      new maxRoom, flatBase = Flat_ReturnID(flatroom);

      if (flatBase != -1) {
        switch (FlatData[flatBase][flatType]) {
          case FLAT_TYPE_LOW: maxRoom = 12;
          case FLAT_TYPE_MEDIUM: maxRoom = 16;
          case FLAT_TYPE_HIGH: maxRoom = 16;
        }

        if (roomid > maxRoom)
          return Error(playerid, "Invalid Room ID!");

        CreateFlatInterior(flatroom, roomid);
        SendCustomMessage(playerid, "FLAT", "You've been created flat interior for ID: "YELLOW_E"%d", flatroom);
      }
    }
    case 12: { // goto
      new flatroom;
      if (sscanf(extendstr, "d", flatroom))
        return Usage(playerid, "/flatroommenu goto [flatroom id]");
      
      if (!Iter_Contains(FlatRooms, flatroom))
        return Error(playerid, "Invalid flat room ID");
      
      SetPlayerPos(playerid, FlatRoom[flatroom][flatRoomPos][0],FlatRoom[flatroom][flatRoomPos][1],FlatRoom[flatroom][flatRoomPos][2]);
      SetPlayerVirtualWorld(playerid, FlatRoom[flatroom][flatRoomWorld]);
      SetPlayerInterior(playerid, FlatRoom[flatroom][flatRoomInterior]);

      SendCustomMessage(playerid, "FLATROOM", "You've been teleported to flatroom ID: "YELLOW_E"%d", flatroom);
    }
    default: {
      Usage(playerid, "/flatroommenu [menu]");
      SendClientMessage(playerid, COLOR_YELLOW, "[MENUS]: "WHITE_E"create, delete, editdoor, areapos, price, location, resetowner, structure, editstructure, createinterior");
      return 1;
    }
  }
  return 1;
}

// Player Commands
CMD:buyflat(playerid,params[]) {
  new flatroom = -1;
  if ((flatroom = FlatRoom_Nearest(playerid)) != -1) {
    if (!IsValidDynamicArea(FlatRoom[flatroom][flatRoomArea]))
      return Error(playerid, "This flat has no interior, please contact Head Admin");
    
    if (!pData[playerid][pCS])
      return Error(playerid, "You must have accepted character story to buying any property");

    if(PropertiResidential_CountMax(playerid) >= PropertiesResidential_Max(playerid)) return Error(playerid, "You can no longer buy a flat, your property slots are full");
  
    if (FlatRoom[flatroom][flatRoomOwner])
      return Error(playerid, "This flat is already owned by other players");
    
    if (pData[playerid][pMoney] < FlatRoom[flatroom][flatRoomPrice])
      return Error(playerid,"You don't have enough money to buy this flat");
    
    FlatRoom[flatroom][flatRoomOwner] = pData[playerid][pID];
    FlatRoom[flatroom][flatRoomSeal] = 0;
    FlatRoom[flatroom][flatRoomMoney] = 0;
    FlatRoom[flatroom][flatRoomLastVisited] = gettime();
    GivePlayerMoneyEx(playerid, -FlatRoom[flatroom][flatRoomPrice]);
    Flat_RemoveAllItems(flatroom);
    FlatFurniture_DeleteAll(flatroom);
    FlatStructure_DeleteAll(flatroom, true);

    FlatRoom_Refresh(flatroom);
    FlatRoom_Save(flatroom);
    return 1;
  }
  Error(playerid, "You're not in range of any flat");
  return 1;
}

CMD:flock(playerid) {
  new id = -1;
  if ((id = FlatRoom_Nearest(playerid)) != -1 || (id = FlatRoom_Inside(playerid)) != -1) {
    if (FlatRoom[id][flatRoomSeal])
      return Error(playerid, "This flat is sealed by the authority");

    if (!FlatRoom_IsOwner(playerid,id) && !FlatRoom_IsBuilder(playerid,id))
      return Error(playerid, "You're not the owner or builder of this flat");
    
    FlatRoom[id][flatRoomLocked] = FlatRoom[id][flatRoomLocked] ? 0 : 1;
    switch(FlatRoom[id][flatRoomLocked])
    {
      case 0:
      {
        GameTextForPlayer(playerid, "~w~Flat ~r~Unlocked",  1000, 6);
      }
      case 1:
      {
        GameTextForPlayer(playerid, "~w~Flat ~g~Locked", 1000, 6);
      }
    }
    FlatRoom_Refresh(id);
    FlatRoom_Save(id);
    return 1;
  }
  Error(playerid, "You're not in range of any flat");
  return 1;
}

CMD:flatmenu(playerid) {
  new id = -1;
  if ((id = FlatRoom_Inside(playerid)) != -1) {
    if (FlatRoom[id][flatRoomSeal])
      return Error(playerid, "This flat is sealed by the authority");

    if (!FlatRoom_IsOwner(playerid, id) && !FlatRoom_IsBuilder(playerid, id))
      return Error(playerid, "You're not the owner or builder of this flat");
    
    Dialog_Show(playerid, Dialog_FlatMenu, DIALOG_STYLE_LIST, "Flat Menu", "%s Flat\nFlat Storage\nFurnitures\nStructures\nAssign Builder", (FlatRoom[id][flatRoomLocked]) ? ("Unlock") : ("Lock"), "Select", "Cancel");
    return 1;
  }
  Error(playerid,"You're not in range of any flat");
  return 1;
}

CMD:getfreestruct(playerid, params[]) {
  if (pData[playerid][pAdmin] < 5)
    return PermissionError(playerid);
  
  new flatid, type[12];
  if (sscanf(params, "ds[12]", flatid, type))
    return Usage(playerid, "/getfreestruct [flat id] [type]");
  
  if (!strcmp(type, "static", true)) {
    if (!Iter_Contains(FlatRooms, flatid))
      return Error(playerid, "Invalid flat room ID");
    
    new freeid;

    if ((freeid = Iter_Free(FlatStaticStructs[flatid])) != cellmin) {
      SendCustomMessage(playerid, "FREEID", "Available for Flat ID: "YELLOW_E"%d "WHITE_E"Static structure ID: "YELLOW_E"%d", flatid, freeid);
    } else {
      Error(playerid, "There are no free static structures for this flat");
    }
  } else if (!strcmp(type, "custom", true)) {
    if (!Iter_Contains(FlatRooms, flatid))
      return Error(playerid, "Invalid flat room ID");
    
    new freeid;

    if ((freeid = Iter_Free(FlatStructures[flatid])) != cellmin) {
      SendCustomMessage(playerid, "FREEID", "Available for Flat ID: "YELLOW_E"%d "WHITE_E"Custom structure ID: "YELLOW_E"%d", flatid, freeid);
    } else {
      Error(playerid, "There are no free custom structures for this flat");
    }
  }
  return 1;
}

CMD:giveflat(playerid, params[])
{
    new hid, otherid;
    
    if(pData[playerid][pLevel] < 3) return Error(playerid, "Anda harus level 3 untuk bisa melalukan akses ini");
    if(!IsPlayerInRangeOfPoint(playerid, 3.0, -1872.98,2670.54,3.59)) return Error(playerid, "Anda harus berada di City Hall!");
    if(sscanf(params, "ud", otherid, hid)) return Usage(playerid, "/giveflat [playerid/name] [id flat]");
    if(hid == -1) return Error(playerid, "Invalid id");
    
    if(!IsPlayerConnected(otherid) || !NearPlayer(playerid, otherid, 4.0)) return Error(playerid, "The specified player is disconnected or not near you.");

    if(!FlatRoom_IsOwner(playerid, hid)) return Error(playerid, "You dont own this id flat.");
    if(PropertiResidential_CountMax(otherid) >= PropertiesResidential_Max(otherid)) return Error(playerid, "property slots are full");
    FlatRoom[hid][flatRoomOwner] = pData[otherid][pID];
    FlatRoom[hid][flatRoomMoney] = 0;
    FlatRoom[hid][flatRoomLastVisited] = gettime();
    Flat_RemoveAllItems(hid);

    FlatRoom_Refresh(hid);
    FlatRoom_Save(hid);
    SendCustomMessage(playerid, "FLAT", "You have successfully purchased %s's Flat", ReturnName(otherid));
    SendCustomMessage(otherid, "FLAT", "%s has successfully purchased your Flat", ReturnName(playerid));
    return 1;
}


Dialog:Dialog_FlatMenu(playerid,response,listitem,inputtext[]) {
  new flatid;

  if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
    if (response) {
      switch (listitem) {
        case 0: {
          callcmd::flock(playerid);
          callcmd::flatmenu(playerid);
        }
        case 1: {
          if (FlatRoom_IsBuilder(playerid, flatid))
            return Error(playerid, "Access denied");

          Flat_OpenStorage(playerid, flatid);
        }
        case 2: {
          if (FlatRoom_IsBuilder(playerid, flatid))
            return Error(playerid, "Access denied");

          FlatFurniture_Show(playerid, flatid);
        }
        case 3: {
          if (pData[playerid][pJob] != 9 && pData[playerid][pJob2] != 9)
            return Error(playerid, "You're not a Builder");

          Dialog_Show(playerid, Flat_Structures, DIALOG_STYLE_LIST, "Select Flat Structure", "Add structure\nMove structure\nRetexture structure\nDestroy structure\nCopy structure\nDestroy all structure\nStructure list\nMove furniture\nDestroy furniture\nStore furniture\nFurniture list", "Select", "Back");
        }
        case 4: {
          if (FlatRoom_IsBuilder(playerid, flatid))
            return Error(playerid, "Access denied");

          if (!FlatRoom[flatid][flatRoomBuilder])
            Dialog_Show(playerid, Flat_AssignBuilder, DIALOG_STYLE_INPUT, "Assign Builder", "Enter player id or name to assign", "Assign", "Back");
          else
            Dialog_Show(playerid, Flat_UnassignBuilder, DIALOG_STYLE_MSGBOX, "Unassign Builder", WHITE_E"Your flat is already assigned a Builder the contract will be expire on "GREEN_E"%s"WHITE_E", do you want to fired them?", "Yes", "Back", experieddate(FlatRoom[flatid][flatRoomBuilderTime],3));
        }
      }
    }
  }
  return 1;
}

Dialog:Flat_AssignBuilder(playerid,response,listitem,inputtext[]) {
  if (!response) callcmd::flatmenu(playerid);
  else {
    new flatid;
    if ((flatid = FlatRoom_Inside(playerid)) != -1 && FlatRoom_IsOwner(playerid, flatid)) {
      new userid;
      if (isnull(inputtext))
        return Dialog_Show(playerid, Flat_AssignBuilder, DIALOG_STYLE_INPUT, "Assign Builder", "Enter player id or name to assign", "Assign", "Back"), Error(playerid, "Invalid input!");

      if (sscanf(inputtext, "u", userid))
        return Dialog_Show(playerid, Flat_AssignBuilder, DIALOG_STYLE_INPUT, "Assign Builder", "Enter player id or name to assign", "Assign", "Back"), Error(playerid, "Invalid input!");

      if (!IsPlayerConnected(userid))
        return Error(playerid, "Invalid playerid or name!");

      if (userid == playerid)
        return Error(playerid, "Cannot assign yourself");

      if (pData[playerid][pJob] != 9 && pData[playerid][pJob2] != 9)
        return Error(playerid, "That player are not a Bulder");

      FlatRoom[flatid][flatRoomBuilder] = pData[userid][pID];
      FlatRoom[flatid][flatRoomBuilderTime] = (gettime()+((24*3600)*7));
      SendCustomMessage(playerid, "FLAT", "You've been assigned "YELLOW_E"%s "WHITE_E"as your flat builder, it will automatically fired for 7 days.", ReturnName(userid));
      SendCustomMessage(userid, "FLAT", ""YELLOW_E"%s "WHITE_E"has assigned you as flat builder.", ReturnName(playerid));
    }
  }
  return 1;
}

Dialog:Flat_UnassignBuilder(playerid,response,listitem,inputtext[]) {
  if (!response) callcmd::flatmenu(playerid);
  else {
    new flatid;
    if ((flatid = FlatRoom_Inside(playerid)) != -1 && FlatRoom_IsOwner(playerid, flatid)) {
      FlatRoom[flatid][flatRoomBuilder] = 0;
      FlatRoom[flatid][flatRoomBuilderTime] = 0;
      SendCustomMessage(playerid, "FLAT", "You've been unassigned your flat builder");
    }
  }
  return 1;
}

Dialog:Flat_EditStatic(playerid,response,listitem,inputtext[]) {
  if (response) {
    new flatid;
    if ((flatid = FlatRoom_Inside(playerid)) != -1) {
      new slot = ListedFlatStructures[playerid][listitem],
        info[512];
      
      pData[playerid][pEditFlatStructure] = flatid;
      pData[playerid][pEditStaticStructure] = slot;

      format(info, sizeof(info), "Model\t%d\n", FlatStaticStruct[flatid][slot][structModel]);
      format(info, sizeof(info), "%sPos X\t%.2f\n", info, FlatStaticStruct[flatid][slot][structPos][0]);
      format(info, sizeof(info), "%sPos Y\t%.2f\n", info, FlatStaticStruct[flatid][slot][structPos][1]);
      format(info, sizeof(info), "%sPos Z\t%.2f\n", info, FlatStaticStruct[flatid][slot][structPos][2]);
      format(info, sizeof(info), "%sRot X\t%.2f\n", info, FlatStaticStruct[flatid][slot][structRot][0]);
      format(info, sizeof(info), "%sRot Y\t%.2f\n", info, FlatStaticStruct[flatid][slot][structRot][1]);
      format(info, sizeof(info), "%sRot Z\t%.2f\n", info, FlatStaticStruct[flatid][slot][structRot][2]);
      format(info, sizeof(info), "%sOpen editor\t\n", info);
      format(info, sizeof(info), "%sDestroy\t", info);
      Dialog_Show(playerid, Flat_EditPage, DIALOG_STYLE_TABLIST, "Edit Static Flat", info, "Edit", "Close");
    }
  }
  return 1;
}

Dialog:Flat_EditPage(playerid,response,listitem,inputtext[]) {
  if (response) {
    SetPVarInt(playerid, "StaticStructUpdate", listitem);

    switch (listitem) {
      case 0: {
        Dialog_Show(playerid, Flat_StructureUpdate, DIALOG_STYLE_INPUT, "Edit Model", "Input new model id: "GREEN_E"(input below)", "Update", "Close");
      }
      case 1: {
        Dialog_Show(playerid, Flat_StructureUpdate, DIALOG_STYLE_INPUT, "Edit Pos X", "Input new Pos X: "GREEN_E"(input below)", "Update", "Close");
      }
      case 2: {
        Dialog_Show(playerid, Flat_StructureUpdate, DIALOG_STYLE_INPUT, "Edit Pos Y", "Input new Pos Y: "GREEN_E"(input below)", "Update", "Close");
      }
      case 3: {
        Dialog_Show(playerid, Flat_StructureUpdate, DIALOG_STYLE_INPUT, "Edit Pos Z", "Input new Pos Z: "GREEN_E"(input below)", "Update", "Close");
      }
      case 4: {
        Dialog_Show(playerid, Flat_StructureUpdate, DIALOG_STYLE_INPUT, "Edit Rot X", "Input new Rot X: "GREEN_E"(input below)", "Update", "Close");
      }
      case 5: {
        Dialog_Show(playerid, Flat_StructureUpdate, DIALOG_STYLE_INPUT, "Edit Rot Y", "Input new Rot Y: "GREEN_E"(input below)", "Update", "Close");
      }
      case 6: {
        Dialog_Show(playerid, Flat_StructureUpdate, DIALOG_STYLE_INPUT, "Edit Rot z", "Input new Rot z: "GREEN_E"(input below)", "Update", "Close");
      }
      case 7: {
        new flatid = pData[playerid][pEditFlatStructure],
          slot = pData[playerid][pEditStaticStructure];
        
        EditDynamicObject(playerid, FlatStaticStruct[flatid][slot][structObject]);
        SendCustomMessage(playerid, "FLAT", "You're now editing static structure "YELLOW_E"%d "WHITE_E"for flat ID: "YELLOW_E"%d", slot, flatid);
      }
      case 8: {
        new flatid = pData[playerid][pEditFlatStructure],
          slot = pData[playerid][pEditStaticStructure];
        
        SendCustomMessage(playerid, "FLAT", "You've deleted static structure "YELLOW_E"%d "WHITE_E"flat ID: "YELLOW_E"%d", slot, flatid);
        FlatStructure_Delete(flatid, slot, false);
      }
    }
  }
  return 1;
}

Dialog:Flat_StructureUpdate(playerid,response,listitem,inputtext[]) {
  if (response) {
    new index = GetPVarInt(playerid, "StaticStructUpdate"),
      flatid = pData[playerid][pEditFlatStructure],
      slot = pData[playerid][pEditStaticStructure];
    
    if (!Iter_Contains(FlatStaticStructs[flatid], slot))
      return Error(playerid, "Invalid structure ID");

    switch (index) {
      case 0: {
        new model;
        if (sscanf(inputtext, "d", model))
          return Error(playerid, "Invalid input"), DeletePVar(playerid, "StaticStructUpdate");

        FlatStaticStruct[flatid][slot][structModel] = model;
        FlatStructure_Refresh(flatid, slot, false);
        FlatStructure_Save(flatid, slot, false, SAVE_STRUCTURE_MODEL);
        SendCustomMessage(playerid, "FLAT", "You've been changed model id of static structure ID: "YELLOW_E"%d "WHITE_E"to "YELLOW_E"%d", slot, model);
        DeletePVar(playerid, "StaticStructUpdate");
      }
      case 1: {
        new Float:pos;
        if (sscanf(inputtext, "f", pos))
          return Error(playerid, "Invalid input"), DeletePVar(playerid, "StaticStructUpdate");

        FlatStaticStruct[flatid][slot][structPos][0] = pos;
        FlatStructure_Refresh(flatid, slot, false);
        FlatStructure_Save(flatid, slot, false, SAVE_STRUCTURE_POS);
        SendCustomMessage(playerid, "FLAT", "You've been changed Pos X of static structure ID: "YELLOW_E"%d "WHITE_E"to "YELLOW_E"%.2f", slot, pos);
        DeletePVar(playerid, "StaticStructUpdate");
      }
      case 2: {
        new Float:pos;
        if (sscanf(inputtext, "f", pos))
          return Error(playerid, "Invalid input"), DeletePVar(playerid, "StaticStructUpdate");

        FlatStaticStruct[flatid][slot][structPos][1] = pos;
        FlatStructure_Refresh(flatid, slot, false);
        FlatStructure_Save(flatid, slot, false, SAVE_STRUCTURE_POS);
        SendCustomMessage(playerid, "FLAT", "You've been changed Pos Y of static structure ID: "YELLOW_E"%d "WHITE_E"to "YELLOW_E"%.2f", slot, pos);
        DeletePVar(playerid, "StaticStructUpdate");
      }
      case 3: {
        new Float:pos;
        if (sscanf(inputtext, "f", pos))
          return Error(playerid, "Invalid input"), DeletePVar(playerid, "StaticStructUpdate");

        FlatStaticStruct[flatid][slot][structPos][2] = pos;
        FlatStructure_Refresh(flatid, slot, false);
        FlatStructure_Save(flatid, slot, false, SAVE_STRUCTURE_POS);
        SendCustomMessage(playerid, "FLAT", "You've been changed Pos Z of static structure ID: "YELLOW_E"%d "WHITE_E"to "YELLOW_E"%.2f", slot, pos);
        DeletePVar(playerid, "StaticStructUpdate");
      }
      case 4: {
        new Float:pos;
        if (sscanf(inputtext, "f", pos))
          return Error(playerid, "Invalid input"), DeletePVar(playerid, "StaticStructUpdate");

        FlatStaticStruct[flatid][slot][structRot][0] = pos;
        FlatStructure_Refresh(flatid, slot, false);
        FlatStructure_Save(flatid, slot, false, SAVE_STRUCTURE_POS);
        SendCustomMessage(playerid, "FLAT", "You've been changed Rot X of static structure ID: "YELLOW_E"%d "WHITE_E"to "YELLOW_E"%.2f", slot, pos);
        DeletePVar(playerid, "StaticStructUpdate");
      }
      case 5: {
        new Float:pos;
        if (sscanf(inputtext, "f", pos))
          return Error(playerid, "Invalid input"), DeletePVar(playerid, "StaticStructUpdate");

        FlatStaticStruct[flatid][slot][structRot][1] = pos;
        FlatStructure_Refresh(flatid, slot, false);
        FlatStructure_Save(flatid, slot, false, SAVE_STRUCTURE_POS);
        SendCustomMessage(playerid, "FLAT", "You've been changed Rot Y of static structure ID: "YELLOW_E"%d "WHITE_E"to "YELLOW_E"%.2f", slot, pos);
        DeletePVar(playerid, "StaticStructUpdate");
      }
      case 6: {
        new Float:pos;
        if (sscanf(inputtext, "f", pos))
          return Error(playerid, "Invalid input"), DeletePVar(playerid, "StaticStructUpdate");

        FlatStaticStruct[flatid][slot][structRot][2] = pos;
        FlatStructure_Refresh(flatid, slot, false);
        FlatStructure_Save(flatid, slot, false, SAVE_STRUCTURE_POS);
        SendCustomMessage(playerid, "FLAT", "You've been changed Rot Z of static structure ID: "YELLOW_E"%d "WHITE_E"to "YELLOW_E"%.2f", slot, pos);
        DeletePVar(playerid, "StaticStructUpdate");
      }
    }
  }
  return 1;
}

Dialog:ListedFlatFurniture(playerid, response, listitem, inputtext[]) {
  if(response) {
    new flatid = FlatRoom_Inside(playerid);

    if (flatid == -1)
      return Error(playerid, "You're not inside a flat.");
    
    if (!FlatRoom_IsOwner(playerid, flatid) && !FlatRoom_IsBuilder(playerid, flatid))
      return Error(playerid, "You're not the owner or builder of this flat");
    
    pData[playerid][pEditFurniture] = ListedFlatFurnitures[playerid][listitem];
    pData[playerid][pEditFurnFlat] = flatid;
    Dialog_Show(playerid, FlatFurnitureSelect, DIALOG_STYLE_LIST, FlatFurniture[flatid][pData[playerid][pEditFurniture]][furnName], "Edit Position\nMove to in front me\nDestroy Furniture\nStore Furniture", "Select", "Cancel");
  }
  return 1;
}

Dialog:FlatFurnitureSelect(playerid, response, listitem, inputtext[]) {
  if(response) {
    new flatid = FlatRoom_Inside(playerid);
    
    if (flatid != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
      new Float:pos[4];
      GetPlayerPos(playerid, pos[0], pos[1], pos[2]);
      GetPlayerFacingAngle(playerid, pos[3]);

      pos[0] += 1.0 * floatsin(-pos[3], degrees);
      pos[1] += 1.0 * floatcos(-pos[3], degrees);

      switch (listitem) {
        case 0: {
          new slot = pData[playerid][pEditFurniture];

          if (FlatFurniture[flatid][slot][furnUnused]) {
            FlatFurniture[flatid][slot][furnUnused] = 0;
            FlatFurniture[flatid][slot][furnPos][0] = pos[0];
            FlatFurniture[flatid][slot][furnPos][1] = pos[1];
            FlatFurniture[flatid][slot][furnPos][2] = pos[2];
            FlatFurniture[flatid][slot][furnRot][0] = 0.0;
            FlatFurniture[flatid][slot][furnRot][1] = 0.0;
            FlatFurniture[flatid][slot][furnRot][2] = pos[3];

            FlatFurniture_Refresh(slot, flatid);
          }
          EditDynamicObject(playerid, FlatFurniture[flatid][slot][furnObject]);
          SendCustomMessage(playerid, "FURNITURE", "You are now editing the position of \"%s"WHITE_E"\".", FlatFurniture[flatid][slot][furnName]);
        }
        case 1: {
          new slot = pData[playerid][pEditFurniture];

          if(FlatFurniture[flatid][slot][furnUnused])
            return Error(playerid, "Attach this furniture first by select option \"Editing Position\"");

          FlatFurniture[flatid][slot][furnUnused] = 0;
          FlatFurniture[flatid][slot][furnPos][0] = pos[0];
          FlatFurniture[flatid][slot][furnPos][1] = pos[1];
          FlatFurniture[flatid][slot][furnPos][2] = pos[2];
          FlatFurniture[flatid][slot][furnRot][0] = 0.0;
          FlatFurniture[flatid][slot][furnRot][1] = 0.0;
          FlatFurniture[flatid][slot][furnRot][2] = pos[3];

          SetDynamicObjectPos(FlatFurniture[flatid][slot][furnObject], FlatFurniture[flatid][slot][furnPos][0], FlatFurniture[flatid][slot][furnPos][1], FlatFurniture[flatid][slot][furnPos][2]);
          SetDynamicObjectRot(FlatFurniture[flatid][slot][furnObject], FlatFurniture[flatid][slot][furnRot][0], FlatFurniture[flatid][slot][furnRot][1], FlatFurniture[flatid][slot][furnRot][2]);
          FlatFurniture_Refresh(slot, flatid);
          FlatFurniture_Save(slot, flatid);
          SendCustomMessage(playerid, "FURNITURE", "Now this furniture is moved to in front you.");
        }
        case 2: {
          SendCustomMessage(playerid, "FURNITURE", "You have destroyed furniture \"%s"WHITE_E"\".", FlatFurniture[flatid][pData[playerid][pEditFurniture]][furnName]);
          FlatFurniture_Delete(pData[playerid][pEditFurniture], flatid);

          CancelEdit(playerid);
          pData[playerid][pEditFurniture] = -1;
          pData[playerid][pEditFurnFlat] = -1;
        }
        case 3: {
          new slot = pData[playerid][pEditFurniture];

          if (FlatFurniture[flatid][slot][furnUnused])
            return Error(playerid, "This furniture already stored.");
          
          FlatFurniture[flatid][slot][furnUnused] = 1;
          FlatFurniture_Refresh(slot, flatid);
          FlatFurniture_Save(slot, flatid);
          SendCustomMessage(playerid, "FURNITURE", "You have stored furniture \"%s"WHITE_E"\" into your flat.", FlatFurniture[flatid][slot][furnName]);
          pData[playerid][pEditFurniture] = -1;
          pData[playerid][pEditFurnFlat] = -1;
        }
      }
    } else {
      pData[playerid][pEditFurniture] = -1;
      pData[playerid][pEditFurnFlat] = -1;
      return 1;
    }
  } else FlatFurniture_Show(playerid, pData[playerid][pEditFurnFlat]);
  return 1;
}

// Dialogs
Dialog:FlatWeapons(playerid, response, listitem, inputtext[]) {
  new
    roomid;

  if((roomid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, roomid) || pData[playerid][pAdmin] > 5))
  {
    if(response)
    {
      if(FlatRoom[roomid][flatRoomWeapon][listitem] != 0)
      {
        if(pData[playerid][pOnDuty] > 1)
          return Error(playerid, "Duty faction tidak dapat mengambil senjata.");

        if(PlayerHasWeapon(playerid, FlatRoom[roomid][flatRoomWeapon][listitem]))
          return Error(playerid, "Kamu sudah memiliki senjata yang sama.");
        switch(FlatRoom[roomid][flatRoomTypeAmmo][listitem]) {
          case 0: {
            GivePlayerWeaponEx(playerid, FlatRoom[roomid][flatRoomWeapon][listitem], FlatRoom[roomid][flatRoomAmmo][listitem], 0);
          }
          case 1: {
            GivePlayerWeaponEx(playerid, FlatRoom[roomid][flatRoomWeapon][listitem], FlatRoom[roomid][flatRoomAmmo][listitem], 1);
          }
        }
        SendNearbyMessage(playerid, 15.0, COLOR_PURPLE, "** %s has taken a \"%s\" from their weapon storage.", ReturnName(playerid), ReturnWeaponName(FlatRoom[roomid][flatRoomWeapon][listitem]));

        new query[128];
        mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat_weapon` WHERE `flatroomid` = '%d' AND `ammo`='%d' AND `weaponid`='%d' AND `durability`='%d'", FlatRoom[roomid][flatRoomID], FlatRoom[roomid][flatRoomAmmo][listitem], FlatRoom[roomid][flatRoomWeapon][listitem], FlatRoom[roomid][flatRoomDurability][listitem]);
        mysql_tquery(g_SQL, query);
        FlatRoom[roomid][flatRoomWeapon][listitem]      = 0;
        FlatRoom[roomid][flatRoomAmmo][listitem]         = 0;
        FlatRoom[roomid][flatRoomDurability][listitem]   = 0;
        FlatRoom[roomid][flatRoomTypeAmmo][listitem]     = 0;
        
        Flat_WeaponStorage(playerid, roomid);
      }
      else
      {
        new
          weaponid = GetWeapon(playerid),
          ammo = ReturnWeaponAmmo(playerid, weaponid);

        if(pData[playerid][pOnDuty] > 1)
            return Error(playerid, "Duty faction tidak dapat menyimpan senjata.");

        if(!weaponid)
            return Error(playerid, "You are not holding any weapon!");

        FlatRoom[roomid][flatRoomWeapon][listitem] = weaponid;
        FlatRoom[roomid][flatRoomAmmo][listitem] = ammo;
        switch(PlayerGuns[playerid][g_aWeaponSlots[weaponid]][weapon_typesurplus]) {
          case 0: {
            FlatRoom[roomid][flatRoomTypeAmmo][listitem]     = 0;
          }
          case 1: {
            FlatRoom[roomid][flatRoomTypeAmmo][listitem]     = 1;
          }
        }
        new string[212];
        mysql_format(g_SQL, string, sizeof(string), "INSERT INTO `flat_weapon` (`flatroomid`, `weaponid`, `ammo`, `typeammo`) VALUES ('%d','%d','%d','%d')", FlatRoom[roomid][flatRoomID], weaponid, ammo, FlatRoom[roomid][flatRoomTypeAmmo][listitem]);
        mysql_tquery(g_SQL, string);
        
        ResetWeaponID(playerid, weaponid);
        Flat_WeaponStorage(playerid, roomid);
        
        SendNearbyMessage(playerid, 15.0, COLOR_PURPLE, "** %s has stored a \"%s\" into their weapon storage.", ReturnName(playerid), ReturnWeaponName(weaponid));
      }
    }
    else Flat_OpenStorage(playerid, roomid);
  }
  return 1;
}

// Dialog:FlatTake(playerid, response, listitem, inputtext[]) {
//   new
//     roomid,
//     string[32];

//   if((roomid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, roomid) || pData[playerid][pAdmin] > 5))
//   {
//     strunpack(string, FlatStorage[roomid][pData[playerid][pStorageItem]][rItemName]);

//     if(response)
//     {
//       new amount = strval(inputtext);

//       if(amount < 1 || amount > FlatStorage[roomid][pData[playerid][pStorageItem]][rItemQuantity])
//         return Dialog_Show(playerid, FlatTake, DIALOG_STYLE_INPUT, "Flat Take", "Item: %s (Quantity: %d)\n\nPlease enter the quantity that you wish to take for this item:", "Take", "Back", string, FlatStorage[roomid][pData[playerid][pInventoryItem]][rItemQuantity]);

//       for (new i = 0; i < sizeof(g_aInventoryItems); i ++) if(!strcmp(g_aInventoryItems[i][e_InventoryItem], string, true)) {
//         if((Inventory_Count(playerid, g_aInventoryItems[i][e_InventoryItem])+amount) > g_aInventoryItems[i][e_InventoryMax])
//           return Dialog_Show(playerid, FlatTake, DIALOG_STYLE_INPUT, "Flat Take", "Item: %s (Quantity: %d)\n\nPlease enter the quantity that you wish to take for this item:\n(You can take %d %s now!)", "Take", "Back", string, FlatStorage[roomid][pData[playerid][pInventoryItem]][rItemQuantity], (g_aInventoryItems[i][e_InventoryMax]-Inventory_Count(playerid, g_aInventoryItems[i][e_InventoryItem])), string);
//       }

//       new id = Inventory_Add(playerid, string, FlatStorage[roomid][pData[playerid][pStorageItem]][rItemModel], amount);

//       if(id == -1)
//           return Error(playerid, "You don't have any inventory slots left.");

//       Flat_RemoveItem(roomid, string, amount);
//       SendNearbyMessage(playerid, 15.0, COLOR_PURPLE, "** %s has taken a \"%s\" from their room storage.", ReturnName(playerid), string);

//       Flat_ShowItems(playerid, roomid);
//     }
//     else Flat_OpenStorage(playerid, roomid);
//   }
//   return 1;
// }

Dialog:Dialog_FlatStorage(playerid, response, listitem, inputtext[]) {
  new
    roomid = -1;

  if((roomid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, roomid) || pData[playerid][pAdmin] >= 3))
  {
    if(response)
    {
      if(listitem == 0) {
        Flat_ShowItems(playerid, roomid);
      }
      else if(listitem == 1) {
        if(pData[playerid][pLevel] < 2)
          return Error(playerid, "You're not allowed to access this storage if you're not level 2.");

        if (!pData[playerid][pCS])
          return Error(playerid, "You must have an active character story to access this option.");

        Flat_WeaponStorage(playerid, roomid);
      }
      else if(listitem == 2) {
        Dialog_Show(playerid, FlatMoney, DIALOG_STYLE_LIST, "Money Safe", "Withdraw from safe\nDeposit into safe", "Select", "Back");
      }
    }
  }
  return 1;
}

// Dialog:Dialog_FlatItems(playerid, response, listitem, inputtext[]) {
//   new
//     roomid,
//     string[64];

//   if((roomid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, roomid) || pData[playerid][pAdmin] > 5))
//   {
//     if(response)
//     {
//       if(Iter_Contains(FlatStorages[roomid], listitem))
//       {
//         pData[playerid][pStorageItem] = listitem;
//         pData[playerid][pInventoryItem] = listitem;

//         strunpack(string, FlatStorage[roomid][listitem][rItemName]);

//         format(string, sizeof(string), "%s (Quantity: %d)", string, FlatStorage[roomid][listitem][rItemQuantity]);
//         Dialog_Show(playerid, Flat_StorageOptions, DIALOG_STYLE_LIST, string, "Take Item\nStore Item", "Select", "Back");
//       }
//       else {
//         OpenInventory(playerid);

//         pData[playerid][pStorageSelect] = 5;
//       }
//     }
//     else Flat_OpenStorage(playerid, roomid);
//   }
//   return 1;
// }

// Dialog:Flat_StorageOptions(playerid, response, listitem, inputtext[]) {
//   new
//     roomid = -1,
//     itemid = -1,
//     string[32];

//   if((roomid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, roomid) || pData[playerid][pAdmin] >= 3))
//   {
//     itemid = pData[playerid][pStorageItem];

//     strunpack(string, FlatStorage[roomid][itemid][rItemName]);

//     if(response)
//     {
//       switch (listitem)
//       {
//         case 0:
//         {
//           if(FlatStorage[roomid][itemid][rItemQuantity] == 1)
//           {
//             if(!strcmp(string, "Backpack") && Inventory_HasItem(playerid, "Backpack"))
//               return Error(playerid, "You already have a backpack in your inventory.");

//             for (new i = 0; i < sizeof(g_aInventoryItems); i ++) if(!strcmp(g_aInventoryItems[i][e_InventoryItem], string, true)) {
//               if((Inventory_Count(playerid, g_aInventoryItems[i][e_InventoryItem])+1) > g_aInventoryItems[i][e_InventoryMax])
//                 return Error(playerid, "You're limited %d for %s.", g_aInventoryItems[i][e_InventoryMax], string);
//             }

//             new id = Inventory_Add(playerid, string, FlatStorage[roomid][itemid][rItemModel], 1);

//             if(id == -1)
//               return Error(playerid, "You don't have any inventory slots left.");

//             Flat_RemoveItem(roomid, string);
//             SendNearbyMessage(playerid, 15.0, COLOR_PURPLE, "** %s has taken a \"%s\" from their room storage.", ReturnName(playerid), string);

//             Flat_ShowItems(playerid, roomid);
//             Log_Write("logs/storage_log.txt", "[%s] %s has taken \"%s\" from room ID: %d.", ReturnDate(), ReturnName(playerid), string, roomid);
//           }
//           else
//           {
//             Dialog_Show(playerid, FlatTake, DIALOG_STYLE_INPUT, "Flat Take", "Item: %s (Quantity: %d)\n\nPlease enter the quantity that you wish to take for this item:", "Take", "Back", string, FlatStorage[roomid][itemid][rItemQuantity]);
//           }
//         }
//         case 1:
//         {
//           new id = Inventory_GetItemID(playerid, string);

//           if(!strcmp(string, "Backpack")) {
//             Flat_ShowItems(playerid, roomid);

//             return Error(playerid, "You can only store one backpack in your room.");
//           }
//           else if(id == -1) {
//             Flat_ShowItems(playerid, roomid);

//             return Error(playerid, "You don't have anymore of this item to store!");
//           }
//           else if(InventoryData[playerid][id][invQuantity] == 1)
//           {
//             Flat_AddItem(roomid, string, InventoryData[playerid][id][invModel]);
//             Inventory_Remove(playerid, string);

//             SendNearbyMessage(playerid, 15.0, COLOR_PURPLE, "** %s has stored a \"%s\" into their room storage.", ReturnName(playerid), string);
//             Log_Write("logs/storage_log.txt", "[%s] %s has stored \"%s\" into their room ID: %d.", ReturnDate(), ReturnName(playerid), string, roomid);
//             Flat_ShowItems(playerid, roomid);
//           }
//           else if(InventoryData[playerid][id][invQuantity] > 1) {
//             pData[playerid][pInventoryItem] = id;

//             Dialog_Show(playerid, FlatDeposit, DIALOG_STYLE_INPUT, "Flat Deposit", "Item: %s (Quantity: %d)\n\nPlease enter the quantity that you wish to store for this item:", "Store", "Back", string, InventoryData[playerid][id][invQuantity]);
//           }
//         }
//       }
//     }
//     else
//     {
//       Flat_ShowItems(playerid, roomid);
//     }
//   }
//   return 1;
// }

// Dialog:FlatDeposit(playerid, response, listitem, inputtext[]) {
//   new
//     roomid,
//     string[32];

//   if((roomid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, roomid)))
//   {
//     strunpack(string, InventoryData[playerid][pData[playerid][pInventoryItem]][invItem]);

//     if(response)
//     {
//       new amount = strval(inputtext);

//       if(amount < 1 || amount > InventoryData[playerid][pData[playerid][pInventoryItem]][invQuantity])
//         return Dialog_Show(playerid, FlatDeposit, DIALOG_STYLE_INPUT, "Flat Deposit", "Item: %s (Quantity: %d)\n\nPlease enter the quantity that you wish to store for this item:", "Store", "Back", string, InventoryData[playerid][pData[playerid][pInventoryItem]][invQuantity]);

//       Flat_AddItem(roomid, string, InventoryData[playerid][pData[playerid][pInventoryItem]][invModel], amount);
//       Inventory_Remove(playerid, string, amount);

//       SendNearbyMessage(playerid, 15.0, COLOR_PURPLE, "** %s has stored a \"%s\" into their room storage.", ReturnName(playerid), string);
//       Log_Write("logs/storage_log.txt", "[%s] %s has stored \"%s\" (%d) into their room ID: %d.", ReturnDate(), ReturnName(playerid), string, amount, roomid);

//       Flat_ShowItems(playerid, roomid);
//     }
//     else Flat_OpenStorage(playerid, roomid);
//   }  
//   return 1;
// }

Dialog:FlatMoney(playerid, response, listitem, inputtext[]) {
  new
    roomid;

  if((roomid = FlatRoom_Inside(playerid)) != -1 && FlatRoom_IsOwner(playerid, roomid) || pData[playerid][pAdmin] > 5)
  {
    if(response)
    {
      switch (listitem)
      {
        case 0: Dialog_Show(playerid, FlatWithdrawCash, DIALOG_STYLE_INPUT, "Withdraw from safe", "Safe Balance: %s\n\nPlease enter how much money you wish to withdraw from the safe:", "Withdraw", "Back", FormatMoney(FlatRoom[roomid][flatRoomMoney]));
        case 1: Dialog_Show(playerid, FlatDepositCash, DIALOG_STYLE_INPUT, "Deposit into safe", "Safe Balance: %s\n\nPlease enter how much money you wish to deposit into the safe:", "Deposit", "Back", FormatMoney(FlatRoom[roomid][flatRoomMoney]));
      }
    }
    else Flat_OpenStorage(playerid, roomid);
  }
  return 1;
}

Dialog:FlatWithdrawCash(playerid, response, listitem, inputtext[]) {
  new
    roomid;

  if((roomid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, roomid) || pData[playerid][pAdmin] > 5))
  {
    if(response)
    {
      new amount = strval(inputtext);

      if(isnull(inputtext))
        return Dialog_Show(playerid, FlatWithdrawCash, DIALOG_STYLE_INPUT, "Withdraw from safe", "Safe Balance: %s\n\nPlease enter how much money you wish to withdraw from the safe:", "Withdraw", "Back", FormatMoney(FlatRoom[roomid][flatRoomMoney]));

      if(amount < 1 || amount > FlatRoom[roomid][flatRoomMoney])
        return Dialog_Show(playerid, FlatWithdrawCash, DIALOG_STYLE_INPUT, "Withdraw from safe", "Error: Insufficient funds.\n\nSafe Balance: %s\n\nPlease enter how much money you wish to withdraw from the safe:", "Withdraw", "Back", FormatMoney(FlatRoom[roomid][flatRoomMoney]));

      FlatRoom[roomid][flatRoomMoney] -= amount;
      GivePlayerMoneyEx(playerid, amount);

      FlatRoom_Save(roomid);
      Flat_OpenStorage(playerid, roomid);

      SendNearbyMessage(playerid, 15.0, COLOR_PURPLE, "** %s has withdrawn %s from their room safe.", ReturnName(playerid), FormatMoney(amount));
    }
    else Dialog_Show(playerid, FlatMoney, DIALOG_STYLE_LIST, "Money Safe", "Withdraw from safe\nDeposit into safe", "Select", "Back");
  }
  return 1;
}

Dialog:FlatDepositCash(playerid, response, listitem, inputtext[]) {
  new
    roomid;

  if((roomid = FlatRoom_Inside(playerid)) != -1 && FlatRoom_IsOwner(playerid, roomid))
  {
    if(response)
    {
      new amount = strval(inputtext);

      if(isnull(inputtext))
        return Dialog_Show(playerid, FlatDepositCash, DIALOG_STYLE_INPUT, "Deposit into safe", "Safe Balance: %s\n\nPlease enter how much money you wish to deposit into the safe:", "Deposit", "Back", FormatMoney(FlatRoom[roomid][flatRoomMoney]));

      if(amount < 1 || amount > pData[playerid][pMoney])
        return Dialog_Show(playerid, FlatDepositCash, DIALOG_STYLE_INPUT, "Deposit into safe", "Error: Insufficient funds.\n\nSafe Balance: %s\n\nPlease enter how much money you wish to deposit into the safe:", "Deposit", "Back", FormatMoney(FlatRoom[roomid][flatRoomMoney]));

      FlatRoom[roomid][flatRoomMoney] += amount;
      GivePlayerMoneyEx(playerid, -amount);

      FlatRoom_Save(roomid);
      Flat_OpenStorage(playerid, roomid);

      SendNearbyMessage(playerid, 15.0, COLOR_PURPLE, "** %s has deposited %s into their room safe.", ReturnName(playerid), FormatMoney(amount));
    }
    else Dialog_Show(playerid, FlatMoney, DIALOG_STYLE_LIST, "Money Safe", "Withdraw from safe\nDeposit into safe", "Select", "Back");
  }
  return 1;
}

hook OnGameModeInitEx() {
  mysql_tquery(g_SQL, "SELECT * FROM `flat`", "Flat_Load", "");
  mysql_tquery(g_SQL, "SELECT * FROM `flatroom`", "FlatRoom_Load", "");
  return 1;
}

#if defined DEVELOPMENT
  hook OnPlayerEnterDynArea(playerid, areaid) {
    new info[2];
    Streamer_GetArrayData(STREAMER_TYPE_AREA, areaid, E_STREAMER_EXTRA_ID, info);

    if (info[0] == FLAT_AREA_INDEX) {
      new flatroom = info[1];
      
      SendClientMessageEx(playerid, -1, "[debug]: you've entered flatroom area ID: "YELLOW_E"%d", flatroom);
    }
    return 1;
  }
#endif


hook OnPlayerLeaveDynArea(playerid, areaid) {
  new info[2];
  Streamer_GetArrayData(STREAMER_TYPE_AREA, areaid, E_STREAMER_EXTRA_ID, info);

  if (info[0] == FLAT_AREA_INDEX) {
    #if defined DEVELOPMENT
      new flatroom = info[1];
      SendClientMessageEx(playerid, -1, "[debug]: you've leaving from flatroom area ID: "YELLOW_E"%d", flatroom);
    #endif

    CancelEdit(playerid);
  }
  return 1;
}

function OnLoadFlatFurniture(flatid) {
  new rows = cache_num_rows(),
    str[128],
    slot = cellmin;
  
  Iter_Init(FlatFurnitures);
  for (new i = 0; i < rows; i ++) if ((slot = Iter_Free(FlatFurnitures[flatid])) != cellmin) {
    Iter_Add(FlatFurnitures[flatid], slot);

    cache_get_value_int(i, "ID", FlatFurniture[flatid][slot][furnID]);
    cache_get_value_int(i, "Model", FlatFurniture[flatid][slot][furnModel]);
    cache_get_value_int(i, "Unused", FlatFurniture[flatid][slot][furnUnused]);
    cache_get_value(i, "Name", str, 32);
    format(FlatFurniture[flatid][slot][furnName], 32, "%s", str);

    cache_get_value(i, "Position", str, 64);
    sscanf(str, "p<|>fff", FlatFurniture[flatid][slot][furnPos][0], FlatFurniture[flatid][slot][furnPos][1], FlatFurniture[flatid][slot][furnPos][2]);

    cache_get_value(i, "Rotation", str, 64);
    sscanf(str, "p<|>fff", FlatFurniture[flatid][slot][furnRot][0], FlatFurniture[flatid][slot][furnRot][1], FlatFurniture[flatid][slot][furnRot][2]);

    cache_get_value(i, "Materials", str, 128);
    sscanf(str, "p<|>dddddddddddddddd",
      FlatFurniture[flatid][slot][furnMaterials][0],
      FlatFurniture[flatid][slot][furnMaterials][1],
      FlatFurniture[flatid][slot][furnMaterials][2],
      FlatFurniture[flatid][slot][furnMaterials][3],
      FlatFurniture[flatid][slot][furnMaterials][4],
      FlatFurniture[flatid][slot][furnMaterials][5],
      FlatFurniture[flatid][slot][furnMaterials][6],
      FlatFurniture[flatid][slot][furnMaterials][7],
      FlatFurniture[flatid][slot][furnMaterials][8],
      FlatFurniture[flatid][slot][furnMaterials][9],
      FlatFurniture[flatid][slot][furnMaterials][10],
      FlatFurniture[flatid][slot][furnMaterials][11],
      FlatFurniture[flatid][slot][furnMaterials][12],
      FlatFurniture[flatid][slot][furnMaterials][13],
      FlatFurniture[flatid][slot][furnMaterials][14],
      FlatFurniture[flatid][slot][furnMaterials][15]
    );

    FlatFurniture_Refresh(slot, flatid);
  }
  return 1;
}

function OnFlatFurnitureCreated(flatid, slot) {
  if (!Iter_Contains(FlatFurnitures[flatid], slot))
    return 0;

  FlatFurniture[flatid][slot][furnID] = cache_insert_id();
  FlatFurniture_Save(slot, flatid);
  return 1;
}

FlatFurniture_Refresh(slot, flatid) {
  if (Iter_Contains(FlatFurnitures[flatid], slot)) {
    if (!IsValidDynamicObject(FlatFurniture[flatid][slot][furnObject])) {
      if (FlatFurniture[flatid][slot][furnUnused] == 0) {
        FlatFurniture[flatid][slot][furnObject] = CreateDynamicObject(FlatFurniture[flatid][slot][furnModel], FlatFurniture[flatid][slot][furnPos][0], FlatFurniture[flatid][slot][furnPos][1], FlatFurniture[flatid][slot][furnPos][2], FlatFurniture[flatid][slot][furnRot][0], FlatFurniture[flatid][slot][furnRot][1], FlatFurniture[flatid][slot][furnRot][2], FlatRoom[flatid][flatRoomWorld], FlatRoom[flatid][flatRoomInterior], -1, STREAMER_OBJECT_SD, 200.00, FlatRoom[flatid][flatRoomArea]);
      }
    }
    FlatFurniture_Update(slot, flatid);

    foreach(new i : Player) if(IsPlayerInRangeOfPoint(i, 5, FlatFurniture[flatid][slot][furnPos][0], FlatFurniture[flatid][slot][furnPos][1], FlatFurniture[flatid][slot][furnPos][2])) {
      Streamer_Update(i);
    }
  }
  return 1;
}

FlatFurniture_Update(slot, flatid) {
  if (Iter_Contains(FlatFurnitures[flatid], slot)) {
    if (!IsValidDynamicObject(FlatFurniture[flatid][slot][furnObject]))
      return 0;
    
    if (FlatFurniture[flatid][slot][furnUnused] == 1) {
      DestroyDynamicObject(FlatFurniture[flatid][slot][furnObject]);
      FlatFurniture[flatid][slot][furnObject] = STREAMER_TAG_OBJECT:INVALID_STREAMER_ID;

      return 1;
    }
    
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatFurniture[flatid][slot][furnObject], E_STREAMER_X, FlatFurniture[flatid][slot][furnPos][0]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatFurniture[flatid][slot][furnObject], E_STREAMER_Y,FlatFurniture[flatid][slot][furnPos][1]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatFurniture[flatid][slot][furnObject], E_STREAMER_Z, FlatFurniture[flatid][slot][furnPos][2]);

    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatFurniture[flatid][slot][furnObject], E_STREAMER_R_X, FlatFurniture[flatid][slot][furnRot][0]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatFurniture[flatid][slot][furnObject], E_STREAMER_R_Y, FlatFurniture[flatid][slot][furnRot][1]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, FlatFurniture[flatid][slot][furnObject], E_STREAMER_R_Z, FlatFurniture[flatid][slot][furnRot][2]);

    Streamer_SetIntData(STREAMER_TYPE_OBJECT, FlatFurniture[flatid][slot][furnObject], E_STREAMER_WORLD_ID, FlatRoom[flatid][flatRoomWorld]);
    Streamer_SetIntData(STREAMER_TYPE_OBJECT, FlatFurniture[flatid][slot][furnObject], E_STREAMER_INTERIOR_ID, FlatRoom[flatid][flatRoomInterior]);

    Streamer_SetIntData(STREAMER_TYPE_OBJECT, FlatFurniture[flatid][slot][furnObject], E_STREAMER_AREA_ID, FlatRoom[flatid][flatRoomArea]);

    for(new i = 0; i != MAX_MATERIALS; i++) if(FlatFurniture[flatid][slot][furnMaterials][i] > 0) {
      SetDynamicObjectMaterial(FlatFurniture[flatid][slot][furnObject], i, 
        GetTModel(FlatFurniture[flatid][slot][furnMaterials][i]), 
        GetTXDName(FlatFurniture[flatid][slot][furnMaterials][i]), 
        GetTextureName(FlatFurniture[flatid][slot][furnMaterials][i]), 0
      );
    }

    return 1;
  }
  return 0;
}

FlatFurniture_Add(flatid, name[], modelid, Float:x, Float:y, Float:z, Float:rx = 0.0, Float:ry = 0.0, Float:rz = 0.0, unused = 1) {
  static
    slot = cellmin;
  
  if ((slot = Iter_Free(FlatFurnitures[flatid])) != cellmin) {
    Iter_Add(FlatFurnitures[flatid], slot);

    FlatFurniture[flatid][slot][furnModel] = modelid;
    FlatFurniture[flatid][slot][furnPos][0] = x;
    FlatFurniture[flatid][slot][furnPos][1] = y;
    FlatFurniture[flatid][slot][furnPos][2] = z;
    FlatFurniture[flatid][slot][furnRot][0] = rx;
    FlatFurniture[flatid][slot][furnRot][1] = ry;
    FlatFurniture[flatid][slot][furnRot][2] = rz;
    FlatFurniture[flatid][slot][furnUnused] = unused;
    format(FlatFurniture[flatid][slot][furnName], 32, "%s", name);

    FlatFurniture_Refresh(slot, flatid);
    new string[212];
    format(string,sizeof(string),"INSERT INTO `flat_furniture` (`Flatid`) VALUES ('%d')", FlatRoom[flatid][flatRoomID]);
    mysql_tquery(g_SQL, string, "OnFlatFurnitureCreated", "dd", flatid, slot);

    return slot;
  }
  return cellmin;
}

FlatFurniture_DeleteAll(flatid) {
  foreach (new slot : FlatFurnitures[flatid]) {
    if (IsValidDynamicObject(FlatFurniture[flatid][slot][furnObject])) {
      DestroyDynamicObject(FlatFurniture[flatid][slot][furnObject]);
      FlatFurniture[flatid][slot][furnObject] = STREAMER_TAG_OBJECT:INVALID_STREAMER_ID;
    }
    
    new query[128];
    mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat_furniture` WHERE `ID` = '%d'", FlatFurniture[flatid][slot][furnID]);
    mysql_tquery(g_SQL, query);
    new tmp_FlatFurniture[flatFurniture];
    FlatFurniture[flatid][slot] = tmp_FlatFurniture;
  }
  
  Iter_Clear(FlatFurnitures[flatid]);
  return 1;
}

FlatFurniture_Delete(slot, flatid) {
  if (Iter_Contains(FlatFurnitures[flatid], slot)) {
    if (IsValidDynamicObject(FlatFurniture[flatid][slot][furnObject])) {
      DestroyDynamicObject(FlatFurniture[flatid][slot][furnObject]);
      FlatFurniture[flatid][slot][furnObject] = STREAMER_TAG_OBJECT:INVALID_STREAMER_ID;
    }
    
    new query[128];
    mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat_furniture` WHERE `ID` = '%d'", FlatFurniture[flatid][slot][furnID]);
    mysql_tquery(g_SQL, query);
    new tmp_FlatFurniture[flatFurniture];
    FlatFurniture[flatid][slot] = tmp_FlatFurniture;

    Iter_Remove(FlatFurnitures[flatid], slot);
    return 1;
  }
  return 0;
}

FlatFurniture_Save(slot, flatid) {
  if (!Iter_Contains(FlatFurnitures[flatid], slot))
    return 0;
  
  new query[1024];
  format(query,sizeof(query),"UPDATE `flat_furniture` SET `Flatid`='%d', `Model`='%d', `Name`='%s', `Unused`='%d', `Position`='%.2f|%.2f|%.2f', `Rotation`='%.2f|%.2f|%.2f', `Materials`='%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d' WHERE `ID`='%d';",
    FlatRoom[flatid][flatRoomID],
    FlatFurniture[flatid][slot][furnModel],
    FlatFurniture[flatid][slot][furnName],
    FlatFurniture[flatid][slot][furnUnused],
    FlatFurniture[flatid][slot][furnPos][0],
    FlatFurniture[flatid][slot][furnPos][1],
    FlatFurniture[flatid][slot][furnPos][2],
    FlatFurniture[flatid][slot][furnRot][0],
    FlatFurniture[flatid][slot][furnRot][1],
    FlatFurniture[flatid][slot][furnRot][2],
    FlatFurniture[flatid][slot][furnMaterials][0],
    FlatFurniture[flatid][slot][furnMaterials][1],
    FlatFurniture[flatid][slot][furnMaterials][2],
    FlatFurniture[flatid][slot][furnMaterials][3],
    FlatFurniture[flatid][slot][furnMaterials][4],
    FlatFurniture[flatid][slot][furnMaterials][5],
    FlatFurniture[flatid][slot][furnMaterials][6],
    FlatFurniture[flatid][slot][furnMaterials][7],
    FlatFurniture[flatid][slot][furnMaterials][8],
    FlatFurniture[flatid][slot][furnMaterials][9],
    FlatFurniture[flatid][slot][furnMaterials][10],
    FlatFurniture[flatid][slot][furnMaterials][11],
    FlatFurniture[flatid][slot][furnMaterials][12],
    FlatFurniture[flatid][slot][furnMaterials][13],
    FlatFurniture[flatid][slot][furnMaterials][14],
    FlatFurniture[flatid][slot][furnMaterials][15],
    FlatFurniture[flatid][slot][furnID]
  );

  return mysql_tquery(g_SQL, query);
}

FlatFurniture_GetCount(flatid) {
  return Iter_Count(FlatFurnitures[flatid]);
}

FlatFurniture_Show(playerid, flatid) {
  new
    count = 0,
    string[MAX_FLAT_FURNITURE * 64];

  if(!FlatFurniture_GetCount(flatid))
    return Error(playerid, "This flat doesn't have any furniture spawned.");

  strcat(string, "Model\tDistance\n");
  foreach (new i : FlatFurnitures[flatid])
  {
    if(FlatFurniture[flatid][i][furnUnused]) 
      format(string, sizeof(string), "%s%s\t(Not placed)\n", string, FlatFurniture[flatid][i][furnName]);
    else 
      format(string, sizeof(string), "%s%s\t%.2f\n", string, FlatFurniture[flatid][i][furnName], GetPlayerDistanceFromPoint(playerid, FlatFurniture[flatid][i][furnPos][0], FlatFurniture[flatid][i][furnPos][1], FlatFurniture[flatid][i][furnPos][2]));

    ListedFlatFurnitures[playerid][count++] = i;
  }
  Dialog_Show(playerid, ListedFlatFurniture, DIALOG_STYLE_TABLIST_HEADERS, "Flat Furniture", string, "Select", "Cancel");
  return 1;
}

#define MAX_FLAT_STORAGE  (5)

enum flatStorage {
  rItemID,
  rItemName[32 char],
  rItemModel,
  rItemQuantity
};
new FlatStorage[MAX_FLAT_ROOM][MAX_FLAT_STORAGE][flatStorage],
  Iterator:FlatStorages[MAX_FLAT_ROOM]<MAX_FLAT_STORAGE>;

function OnLoadFlatStorage(id) {
  new
    rows = cache_num_rows(),
    str[32],
    slot = cellmin;

  Iter_Init(FlatStorages);
  for (new i = 0; i != rows; i ++) if((slot = Iter_Free(FlatStorages[id])) != cellmin) {
    Iter_Add(FlatStorages[id], slot);

    cache_get_value_int(i, "itemID", FlatStorage[id][slot][rItemID]);
    cache_get_value_int(i, "itemModel", FlatStorage[id][slot][rItemModel]);
    cache_get_value_int(i, "itemQuantity", FlatStorage[id][slot][rItemQuantity]);

    cache_get_value(i, "itemName", str, sizeof(str));
    strpack(FlatStorage[id][slot][rItemName], str, 32 char);
  }
  return 1;
}

function OnFlatLoadWeapon(roomid)
{
  new
    rows = cache_num_rows();

  for (new i = 0; i != rows; i ++) {
    cache_get_value_int(i, "weaponid", FlatRoom[roomid][flatRoomWeapon][i]);
    cache_get_value_int(i, "ammo", FlatRoom[roomid][flatRoomAmmo][i]);
    cache_get_value_int(i, "durability", FlatRoom[roomid][flatRoomDurability][i]);
    cache_get_value_int(i, "typeammo", FlatRoom[roomid][flatRoomTypeAmmo][i]);
  }
  return 1;
}

function OnFlatStorageAdd(roomid, itemid)
{
  FlatStorage[roomid][itemid][rItemID] = cache_insert_id();
  return 1;
}

Flat_ShowItems(playerid, roomid)
{
  if(!Iter_Contains(FlatRooms, roomid))
    return 0;

  static
    string[MAX_FLAT_STORAGE * 32],
    name[32];

  string[0] = 0;

  for (new i = 0; i != MAX_FLAT_STORAGE; i ++)
  {
    if(!Iter_Contains(FlatStorages[roomid], i))
      format(string, sizeof(string), "%sEmpty Slot\n", string);

    else {
      strunpack(name, FlatStorage[roomid][i][rItemName]);

      if(FlatStorage[roomid][i][rItemQuantity] == 1) {
        format(string, sizeof(string), "%s%s\n", string, name);
      }
      else format(string, sizeof(string), "%s%s (%d)\n", string, name, FlatStorage[roomid][i][rItemQuantity]);
    }
  }
  Dialog_Show(playerid, Dialog_FlatItems, DIALOG_STYLE_LIST, "Item Storage", string, "Select", "Cancel");
  return 1;
}

Flat_OpenStorage(playerid, roomid)
{
  if(!Iter_Contains(FlatRooms, roomid))
    return 0;

  new
    items[2],
    string[MAX_FLAT_STORAGE * 32];

  items[0] = Iter_Count(FlatStorages[roomid]);
  for (new i = 0; i < 3; i ++) if(FlatRoom[roomid][flatRoomWeapon][i]) {
    items[1]++;
  }
  format(string, sizeof(string), "Item Storage (%d/%d)\nWeapon Storage (%d/3)\nMoney Safe (%s)", items[0], MAX_FLAT_STORAGE, items[1], FormatMoney(FlatRoom[roomid][flatRoomMoney]));
  Dialog_Show(playerid, Dialog_FlatStorage, DIALOG_STYLE_LIST, "Room Storage", string, "Select", "Cancel");
  return 1;
}

// Flat_GetItemID(roomid, item[])
// {
//   if(!Iter_Contains(FlatRooms, roomid))
//     return 0;

//   for (new i = 0; i < MAX_FLAT_STORAGE; i ++)
//   {
//     if(!Iter_Contains(FlatStorages[roomid], i))
//       continue;

//     if(!strcmp(FlatStorage[roomid][i][rItemName], item)) return i;
//   }
//   return -1;
// }

// Flat_GetFreeID(roomid)
// {
//   if(!Iter_Contains(FlatRooms, roomid))
//     return 0;

//   new freeid = cellmin;

//   if ((freeid = Iter_Free(FlatStorages[roomid])) != cellmin)
//     return freeid;

//   return cellmin;
// }

// Flat_AddItem(roomid, item[], model, quantity = 1, slotid = -1)
// {
//   if(!Iter_Contains(FlatRooms, roomid))
//     return 0;

//   new
//     itemid = Flat_GetItemID(roomid, item),
//     string[256];

//   if(itemid == -1)
//   {
//     itemid = Flat_GetFreeID(roomid);

//     if(itemid != cellmin)
//     {
//       if(slotid != -1)
//         itemid = slotid;

//       Iter_Add(FlatStorages[roomid], itemid);
//       FlatStorage[roomid][itemid][rItemModel] = model;
//       FlatStorage[roomid][itemid][rItemQuantity] = quantity;

//       strpack(FlatStorage[roomid][itemid][rItemName], item, 32 char);

//       format(string, sizeof(string), "INSERT INTO `flat_storage` (`ID`, `itemName`, `itemModel`, `itemQuantity`) VALUES ('%d', '%s', '%d', '%d')", FlatRoom[roomid][flatRoomID], item, model, quantity);
//       mysql_tquery(g_SQL, string, "OnFlatStorageAdd", "dd", roomid, itemid);

//       return itemid;
//     }
//     return -1;
//   }
//   else
//   {
//     format(string, sizeof(string), "UPDATE `flat_storage` SET `itemQuantity` = `itemQuantity` + %d WHERE `ID` = '%d' AND `itemID` = '%d'", quantity, FlatRoom[roomid][flatRoomID], FlatStorage[roomid][itemid][rItemID]);
//     mysql_tquery(g_SQL, string);

//     FlatStorage[roomid][itemid][rItemQuantity] += quantity;
//   }
//   return itemid;
// }

// Flat_RemoveItem(roomid, item[], quantity = 1)
// {
//   if(!Iter_Contains(FlatRooms, roomid))
//     return 0;

//   new
//     itemid = Flat_GetItemID(roomid, item),
//     string[128];

//   if(itemid != -1)
//   {
//     if(FlatStorage[roomid][itemid][rItemQuantity] > 0)
//     {
//       FlatStorage[roomid][itemid][rItemQuantity] -= quantity;
//     }
//     if(quantity == -1 || FlatStorage[roomid][itemid][rItemQuantity] < 1)
//     {
//       Iter_Remove(FlatStorages[roomid], itemid);
//       FlatStorage[roomid][itemid][rItemModel] = 0;
//       FlatStorage[roomid][itemid][rItemQuantity] = 0;

//       format(string, sizeof(string), "DELETE FROM `flat_storage` WHERE `ID` = '%d' AND `itemID` = '%d'", FlatRoom[roomid][flatRoomID], FlatStorage[roomid][itemid][rItemID]);
//       mysql_tquery(g_SQL, string);
//     }
//     else if(quantity != -1 && FlatStorage[roomid][itemid][rItemQuantity] > 0)
//     {
//       format(string, sizeof(string), "UPDATE `flat_storage` SET `itemQuantity` = `itemQuantity` - %d WHERE `ID` = '%d' AND `itemID` = '%d'", quantity, FlatRoom[roomid][flatRoomID], FlatStorage[roomid][itemid][rItemID]);
//       mysql_tquery(g_SQL, string);
//     }
//     return 1;
//   }
//   return 0;
// }

Flat_RemoveAllItems(roomid)
{
  if (!Iter_Contains(FlatRooms, roomid))
    return 0;

  for (new i = 0; i != MAX_FLAT_STORAGE; i ++) {
    FlatStorage[roomid][i][rItemModel] = 0;
    FlatStorage[roomid][i][rItemQuantity] = 0;
  }
  Iter_Clear(FlatStorages[roomid]);

  new query[128];
  mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat_storage` WHERE `ID` = '%d'", FlatRoom[roomid][flatRoomID]);
  mysql_tquery(g_SQL, query);
  for (new i = 0; i < 3; i ++) {
    FlatRoom[roomid][flatRoomWeapon][i] = 0;
    FlatRoom[roomid][flatRoomAmmo][i] = 0;
    FlatRoom[roomid][flatRoomDurability][i] = 0;
    FlatRoom[roomid][flatRoomTypeAmmo][i] = 0;
  }
  mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat_weapon` WHERE `flatroomid` = '%d'", FlatRoom[roomid][flatRoomID]);
  mysql_tquery(g_SQL, query);
  return 1;
}

GetTypeAmmoFlat(roomid) {
  new type[52];
  for (new i = 0; i < 3; i ++) {
      if(FlatRoom[roomid][flatRoomWeapon][i]) {
          if(FlatRoom[roomid][flatRoomTypeAmmo][i]) {
              format(type, sizeof(type), "%d Surplus", FlatRoom[roomid][flatRoomAmmo][i]);
          }
          else {
              format(type, sizeof(type), "%d", FlatRoom[roomid][flatRoomAmmo][i]);
          }
      }
  }
  return type;
}

Flat_WeaponStorage(playerid, roomid)
{
  if(!Iter_Contains(FlatRooms, roomid))
    return 0;

  new
    string[320];

  for (new i = 0; i < 3; i ++)
  {
    if(!FlatRoom[roomid][flatRoomWeapon][i]) format(string, sizeof(string), "%sEmpty Slot\n", string);
    else format(string, sizeof(string), "%s%s ("YELLOW_E"Ammo: %s"WHITE_E") ("YELLOW_E"Durability: %d"WHITE_E")\n", string, ReturnWeaponName(FlatRoom[roomid][flatRoomWeapon][i]), GetTypeAmmoFlat(roomid), FlatRoom[roomid][flatRoomDurability][i]);
  }
  Dialog_Show(playerid, FlatWeapons, DIALOG_STYLE_LIST, "Weapon Storage", string, "Select", "Cancel");
  return 1;
}

enum e_flatIntStructure {
  objRoomID,
  objModel,
  Float:objPosX,
  Float:objPosY,
  Float:objPosZ,
  Float:objRotX,
  Float:objRotY,
  Float:objRotZ
};

enum e_flatAreaPos {
  roomID,
  Float:minX,
  Float:minY,
  Float:maxX,
  Float:maxY,
  Float:zPos
};

new const FlatHighInterior[][e_flatIntStructure] = {
  {1, 19379, 1772.020141, -2507.650634, 12.626873, 0.000000, 90.000000, 0.000000},// Room 1 (Floor)
  {1, 19379, 1782.520751, -2507.650634, 12.626873, 0.000000, 90.000000, 0.000000},// Room 1 (Floor)
  {1, 19379, 1793.019897, -2507.650634, 12.626873, 0.000000, 90.000000, 0.000000},// Room 1 (Floor)
  {1, 19447, 1772.458618, -2496.501220, 14.474684, -0.000007, 180.000000, 90.000000},// Room 1 (Wall)
  {1, 19447, 1772.458618, -2512.371337, 14.474684, 0.000000, 180.000000, 90.000000},// Room 1 (Wall)
  {1, 19355, 1767.571166, -2510.866699, 14.474684, 0.000000, -0.000001, 0.000000},// Room 1 (Wall)
  {1, 19355, 1767.571166, -2507.655517, 14.474684, 0.000000, -0.000001, 0.000000},// Room 1 (Wall)
  {1, 19447, 1782.088989, -2512.371337, 14.474684, 0.000000, 180.000000, 90.000000},// Room 1 (Wall)
  {1, 19385, 1767.551147, -2504.444580, 14.474684, 0.000000, 0.000000, 0.000000},// Room 1 (Wall)
  {1, 19355, 1787.067138, -2512.381347, 14.474684, 0.000000, 180.000000, 90.000000},// Room 1 (Wall)
  {1, 19447, 1793.449829, -2512.371337, 14.474684, 0.000000, 180.000000, 90.000000},// Room 1 (Wall)
  {1, 19447, 1782.088989, -2496.501220, 14.474684, -0.000007, 180.000000, 90.000000},// Room 1 (Wall)
  {1, 19355, 1787.067138, -2496.511230, 14.474684, -0.000007, 180.000000, 90.000000},// Room 1 (Wall)
  {1, 19447, 1793.449829, -2496.501220, 14.474684, -0.000007, 180.000000, 90.000000},// Room 1 (Wall)
  {1, 19355, 1767.571166, -2501.231689, 14.474684, 0.000000, -0.000004, 0.000000},// Room 1 (Wall)
  {1, 19355, 1767.571166, -2498.020507, 14.474684, 0.000000, -0.000004, 0.000000},// Room 1 (Wall)
  {1, 19379, 1772.020141, -2501.189941, 12.616872, 0.000000, 90.000000, 0.000000},// Room 1 (Floor)
  {1, 19379, 1782.520751, -2501.189941, 12.616873, 0.000000, 90.000000, 0.000000},// Room 1 (Floor)
  {1, 19379, 1793.019897, -2501.189941, 12.616873, 0.000000, 90.000000, 0.000000},// Room 1 (Floor)
  {1, 19447, 1798.170776, -2507.468261, 14.454680, 0.000000, 180.000000, 180.000000},// Room 1 (Wall)
  {1, 19447, 1798.180786, -2501.302734, 14.474684, 0.000000, 180.000000, 180.000000},// Room 1 (Wall)
  {1, 19379, 1772.708496, -2507.650634, 16.316936, 0.000000, 90.000000, 0.000000},// Room 1 (Ceiling)
  {1, 19379, 1783.209106, -2507.650634, 16.316936, 0.000000, 90.000000, 0.000000},// Room 1 (Ceiling)
  {1, 19379, 1793.708251, -2507.650634, 16.316936, 0.000000, 90.000000, 0.000000},// Room 1 (Ceiling)
  {1, 19379, 1772.708496, -2501.189941, 16.306934, 0.000000, 90.000000, 0.000000},// Room 1 (Ceiling)
  {1, 19379, 1783.209106, -2501.189941, 16.306936, 0.000000, 90.000000, 0.000000},// Room 1 (Ceiling)
  {1, 19379, 1793.708251, -2501.189941, 16.306936, 0.000000, 90.000000, 0.000000},// Room 1 (Ceiling)
  {2, 19379, 1772.020141, -2491.651367, 12.626873, 0.000000, 90.000000, 0.000000}, // Room 2 (Floor)
  {2, 19379, 1782.520751, -2491.651367, 12.626873, 0.000000, 90.000000, 0.000000}, // Room 2 (Floor)
  {2, 19379, 1793.019897, -2491.651367, 12.626873, 0.000000, 90.000000, 0.000000}, // Room 2 (Floor)
  {2, 19447, 1772.458618, -2480.501953, 14.474684, -0.000009, 180.000000, 90.000000}, // Room 2 (Wall)
  {2, 19447, 1772.458618, -2496.372070, 14.474684, -0.000001, 180.000000, 90.000000}, // Room 2 (Wall)
  {2, 19355, 1767.571166, -2494.867431, 14.474684, 0.000000, -0.000004, 0.000000}, // Room 2 (Wall)
  {2, 19355, 1767.571166, -2491.656250, 14.474684, 0.000000, -0.000004, 0.000000}, // Room 2 (Wall)
  {2, 19447, 1782.088989, -2496.372070, 14.474684, -0.000001, 180.000000, 90.000000}, // Room 2 (Wall)
  {2, 19385, 1767.551147, -2488.445312, 14.474684, 0.000000, -0.000001, 0.000000}, // Room 2 (Wall)
  {2, 19355, 1787.067138, -2496.382080, 14.474684, -0.000001, 180.000000, 90.000000}, // Room 2 (Wall)
  {2, 19447, 1793.449829, -2496.372070, 14.474684, -0.000001, 180.000000, 90.000000}, // Room 2 (Wall)
  {2, 19447, 1782.088989, -2480.501953, 14.474684, -0.000009, 180.000000, 90.000000}, // Room 2 (Wall)
  {2, 19355, 1787.067138, -2480.511962, 14.474684, -0.000009, 180.000000, 90.000000}, // Room 2 (Wall)
  {2, 19447, 1793.449829, -2480.501953, 14.474684, -0.000009, 180.000000, 90.000000}, // Room 2 (Wall)
  {2, 19355, 1767.571166, -2485.232421, 14.474684, 0.000000, -0.000007, 0.000000}, // Room 2 (Wall)
  {2, 19355, 1767.571166, -2482.021240, 14.474684, 0.000000, -0.000007, 0.000000}, // Room 2 (Wall)
  {2, 19379, 1772.020141, -2485.190673, 12.616872, 0.000000, 90.000000, 0.000000}, // Room 2 (Floor)
  {2, 19379, 1782.520751, -2485.190673, 12.616873, 0.000000, 90.000000, 0.000000}, // Room 2 (Floor)
  {2, 19379, 1793.019897, -2485.190673, 12.616873, 0.000000, 90.000000, 0.000000}, // Room 2 (Floor)
  {2, 19447, 1798.170776, -2491.468994, 14.454683, 0.000000, 180.000000, -179.999984}, // Room 2 (Wall)
  {2, 19447, 1798.180786, -2485.303466, 14.474684, 0.000000, 180.000000, -179.999984}, // Room 2 (Wall)
  {2, 19379, 1772.708496, -2491.651367, 16.316936, 0.000000, 90.000000, 0.000000}, // Room 2 (Ceiling)
  {2, 19379, 1783.209106, -2491.651367, 16.316936, 0.000000, 90.000000, 0.000000}, // Room 2 (Ceiling)
  {2, 19379, 1793.708251, -2491.651367, 16.316936, 0.000000, 90.000000, 0.000000}, // Room 2 (Ceiling)
  {2, 19379, 1772.708496, -2485.190673, 16.306934, 0.000000, 90.000000, 0.000000}, // Room 2 (Ceiling)
  {2, 19379, 1783.209106, -2485.190673, 16.306936, 0.000000, 90.000000, 0.000000}, // Room 2 (Ceiling)
  {2, 19379, 1793.708251, -2485.190673, 16.306936, 0.000000, 90.000000, 0.000000}, // Room 2 (Ceiling)
  {3, 19379, 1752.270019, -2501.231933, 12.626873, 0.000000, 90.000000, -179.999938}, // Room 3 (Floor)
  {3, 19447, 1751.831542, -2496.511230, 14.474684, -0.000004, 180.000000, -89.999969}, // Room 3 (Wall)
  {3, 19355, 1756.718750, -2498.016113, 14.474684, 0.000000, -0.000007, -179.999938}, // Room 3 (Wall)
  {3, 19355, 1756.718750, -2501.227050, 14.474684, 0.000000, -0.000007, -179.999938}, // Room 3 (Wall)
  {3, 19447, 1742.201171, -2496.511230, 14.474684, -0.000004, 180.000000, -89.999969}, // Room 3 (Wall)
  {3, 19385, 1756.728759, -2504.437988, 14.474684, 0.000000, -0.000004, -179.999938}, // Room 3 (Wall)
  {3, 19355, 1737.222900, -2496.501464, 14.474684, -0.000004, 180.000000, -89.999969}, // Room 3 (Wall)
  {3, 19447, 1730.840332, -2496.511230, 14.474684, -0.000004, 180.000000, -89.999969}, // Room 3 (Wall)
  {3, 19447, 1742.201171, -2512.381347, 14.474684, -0.000012, 180.000000, -89.999969}, // Room 3 (Wall)
  {3, 19355, 1737.222900, -2512.371582, 14.474684, -0.000012, 180.000000, -89.999969}, // Room 3 (Wall)
  {3, 19447, 1730.840332, -2512.381347, 14.474684, -0.000012, 180.000000, -89.999969}, // Room 3 (Wall)
  {3, 19355, 1756.718750, -2507.650878, 14.474684, 0.000000, -0.000009, -179.999938}, // Room 3 (Wall)
  {3, 19355, 1756.718750, -2510.862304, 14.474684, 0.000000, -0.000009, -179.999938}, // Room 3 (Wall)
  {3, 19379, 1752.270019, -2507.692871, 12.616872, 0.000000, 90.000000, -179.999938}, // Room 3 (Floor)
  {3, 19379, 1741.769287, -2507.692871, 12.616873, 0.000000, 90.000000, -179.999938}, // Room 3 (Floor)
  {3, 19379, 1731.270019, -2507.692871, 12.616873, 0.000000, 90.000000, -179.999938}, // Room 3 (Floor)
  {3, 19447, 1726.119140, -2501.414550, 14.474684, 0.000000, 180.000000, 0.000027}, // Room 3 (Wall)
  {3, 19447, 1726.109375, -2507.580078, 14.444683, 0.000000, 180.000000, 0.000027}, // Room 3 (Wall)
  {3, 19379, 1751.581542, -2501.231933, 16.316936, 0.000000, 90.000000, -179.999938}, // Room 3 (Ceiling)
  {3, 19379, 1741.081054, -2501.231933, 16.316936, 0.000000, 90.000000, -179.999938}, // Room 3 (Ceiling)
  {3, 19379, 1730.581787, -2501.231933, 16.316936, 0.000000, 90.000000, -179.999938}, // Room 3 (Ceiling)
  {3, 19379, 1751.581542, -2507.692871, 16.306934, 0.000000, 90.000000, -179.999938}, // Room 3 (Ceiling)
  {3, 19379, 1741.081054, -2507.692871, 16.306936, 0.000000, 90.000000, -179.999938}, // Room 3 (Ceiling)
  {3, 19379, 1730.581787, -2507.692871, 16.306936, 0.000000, 90.000000, -179.999938}, // Room 3 (Ceiling)
  {3, 19379, 1741.769287, -2501.231933, 12.626873, 0.000000, 90.000000, -179.999938}, // Room 3 (Floor)
  {3, 19379, 1731.270019, -2501.231933, 12.626873, 0.000000, 90.000000, -179.999938}, // Room 3 (Floor)
  {3, 19447, 1751.831542, -2512.381347, 14.474684, -0.000012, 180.000000, -89.999969}, // Room 3 (Wall)
  {4, 19379, 1752.270019, -2485.188476, 12.626873, 0.000000, 90.000000, -179.999938}, // Room 4 (Floor)
  {4, 19447, 1751.831542, -2480.467773, 14.474684, -0.000001, 180.000000, -89.999969}, // Room 4 (Wall)
  {4, 19355, 1756.718750, -2481.972656, 14.474684, 0.000000, -0.000004, -179.999938}, // Room 4 (Wall)
  {4, 19355, 1756.718750, -2485.183593, 14.474684, 0.000000, -0.000004, -179.999938}, // Room 4 (Wall)
  {4, 19447, 1742.201171, -2480.467773, 14.474684, -0.000001, 180.000000, -89.999969}, // Room 4 (Wall)
  {4, 19385, 1756.728759, -2488.394531, 14.474684, 0.000000, -0.000001, -179.999938}, // Room 4 (Wall)
  {4, 19355, 1737.222900, -2480.458007, 14.474684, -0.000001, 180.000000, -89.999969}, // Room 4 (Wall)
  {4, 19447, 1730.840332, -2480.467773, 14.474684, -0.000001, 180.000000, -89.999969}, // Room 4 (Wall)
  {4, 19447, 1742.201171, -2496.337890, 14.474684, -0.000009, 180.000000, -89.999969}, // Room 4 (Wall)
  {4, 19355, 1737.222900, -2496.328125, 14.474684, -0.000009, 180.000000, -89.999969}, // Room 4 (Wall)
  {4, 19447, 1730.840332, -2496.337890, 14.474684, -0.000009, 180.000000, -89.999969}, // Room 4 (Wall)
  {4, 19355, 1756.718750, -2491.607421, 14.474684, 0.000000, -0.000007, -179.999938}, // Room 4 (Wall)
  {4, 19355, 1756.718750, -2494.818847, 14.474684, 0.000000, -0.000007, -179.999938}, // Room 4 (Wall)
  {4, 19379, 1752.270019, -2491.649414, 12.616872, 0.000000, 90.000000, -179.999938}, // Room 4 (Floor)
  {4, 19379, 1741.769287, -2491.649414, 12.616873, 0.000000, 90.000000, -179.999938}, // Room 4 (Floor)
  {4, 19379, 1731.270019, -2491.649414, 12.616873, 0.000000, 90.000000, -179.999938}, // Room 4 (Floor)
  {4, 19447, 1726.119140, -2485.371093, 14.474684, 0.000000, 180.000000, 0.000027}, // Room 4 (Wall)
  {4, 19447, 1726.109375, -2491.536621, 14.444683, 0.000000, 180.000000, 0.000027}, // Room 4 (Wall)
  {4, 19379, 1751.581542, -2485.188476, 16.316936, 0.000000, 90.000000, -179.999938}, // Room 4 (Ceiling)
  {4, 19379, 1741.081054, -2485.188476, 16.316936, 0.000000, 90.000000, -179.999938}, // Room 4 (Ceiling)
  {4, 19379, 1730.581787, -2485.188476, 16.316936, 0.000000, 90.000000, -179.999938}, // Room 4 (Ceiling)
  {4, 19379, 1751.581542, -2491.649414, 16.306934, 0.000000, 90.000000, -179.999938}, // Room 4 (Ceiling)
  {4, 19379, 1741.081054, -2491.649414, 16.306936, 0.000000, 90.000000, -179.999938}, // Room 4 (Ceiling)
  {4, 19379, 1730.581787, -2491.649414, 16.306936, 0.000000, 90.000000, -179.999938}, // Room 4 (Ceiling)
  {4, 19379, 1741.769287, -2485.188476, 12.626873, 0.000000, 90.000000, -179.999938}, // Room 4 (Floor)
  {4, 19379, 1731.270019, -2485.188476, 12.626873, 0.000000, 90.000000, -179.999938}, // Room 4 (Floor)
  {4, 19447, 1751.831542, -2496.337890, 14.474684, -0.000009, 180.000000, -89.999969}, // Room 4 (Wall)
  {5, 19379, 1772.020141, -2507.650634, 18.786949, 0.000000, 90.000000, 0.000000}, // Room 5 (Floor)
  {5, 19379, 1782.520751, -2507.650634, 18.786949, 0.000000, 90.000000, 0.000000}, // Room 5 (Floor)
  {5, 19379, 1793.019897, -2507.650634, 18.786949, 0.000000, 90.000000, 0.000000}, // Room 5 (Floor)
  {5, 19447, 1772.458618, -2496.501220, 20.634759, -0.000009, 180.000000, 90.000000}, // Room 5 (Wall)
  {5, 19447, 1772.458618, -2512.371337, 20.634759, -0.000001, 180.000000, 90.000000}, // Room 5 (Wall)
  {5, 19355, 1767.571166, -2510.866699, 20.634759, 0.000000, -0.000004, 0.000000}, // Room 5 (Wall)
  {5, 19355, 1767.571166, -2507.655517, 20.634759, 0.000000, -0.000004, 0.000000}, // Room 5 (Wall)
  {5, 19447, 1782.088989, -2512.371337, 20.634759, -0.000001, 180.000000, 90.000000}, // Room 5 (Wall)
  {5, 19385, 1767.551147, -2504.444580, 20.634759, 0.000000, -0.000001, 0.000000}, // Room 5 (Wall)
  {5, 19355, 1787.067138, -2512.381347, 20.634759, -0.000001, 180.000000, 90.000000}, // Room 5 (Wall)
  {5, 19447, 1793.449829, -2512.371337, 20.634759, -0.000001, 180.000000, 90.000000}, // Room 5 (Wall)
  {5, 19447, 1782.088989, -2496.501220, 20.634759, -0.000009, 180.000000, 90.000000}, // Room 5 (Wall)
  {5, 19355, 1787.067138, -2496.511230, 20.634759, -0.000009, 180.000000, 90.000000}, // Room 5 (Wall)
  {5, 19447, 1793.449829, -2496.501220, 20.634759, -0.000009, 180.000000, 90.000000}, // Room 5 (Wall)
  {5, 19355, 1767.571166, -2501.231689, 20.634759, 0.000000, -0.000007, 0.000000}, // Room 5 (Wall)
  {5, 19355, 1767.571166, -2498.020507, 20.634759, 0.000000, -0.000007, 0.000000}, // Room 5 (Wall)
  {5, 19379, 1772.020141, -2501.189941, 18.776947, 0.000000, 90.000000, 0.000000}, // Room 5 (Floor)
  {5, 19379, 1782.520751, -2501.189941, 18.776948, 0.000000, 90.000000, 0.000000}, // Room 5 (Floor)
  {5, 19379, 1793.019897, -2501.189941, 18.776948, 0.000000, 90.000000, 0.000000}, // Room 5 (Floor)
  {5, 19447, 1798.170776, -2507.468261, 20.604759, 0.000000, 180.000000, -179.999984}, // Room 5 (Wall)
  {5, 19447, 1798.180786, -2501.302734, 20.604759, 0.000000, 180.000000, -179.999984}, // Room 5 (Wall)
  {5, 19379, 1772.708496, -2507.650634, 22.477010, 0.000000, 90.000000, 0.000000}, // Room 5 (Ceiling)
  {5, 19379, 1783.209106, -2507.650634, 22.477010, 0.000000, 90.000000, 0.000000}, // Room 5 (Ceiling)
  {5, 19379, 1793.708251, -2507.650634, 22.477010, 0.000000, 90.000000, 0.000000}, // Room 5 (Ceiling)
  {5, 19379, 1772.708496, -2501.189941, 22.467008, 0.000000, 90.000000, 0.000000}, // Room 5 (Ceiling)
  {5, 19379, 1783.209106, -2501.189941, 22.467010, 0.000000, 90.000000, 0.000000}, // Room 5 (Ceiling)
  {5, 19379, 1793.708251, -2501.189941, 22.467010, 0.000000, 90.000000, 0.000000}, // Room 5 (Ceiling)
  {6, 19379, 1772.020141, -2491.651367, 18.786884, 0.000000, 90.000000, 0.000000}, // Room 6 (Floor)
  {6, 19379, 1782.520751, -2491.651367, 18.786886, 0.000000, 90.000000, 0.000000}, // Room 6 (Floor)
  {6, 19379, 1793.019897, -2491.651367, 18.786886, 0.000000, 90.000000, 0.000000}, // Room 6 (Floor)
  {6, 19447, 1772.458618, -2480.501953, 20.634695, -0.000012, 180.000000, 90.000000}, // Room 6 (Wall)
  {6, 19447, 1772.458618, -2496.372070, 20.634695, -0.000004, 180.000000, 90.000000}, // Room 6 (Wall)
  {6, 19355, 1767.571166, -2494.867431, 20.634695, 0.000000, -0.000007, 0.000000}, // Room 6 (Wall)
  {6, 19355, 1767.571166, -2491.656250, 20.634695, 0.000000, -0.000007, 0.000000}, // Room 6 (Wall)
  {6, 19447, 1782.088989, -2496.372070, 20.634695, -0.000004, 180.000000, 90.000000}, // Room 6 (Wall)
  {6, 19385, 1767.551147, -2488.445312, 20.634695, 0.000000, -0.000004, 0.000000}, // Room 6 (Wall)
  {6, 19355, 1787.067138, -2496.382080, 20.634695, -0.000004, 180.000000, 90.000000}, // Room 6 (Wall)
  {6, 19447, 1793.449829, -2496.372070, 20.634695, -0.000004, 180.000000, 90.000000}, // Room 6 (Wall)
  {6, 19447, 1782.088989, -2480.501953, 20.634695, -0.000012, 180.000000, 90.000000}, // Room 6 (Wall)
  {6, 19355, 1787.067138, -2480.511962, 20.634695, -0.000012, 180.000000, 90.000000}, // Room 6 (Wall)
  {6, 19447, 1793.449829, -2480.501953, 20.634695, -0.000012, 180.000000, 90.000000}, // Room 6 (Wall)
  {6, 19355, 1767.571166, -2485.232421, 20.634695, 0.000000, -0.000009, 0.000000}, // Room 6 (Wall)
  {6, 19355, 1767.571166, -2482.021240, 20.634695, 0.000000, -0.000009, 0.000000}, // Room 6 (Wall)
  {6, 19379, 1772.020141, -2485.190673, 18.776884, 0.000000, 90.000000, 0.000000}, // Room 6 (Floor)
  {6, 19379, 1782.520751, -2485.190673, 18.776884, 0.000000, 90.000000, 0.000000}, // Room 6 (Floor)
  {6, 19379, 1793.019897, -2485.190673, 18.776884, 0.000000, 90.000000, 0.000000}, // Room 6 (Floor)
  {6, 19447, 1798.170776, -2491.468994, 20.614688, 0.000000, 180.000000, -179.999984}, // Room 6 (Wall)
  {6, 19447, 1798.180786, -2485.303466, 20.604700, 0.000000, 180.000000, -179.999984}, // Room 6 (Wall)
  {6, 19379, 1772.708496, -2491.651367, 22.476947, 0.000000, 90.000000, 0.000000}, // Room 6 (Ceiling)
  {6, 19379, 1783.209106, -2491.651367, 22.476947, 0.000000, 90.000000, 0.000000}, // Room 6 (Ceiling)
  {6, 19379, 1793.708251, -2491.651367, 22.476947, 0.000000, 90.000000, 0.000000}, // Room 6 (Ceiling)
  {6, 19379, 1772.708496, -2485.190673, 22.466945, 0.000000, 90.000000, 0.000000}, // Room 6 (Ceiling)
  {6, 19379, 1783.209106, -2485.190673, 22.466947, 0.000000, 90.000000, 0.000000}, // Room 6 (Ceiling)
  {6, 19379, 1793.708251, -2485.190673, 22.466947, 0.000000, 90.000000, 0.000000}, // Room 6 (Ceiling)
  {7, 19379, 1752.270019, -2501.231933, 18.786911, 0.000000, 90.000000, -179.999938}, // Room 7 (Floor)
  {7, 19447, 1751.831542, -2496.511230, 20.634723, -0.000001, 180.000000, -89.999969}, // Room 7 (Wall)
  {7, 19355, 1756.718750, -2498.016113, 20.634723, 0.000000, -0.000004, -179.999938}, // Room 7 (Wall)
  {7, 19355, 1756.718750, -2501.227050, 20.634723, 0.000000, -0.000004, -179.999938}, // Room 7 (Wall)
  {7, 19447, 1742.201171, -2496.511230, 20.634723, -0.000001, 180.000000, -89.999969}, // Room 7 (Wall)
  {7, 19385, 1756.728759, -2504.437988, 20.634723, 0.000000, -0.000001, -179.999938}, // Room 7 (Wall)
  {7, 19355, 1737.222900, -2496.501464, 20.634723, -0.000001, 180.000000, -89.999969}, // Room 7 (Wall)
  {7, 19447, 1730.840332, -2496.511230, 20.634723, -0.000001, 180.000000, -89.999969}, // Room 7 (Wall)
  {7, 19447, 1742.201171, -2512.381347, 20.634723, -0.000009, 180.000000, -89.999969}, // Room 7 (Wall)
  {7, 19355, 1737.222900, -2512.371582, 20.634723, -0.000009, 180.000000, -89.999969}, // Room 7 (Wall)
  {7, 19447, 1730.840332, -2512.381347, 20.634723, -0.000009, 180.000000, -89.999969}, // Room 7 (Wall)
  {7, 19355, 1756.718750, -2507.650878, 20.634723, 0.000000, -0.000007, -179.999938}, // Room 7 (Wall)
  {7, 19355, 1756.718750, -2510.862304, 20.634723, 0.000000, -0.000007, -179.999938}, // Room 7 (Wall)
  {7, 19379, 1752.270019, -2507.692871, 18.776912, 0.000000, 90.000000, -179.999938}, // Room 7 (Floor)
  {7, 19379, 1741.769287, -2507.692871, 18.776912, 0.000000, 90.000000, -179.999938}, // Room 7 (Floor)
  {7, 19379, 1731.270019, -2507.692871, 18.776912, 0.000000, 90.000000, -179.999938}, // Room 7 (Floor)
  {7, 19447, 1726.119140, -2501.414550, 20.614723, 0.000000, 180.000000, 0.000027}, // Room 7 (Wall)
  {7, 19447, 1726.109375, -2507.580078, 20.604721, 0.000000, 180.000000, 0.000027}, // Room 7 (Wall)
  {7, 19379, 1751.581542, -2501.231933, 22.476974, 0.000000, 90.000000, -179.999938}, // Room 7 (Ceiling)
  {7, 19379, 1741.081054, -2501.231933, 22.476974, 0.000000, 90.000000, -179.999938}, // Room 7 (Ceiling)
  {7, 19379, 1730.581787, -2501.231933, 22.476974, 0.000000, 90.000000, -179.999938}, // Room 7 (Ceiling)
  {7, 19379, 1751.581542, -2507.692871, 22.466972, 0.000000, 90.000000, -179.999938}, // Room 7 (Ceiling)
  {7, 19379, 1741.081054, -2507.692871, 22.466974, 0.000000, 90.000000, -179.999938}, // Room 7 (Ceiling)
  {7, 19379, 1730.581787, -2507.692871, 22.466974, 0.000000, 90.000000, -179.999938}, // Room 7 (Ceiling)
  {7, 19379, 1741.769287, -2501.231933, 18.786912, 0.000000, 90.000000, -179.999938}, // Room 7 (Floor)
  {7, 19379, 1731.270019, -2501.231933, 18.786912, 0.000000, 90.000000, -179.999938}, // Room 7 (Floor)
  {7, 19447, 1751.831542, -2512.381347, 20.634723, -0.000009, 180.000000, -89.999969}, // Room 7 (Wall)
  {8, 19379, 1752.270019, -2485.188476, 18.786911, 0.000000, 90.000000, -179.999938}, // Room 8 (Floor)
  {8, 19447, 1751.831542, -2480.467773, 20.634723, 0.000000, 180.000000, -89.999969}, // Room 8 (Wall)
  {8, 19355, 1756.718750, -2481.972656, 20.634723, 0.000000, -0.000001, -179.999938}, // Room 8 (Wall)
  {8, 19355, 1756.718750, -2485.183593, 20.634723, 0.000000, -0.000001, -179.999938}, // Room 8 (Wall)
  {8, 19447, 1742.201171, -2480.467773, 20.634723, 0.000000, 180.000000, -89.999969}, // Room 8 (Wall)
  {8, 19385, 1756.728759, -2488.394531, 20.634723, 0.000000, 0.000000, -179.999938}, // Room 8 (Wall)
  {8, 19355, 1737.222900, -2480.458007, 20.634723, 0.000000, 180.000000, -89.999969}, // Room 8 (Wall)
  {8, 19447, 1730.840332, -2480.467773, 20.634723, 0.000000, 180.000000, -89.999969}, // Room 8 (Wall)
  {8, 19447, 1742.201171, -2496.337890, 20.634723, -0.000007, 180.000000, -89.999969}, // Room 8 (Wall)
  {8, 19355, 1737.222900, -2496.328125, 20.634723, -0.000007, 180.000000, -89.999969}, // Room 8 (Wall)
  {8, 19447, 1730.840332, -2496.337890, 20.634723, -0.000007, 180.000000, -89.999969}, // Room 8 (Wall)
  {8, 19355, 1756.718750, -2491.607421, 20.634723, 0.000000, -0.000004, -179.999938}, // Room 8 (Wall)
  {8, 19355, 1756.718750, -2494.818847, 20.634723, 0.000000, -0.000004, -179.999938}, // Room 8 (Wall)
  {8, 19379, 1752.270019, -2491.649414, 18.776912, 0.000000, 90.000000, -179.999938}, // Room 8 (Floor)
  {8, 19379, 1741.769287, -2491.649414, 18.776912, 0.000000, 90.000000, -179.999938}, // Room 8 (Floor)
  {8, 19379, 1731.270019, -2491.649414, 18.776912, 0.000000, 90.000000, -179.999938}, // Room 8 (Floor)
  {8, 19447, 1726.119140, -2485.371093, 20.614723, 0.000000, 180.000000, 0.000027}, // Room 8 (Wall)
  {8, 19447, 1726.109375, -2491.536621, 20.604721, 0.000000, 180.000000, 0.000027}, // Room 8 (Wall)
  {8, 19379, 1751.581542, -2485.188476, 22.476974, 0.000000, 90.000000, -179.999938}, // Room 8 (Ceiling)
  {8, 19379, 1741.081054, -2485.188476, 22.476974, 0.000000, 90.000000, -179.999938}, // Room 8 (Ceiling)
  {8, 19379, 1730.581787, -2485.188476, 22.476974, 0.000000, 90.000000, -179.999938}, // Room 8 (Ceiling)
  {8, 19379, 1751.581542, -2491.649414, 22.466972, 0.000000, 90.000000, -179.999938}, // Room 8 (Ceiling)
  {8, 19379, 1741.081054, -2491.649414, 22.466974, 0.000000, 90.000000, -179.999938}, // Room 8 (Ceiling)
  {8, 19379, 1730.581787, -2491.649414, 22.466974, 0.000000, 90.000000, -179.999938}, // Room 8 (Ceiling)
  {8, 19379, 1741.769287, -2485.188476, 18.786912, 0.000000, 90.000000, -179.999938}, // Room 8 (Floor)
  {8, 19379, 1731.270019, -2485.188476, 18.786912, 0.000000, 90.000000, -179.999938}, // Room 8 (Floor)
  {8, 19447, 1751.831542, -2496.337890, 20.634723, -0.000007, 180.000000, -89.999969}, // Room 8 (Wall)
  {9, 19379, 1772.020141, -2507.650634, 24.986986, 0.000000, 90.000000, 0.000000}, // Room 9 (Floor)
  {9, 19379, 1782.520751, -2507.650634, 24.986986, 0.000000, 90.000000, 0.000000}, // Room 9 (Floor)
  {9, 19379, 1793.019897, -2507.650634, 24.986986, 0.000000, 90.000000, 0.000000}, // Room 9 (Floor)
  {9, 19447, 1772.458618, -2496.501220, 26.834796, -0.000012, 180.000000, 90.000000}, // Room 9 (Wall)
  {9, 19447, 1772.458618, -2512.371337, 26.834796, -0.000004, 180.000000, 90.000000}, // Room 9 (Wall)
  {9, 19355, 1767.571166, -2510.866699, 26.834796, 0.000000, -0.000007, 0.000000}, // Room 9 (Wall)
  {9, 19355, 1767.571166, -2507.655517, 26.834796, 0.000000, -0.000007, 0.000000}, // Room 9 (Wall)
  {9, 19447, 1782.088989, -2512.371337, 26.834796, -0.000004, 180.000000, 90.000000}, // Room 9 (Wall)
  {9, 19385, 1767.551147, -2504.444580, 26.834796, 0.000000, -0.000004, 0.000000}, // Room 9 (Wall)
  {9, 19355, 1787.067138, -2512.381347, 26.834796, -0.000004, 180.000000, 90.000000}, // Room 9 (Wall)
  {9, 19447, 1793.449829, -2512.371337, 26.834796, -0.000004, 180.000000, 90.000000}, // Room 9 (Wall)
  {9, 19447, 1782.088989, -2496.501220, 26.834796, -0.000012, 180.000000, 90.000000}, // Room 9 (Wall)
  {9, 19355, 1787.067138, -2496.511230, 26.834796, -0.000012, 180.000000, 90.000000}, // Room 9 (Wall)
  {9, 19447, 1793.449829, -2496.501220, 26.834796, -0.000012, 180.000000, 90.000000}, // Room 9 (Wall)
  {9, 19355, 1767.571166, -2501.231689, 26.834796, 0.000000, -0.000009, 0.000000}, // Room 9 (Wall)
  {9, 19355, 1767.571166, -2498.020507, 26.834796, 0.000000, -0.000009, 0.000000}, // Room 9 (Wall)
  {9, 19379, 1772.020141, -2501.189941, 24.976984, 0.000000, 90.000000, 0.000000}, // Room 9 (Floor)
  {9, 19379, 1782.520751, -2501.189941, 24.976985, 0.000000, 90.000000, 0.000000}, // Room 9 (Floor)
  {9, 19379, 1793.019897, -2501.189941, 24.976985, 0.000000, 90.000000, 0.000000}, // Room 9 (Floor)
  {9, 19447, 1798.170776, -2507.468261, 26.814796, 0.000000, 180.000000, -179.999984}, // Room 9 (Wall)
  {9, 19447, 1798.180786, -2501.302734, 26.804796, 0.000000, 180.000000, -179.999984}, // Room 9 (Wall)
  {9, 19379, 1772.708496, -2507.650634, 28.677047, 0.000000, 90.000000, 0.000000}, // Room 9 (Ceiling)
  {9, 19379, 1783.209106, -2507.650634, 28.677047, 0.000000, 90.000000, 0.000000}, // Room 9 (Ceiling)
  {9, 19379, 1793.708251, -2507.650634, 28.677047, 0.000000, 90.000000, 0.000000}, // Room 9 (Ceiling)
  {9, 19379, 1772.708496, -2501.189941, 28.667045, 0.000000, 90.000000, 0.000000}, // Room 9 (Ceiling)
  {9, 19379, 1783.209106, -2501.189941, 28.667047, 0.000000, 90.000000, 0.000000}, // Room 9 (Ceiling)
  {9, 19379, 1793.708251, -2501.189941, 28.667047, 0.000000, 90.000000, 0.000000}, // Room 9 (Ceiling)
  {10, 19379, 1772.020141, -2491.651367, 24.986917, 0.000000, 90.000000, 0.000000}, // Room 10 (Floor)
  {10, 19379, 1782.520751, -2491.651367, 24.986919, 0.000000, 90.000000, 0.000000}, // Room 10 (Floor)
  {10, 19379, 1793.019897, -2491.651367, 24.986919, 0.000000, 90.000000, 0.000000}, // Room 10 (Floor)
  {10, 19447, 1772.458618, -2480.501953, 26.834730, -0.000014, 180.000000, 90.000000}, // Room 10 (Wall)
  {10, 19447, 1772.458618, -2496.372070, 26.834730, -0.000007, 180.000000, 90.000000}, // Room 10 (Wall)
  {10, 19355, 1767.571166, -2494.867431, 26.834730, 0.000000, -0.000009, 0.000000}, // Room 10 (Wall)
  {10, 19355, 1767.571166, -2491.656250, 26.834730, 0.000000, -0.000009, 0.000000}, // Room 10 (Wall)
  {10, 19447, 1782.088989, -2496.372070, 26.834730, -0.000007, 180.000000, 90.000000}, // Room 10 (Wall)
  {10, 19385, 1767.551147, -2488.445312, 26.834730, 0.000000, -0.000007, 0.000000}, // Room 10 (Wall)
  {10, 19355, 1787.067138, -2496.382080, 26.834730, -0.000007, 180.000000, 90.000000}, // Room 10 (Wall)
  {10, 19447, 1793.449829, -2496.372070, 26.834730, -0.000007, 180.000000, 90.000000}, // Room 10 (Wall)
  {10, 19447, 1782.088989, -2480.501953, 26.834730, -0.000014, 180.000000, 90.000000}, // Room 10 (Wall)
  {10, 19355, 1787.067138, -2480.511962, 26.834730, -0.000014, 180.000000, 90.000000}, // Room 10 (Wall)
  {10, 19447, 1793.449829, -2480.501953, 26.834730, -0.000014, 180.000000, 90.000000}, // Room 10 (Wall)
  {10, 19355, 1767.571166, -2485.232421, 26.834730, 0.000000, -0.000012, 0.000000}, // Room 10 (Wall)
  {10, 19355, 1767.571166, -2482.021240, 26.834730, 0.000000, -0.000012, 0.000000}, // Room 10 (Wall)
  {10, 19379, 1772.020141, -2485.190673, 24.976919, 0.000000, 90.000000, 0.000000}, // Room 10 (Floor)
  {10, 19379, 1782.520751, -2485.190673, 24.976919, 0.000000, 90.000000, 0.000000}, // Room 10 (Floor)
  {10, 19379, 1793.019897, -2485.190673, 24.976919, 0.000000, 90.000000, 0.000000}, // Room 10 (Floor)
  {10, 19447, 1798.170776, -2491.468994, 26.824729, 0.000000, 180.000000, -179.999984}, // Room 10 (Wall)
  {10, 19447, 1798.180786, -2485.303466, 26.804735, 0.000000, 180.000000, -179.999984}, // Room 10 (Wall)
  {10, 19379, 1772.708496, -2491.651367, 28.676979, 0.000000, 90.000000, 0.000000}, // Room 10 (Ceiling)
  {10, 19379, 1783.209106, -2491.651367, 28.676979, 0.000000, 90.000000, 0.000000}, // Room 10 (Ceiling)
  {10, 19379, 1793.708251, -2491.651367, 28.676979, 0.000000, 90.000000, 0.000000}, // Room 10 (Ceiling)
  {10, 19379, 1772.708496, -2485.190673, 28.666978, 0.000000, 90.000000, 0.000000}, // Room 10 (Ceiling)
  {10, 19379, 1783.209106, -2485.190673, 28.666980, 0.000000, 90.000000, 0.000000}, // Room 10 (Ceiling)
  {10, 19379, 1793.708251, -2485.190673, 28.666980, 0.000000, 90.000000, 0.000000}, // Room 10 (Ceiling)
  {11, 19379, 1752.270019, -2501.231933, 24.986951, 0.000000, 90.000000, -179.999938}, // Room 11 (Floor)
  {11, 19447, 1751.831542, -2496.511230, 26.834764, 0.000000, 180.000000, -89.999969}, // Room 11 (Wall)
  {11, 19355, 1756.718750, -2498.016113, 26.834764, 0.000000, -0.000001, -179.999938}, // Room 11 (Wall)
  {11, 19355, 1756.718750, -2501.227050, 26.834764, 0.000000, -0.000001, -179.999938}, // Room 11 (Wall)
  {11, 19447, 1742.201171, -2496.511230, 26.834764, 0.000000, 180.000000, -89.999969}, // Room 11 (Wall)
  {11, 19385, 1756.728759, -2504.437988, 26.834764, 0.000000, 0.000000, -179.999938}, // Room 11 (Wall)
  {11, 19355, 1737.222900, -2496.501464, 26.834764, 0.000000, 180.000000, -89.999969}, // Room 11 (Wall)
  {11, 19447, 1730.840332, -2496.511230, 26.834764, 0.000000, 180.000000, -89.999969}, // Room 11 (Wall)
  {11, 19447, 1742.201171, -2512.381347, 26.834764, -0.000007, 180.000000, -89.999969}, // Room 11 (Wall)
  {11, 19355, 1737.222900, -2512.371582, 26.834764, -0.000007, 180.000000, -89.999969}, // Room 11 (Wall)
  {11, 19447, 1730.840332, -2512.381347, 26.834764, -0.000007, 180.000000, -89.999969}, // Room 11 (Wall)
  {11, 19355, 1756.718750, -2507.650878, 26.834764, 0.000000, -0.000004, -179.999938}, // Room 11 (Wall)
  {11, 19355, 1756.718750, -2510.862304, 26.834764, 0.000000, -0.000004, -179.999938}, // Room 11 (Wall)
  {11, 19379, 1752.270019, -2507.692871, 24.976953, 0.000000, 90.000000, -179.999938}, // Room 11 (Floor)
  {11, 19379, 1741.769287, -2507.692871, 24.976953, 0.000000, 90.000000, -179.999938}, // Room 11 (Floor)
  {11, 19379, 1731.270019, -2507.692871, 24.976953, 0.000000, 90.000000, -179.999938}, // Room 11 (Floor)
  {11, 19447, 1726.119140, -2501.414550, 26.824764, 0.000000, 180.000000, 0.000027}, // Room 11 (Wall)
  {11, 19447, 1726.109375, -2507.580078, 26.804761, 0.000000, 180.000000, 0.000027}, // Room 11 (Wall)
  {11, 19379, 1751.581542, -2501.231933, 28.677015, 0.000000, 90.000000, -179.999938}, // Room 11 (Ceiling)
  {11, 19379, 1741.081054, -2501.231933, 28.677015, 0.000000, 90.000000, -179.999938}, // Room 11 (Ceiling)
  {11, 19379, 1730.581787, -2501.231933, 28.677015, 0.000000, 90.000000, -179.999938}, // Room 11 (Ceiling)
  {11, 19379, 1751.581542, -2507.692871, 28.667013, 0.000000, 90.000000, -179.999938}, // Room 11 (Ceiling)
  {11, 19379, 1741.081054, -2507.692871, 28.667015, 0.000000, 90.000000, -179.999938}, // Room 11 (Ceiling)
  {11, 19379, 1730.581787, -2507.692871, 28.667015, 0.000000, 90.000000, -179.999938}, // Room 11 (Ceiling)
  {11, 19379, 1741.769287, -2501.231933, 24.986953, 0.000000, 90.000000, -179.999938}, // Room 11 (Floor)
  {11, 19379, 1731.270019, -2501.231933, 24.986953, 0.000000, 90.000000, -179.999938}, // Room 11 (Floor)
  {11, 19447, 1751.831542, -2512.381347, 26.834764, -0.000007, 180.000000, -89.999969}, // Room 11 (Wall)
  {12, 19379, 1752.270019, -2485.188476, 24.976947, 0.000000, 90.000000, -179.999938}, // Room 12 (Floor)
  {12, 19447, 1751.831542, -2480.467773, 26.824760, 0.000001, 180.000000, -89.999969}, // Room 12 (Wall)
  {12, 19355, 1756.718750, -2481.972656, 26.824760, 0.000000, 0.000000, -179.999938}, // Room 12 (Wall)
  {12, 19355, 1756.718750, -2485.183593, 26.824760, 0.000000, 0.000000, -179.999938}, // Room 12 (Wall)
  {12, 19447, 1742.201171, -2480.467773, 26.824760, 0.000001, 180.000000, -89.999969}, // Room 12 (Wall)
  {12, 19385, 1756.728759, -2488.394531, 26.824760, 0.000000, 0.000001, -179.999938}, // Room 12 (Wall)
  {12, 19355, 1737.222900, -2480.458007, 26.824760, 0.000001, 180.000000, -89.999969}, // Room 12 (Wall)
  {12, 19447, 1730.840332, -2480.467773, 26.824760, 0.000001, 180.000000, -89.999969}, // Room 12 (Wall)
  {12, 19447, 1742.201171, -2496.337890, 26.824760, -0.000004, 180.000000, -89.999969}, // Room 12 (Wall)
  {12, 19355, 1737.222900, -2496.328125, 26.824760, -0.000004, 180.000000, -89.999969}, // Room 12 (Wall)
  {12, 19447, 1730.840332, -2496.337890, 26.824760, -0.000004, 180.000000, -89.999969}, // Room 12 (Wall)
  {12, 19355, 1756.718750, -2491.607421, 26.824760, 0.000000, -0.000001, -179.999938}, // Room 12 (Wall)
  {12, 19355, 1756.718750, -2494.818847, 26.824760, 0.000000, -0.000001, -179.999938}, // Room 12 (Wall)
  {12, 19379, 1752.270019, -2491.649414, 24.966949, 0.000000, 90.000000, -179.999938}, // Room 12 (Floor)
  {12, 19379, 1741.769287, -2491.649414, 24.966949, 0.000000, 90.000000, -179.999938}, // Room 12 (Floor)
  {12, 19379, 1731.270019, -2491.649414, 24.966949, 0.000000, 90.000000, -179.999938}, // Room 12 (Floor)
  {12, 19447, 1726.119140, -2485.371093, 26.814760, 0.000000, 180.000000, 0.000027}, // Room 12 (Wall)
  {12, 19447, 1726.109375, -2491.536621, 26.794757, 0.000000, 180.000000, 0.000027}, // Room 12 (Wall)
  {12, 19379, 1751.581542, -2485.188476, 28.667011, 0.000000, 90.000000, -179.999938}, // Room 12 (Ceiling)
  {12, 19379, 1741.081054, -2485.188476, 28.667011, 0.000000, 90.000000, -179.999938}, // Room 12 (Ceiling)
  {12, 19379, 1730.581787, -2485.188476, 28.667011, 0.000000, 90.000000, -179.999938}, // Room 12 (Ceiling)
  {12, 19379, 1751.581542, -2491.649414, 28.657009, 0.000000, 90.000000, -179.999938}, // Room 12 (Ceiling)
  {12, 19379, 1741.081054, -2491.649414, 28.657011, 0.000000, 90.000000, -179.999938}, // Room 12 (Ceiling)
  {12, 19379, 1730.581787, -2491.649414, 28.657011, 0.000000, 90.000000, -179.999938}, // Room 12 (Ceiling)
  {12, 19379, 1741.769287, -2485.188476, 24.976949, 0.000000, 90.000000, -179.999938}, // Room 12 (Floor)
  {12, 19379, 1731.270019, -2485.188476, 24.976949, 0.000000, 90.000000, -179.999938}, // Room 12 (Floor)
  {12, 19447, 1751.831542, -2496.337890, 26.824760, -0.000004, 180.000000, -89.999969}, // Room 12 (Wall)
  {13, 19379, 1772.020141, -2507.650634, 31.167001, 0.000000, 90.000000, 0.000000}, // Room 13 (Floor)
  {13, 19379, 1782.520751, -2507.650634, 31.167001, 0.000000, 90.000000, 0.000000}, // Room 13 (Floor)
  {13, 19379, 1793.019897, -2507.650634, 31.167001, 0.000000, 90.000000, 0.000000}, // Room 13 (Floor)
  {13, 19447, 1772.458618, -2496.501220, 33.014812, -0.000014, 180.000000, 90.000000}, // Room 13 (Wall)
  {13, 19447, 1772.458618, -2512.371337, 33.014812, -0.000007, 180.000000, 90.000000}, // Room 13 (Wall)
  {13, 19355, 1767.571166, -2510.866699, 33.014812, 0.000000, -0.000009, 0.000000}, // Room 13 (Wall)
  {13, 19355, 1767.571166, -2507.655517, 33.014812, 0.000000, -0.000009, 0.000000}, // Room 13 (Wall)
  {13, 19447, 1782.088989, -2512.371337, 33.014812, -0.000007, 180.000000, 90.000000}, // Room 13 (Wall)
  {13, 19385, 1767.551147, -2504.444580, 33.014812, 0.000000, -0.000007, 0.000000}, // Room 13 (Wall)
  {13, 19355, 1787.067138, -2512.381347, 33.014812, -0.000007, 180.000000, 90.000000}, // Room 13 (Wall)
  {13, 19447, 1793.449829, -2512.371337, 33.014812, -0.000007, 180.000000, 90.000000}, // Room 13 (Wall)
  {13, 19447, 1782.088989, -2496.501220, 33.014812, -0.000014, 180.000000, 90.000000}, // Room 13 (Wall)
  {13, 19355, 1787.067138, -2496.511230, 33.014812, -0.000014, 180.000000, 90.000000}, // Room 13 (Wall)
  {13, 19447, 1793.449829, -2496.501220, 33.014812, -0.000014, 180.000000, 90.000000}, // Room 13 (Wall)
  {13, 19355, 1767.571166, -2501.231689, 33.014812, 0.000000, -0.000012, 0.000000}, // Room 13 (Wall)
  {13, 19355, 1767.571166, -2498.020507, 33.014812, 0.000000, -0.000012, 0.000000}, // Room 13 (Wall)
  {13, 19379, 1772.020141, -2501.189941, 31.156999, 0.000000, 90.000000, 0.000000}, // Room 13 (Floor)
  {13, 19379, 1782.520751, -2501.189941, 31.157001, 0.000000, 90.000000, 0.000000}, // Room 13 (Floor)
  {13, 19379, 1793.019897, -2501.189941, 31.157001, 0.000000, 90.000000, 0.000000}, // Room 13 (Floor)
  {13, 19447, 1798.170776, -2507.468261, 32.994800, 0.000000, 180.000000, -179.999984}, // Room 13 (Wall)
  {13, 19447, 1798.180786, -2501.302734, 32.984809, 0.000000, 180.000000, -179.999984}, // Room 13 (Wall)
  {13, 19379, 1772.708496, -2507.650634, 34.857063, 0.000000, 90.000000, 0.000000}, // Room 13 (Ceiling)
  {13, 19379, 1783.209106, -2507.650634, 34.857063, 0.000000, 90.000000, 0.000000}, // Room 13 (Ceiling)
  {13, 19379, 1793.708251, -2507.650634, 34.857063, 0.000000, 90.000000, 0.000000}, // Room 13 (Ceiling)
  {13, 19379, 1772.708496, -2501.189941, 34.847061, 0.000000, 90.000000, 0.000000}, // Room 13 (Ceiling)
  {13, 19379, 1783.209106, -2501.189941, 34.847061, 0.000000, 90.000000, 0.000000}, // Room 13 (Ceiling)
  {13, 19379, 1793.708251, -2501.189941, 34.847061, 0.000000, 90.000000, 0.000000}, // Room 13 (Ceiling)
  {14, 19379, 1772.020141, -2491.651367, 31.156999, 0.000000, 90.000000, 0.000000}, // Room 14 (Floor)
  {14, 19379, 1782.520751, -2491.651367, 31.157001, 0.000000, 90.000000, 0.000000}, // Room 14 (Floor)
  {14, 19379, 1793.019897, -2491.651367, 31.157001, 0.000000, 90.000000, 0.000000}, // Room 14 (Floor)
  {14, 19447, 1772.458618, -2480.501953, 33.004814, -0.000017, 180.000000, 90.000000}, // Room 14 (Wall)
  {14, 19447, 1772.458618, -2496.372070, 33.004814, -0.000009, 180.000000, 90.000000}, // Room 14 (Wall)
  {14, 19355, 1767.571166, -2494.867431, 33.004814, 0.000000, -0.000012, 0.000000}, // Room 14 (Wall)
  {14, 19355, 1767.571166, -2491.656250, 33.004814, 0.000000, -0.000012, 0.000000}, // Room 14 (Wall)
  {14, 19447, 1782.088989, -2496.372070, 33.004814, -0.000009, 180.000000, 90.000000}, // Room 14 (Wall)
  {14, 19385, 1767.551147, -2488.445312, 33.004814, 0.000000, -0.000009, 0.000000}, // Room 14 (Wall)
  {14, 19355, 1787.067138, -2496.382080, 33.004814, -0.000009, 180.000000, 90.000000}, // Room 14 (Wall)
  {14, 19447, 1793.449829, -2496.372070, 33.004814, -0.000009, 180.000000, 90.000000}, // Room 14 (Wall)
  {14, 19447, 1782.088989, -2480.501953, 33.004814, -0.000017, 180.000000, 90.000000}, // Room 14 (Wall)
  {14, 19355, 1787.067138, -2480.511962, 33.004814, -0.000017, 180.000000, 90.000000}, // Room 14 (Wall)
  {14, 19447, 1793.449829, -2480.501953, 33.004814, -0.000017, 180.000000, 90.000000}, // Room 14 (Wall)
  {14, 19355, 1767.571166, -2485.232421, 33.004814, 0.000000, -0.000014, 0.000000}, // Room 14 (Wall)
  {14, 19355, 1767.571166, -2482.021240, 33.004814, 0.000000, -0.000014, 0.000000}, // Room 14 (Wall)
  {14, 19379, 1772.020141, -2485.190673, 31.147001, 0.000000, 90.000000, 0.000000}, // Room 14 (Floor)
  {14, 19379, 1782.520751, -2485.190673, 31.147001, 0.000000, 90.000000, 0.000000}, // Room 14 (Floor)
  {14, 19379, 1793.019897, -2485.190673, 31.147001, 0.000000, 90.000000, 0.000000}, // Room 14 (Floor)
  {14, 19447, 1798.170776, -2491.468994, 33.004814, 0.000000, 180.000000, -179.999984}, // Room 14 (Wall)
  {14, 19447, 1798.180786, -2485.303466, 32.974815, 0.000000, 180.000000, -179.999984}, // Room 14 (Wall)
  {14, 19379, 1772.708496, -2491.651367, 34.847061, 0.000000, 90.000000, 0.000000}, // Room 14 (Ceiling)
  {14, 19379, 1783.209106, -2491.651367, 34.847061, 0.000000, 90.000000, 0.000000}, // Room 14 (Ceiling)
  {14, 19379, 1793.708251, -2491.651367, 34.847061, 0.000000, 90.000000, 0.000000}, // Room 14 (Ceiling)
  {14, 19379, 1772.708496, -2485.190673, 34.837059, 0.000000, 90.000000, 0.000000}, // Room 14 (Ceiling)
  {14, 19379, 1783.209106, -2485.190673, 34.837062, 0.000000, 90.000000, 0.000000}, // Room 14 (Ceiling)
  {14, 19379, 1793.708251, -2485.190673, 34.837062, 0.000000, 90.000000, 0.000000}, // Room 14 (Ceiling)
  {15, 19379, 1752.270019, -2501.231933, 31.186990, 0.000000, 90.000000, -179.999938}, // Room 15 (Floor)
  {15, 19447, 1751.831542, -2496.511230, 33.034805, 0.000001, 180.000000, -89.999969}, // Room 15 (Wall)
  {15, 19355, 1756.718750, -2498.016113, 33.034805, 0.000000, 0.000000, -179.999938}, // Room 15 (Wall)
  {15, 19355, 1756.718750, -2501.227050, 33.034805, 0.000000, 0.000000, -179.999938}, // Room 15 (Wall)
  {15, 19447, 1742.201171, -2496.511230, 33.034805, 0.000001, 180.000000, -89.999969}, // Room 15 (Wall)
  {15, 19385, 1756.728759, -2504.437988, 33.034805, 0.000000, 0.000001, -179.999938}, // Room 15 (Wall)
  {15, 19355, 1737.222900, -2496.501464, 33.034805, 0.000001, 180.000000, -89.999969}, // Room 15 (Wall)
  {15, 19447, 1730.840332, -2496.511230, 33.034805, 0.000001, 180.000000, -89.999969}, // Room 15 (Wall)
  {15, 19447, 1742.201171, -2512.381347, 33.034805, -0.000004, 180.000000, -89.999969}, // Room 15 (Wall)
  {15, 19355, 1737.222900, -2512.371582, 33.034805, -0.000004, 180.000000, -89.999969}, // Room 15 (Wall)
  {15, 19447, 1730.840332, -2512.381347, 33.034805, -0.000004, 180.000000, -89.999969}, // Room 15 (Wall)
  {15, 19355, 1756.718750, -2507.650878, 33.034805, 0.000000, -0.000001, -179.999938}, // Room 15 (Wall)
  {15, 19355, 1756.718750, -2510.862304, 33.034805, 0.000000, -0.000001, -179.999938}, // Room 15 (Wall)
  {15, 19379, 1752.270019, -2507.692871, 31.176992, 0.000000, 90.000000, -179.999938}, // Room 15 (Floor)
  {15, 19379, 1741.769287, -2507.692871, 31.176992, 0.000000, 90.000000, -179.999938}, // Room 15 (Floor)
  {15, 19379, 1731.270019, -2507.692871, 31.176992, 0.000000, 90.000000, -179.999938}, // Room 15 (Floor)
  {15, 19447, 1726.119140, -2501.414550, 33.014812, 0.000000, 180.000000, 0.000027}, // Room 15 (Wall)
  {15, 19447, 1726.109375, -2507.580078, 33.004798, 0.000000, 180.000000, 0.000027}, // Room 15 (Wall)
  {15, 19379, 1751.581542, -2501.231933, 34.877052, 0.000000, 90.000000, -179.999938}, // Room 15 (Ceiling)
  {15, 19379, 1741.081054, -2501.231933, 34.877052, 0.000000, 90.000000, -179.999938}, // Room 15 (Ceiling)
  {15, 19379, 1730.581787, -2501.231933, 34.877052, 0.000000, 90.000000, -179.999938}, // Room 15 (Ceiling)
  {15, 19379, 1751.581542, -2507.692871, 34.867050, 0.000000, 90.000000, -179.999938}, // Room 15 (Ceiling)
  {15, 19379, 1741.081054, -2507.692871, 34.867053, 0.000000, 90.000000, -179.999938}, // Room 15 (Ceiling)
  {15, 19379, 1730.581787, -2507.692871, 34.867053, 0.000000, 90.000000, -179.999938}, // Room 15 (Ceiling)
  {15, 19379, 1741.769287, -2501.231933, 31.186992, 0.000000, 90.000000, -179.999938}, // Room 15 (Floor)
  {15, 19379, 1731.270019, -2501.231933, 31.186992, 0.000000, 90.000000, -179.999938}, // Room 15 (Floor)
  {15, 19447, 1751.831542, -2512.381347, 33.034805, -0.000004, 180.000000, -89.999969}, // Room 15 (Wall)
  {16, 19379, 1752.270019, -2485.188476, 31.176927, 0.000000, 90.000000, -179.999938}, // Room 16 (Floor)
  {16, 19447, 1751.831542, -2480.467773, 33.024742, 0.000004, 180.000000, -89.999969}, // Room 16 (Wall)
  {16, 19355, 1756.718750, -2481.972656, 33.024742, 0.000000, 0.000001, -179.999938}, // Room 16 (Wall)
  {16, 19355, 1756.718750, -2485.183593, 33.024742, 0.000000, 0.000001, -179.999938}, // Room 16 (Wall)
  {16, 19447, 1742.201171, -2480.467773, 33.024742, 0.000004, 180.000000, -89.999969}, // Room 16 (Wall)
  {16, 19385, 1756.728759, -2488.394531, 33.024742, 0.000000, 0.000004, -179.999938}, // Room 16 (Wall)
  {16, 19355, 1737.222900, -2480.458007, 33.024742, 0.000004, 180.000000, -89.999969}, // Room 16 (Wall)
  {16, 19447, 1730.840332, -2480.467773, 33.024742, 0.000004, 180.000000, -89.999969}, // Room 16 (Wall)
  {16, 19447, 1742.201171, -2496.337890, 33.024742, -0.000001, 180.000000, -89.999969}, // Room 16 (Wall)
  {16, 19355, 1737.222900, -2496.328125, 33.024742, -0.000001, 180.000000, -89.999969}, // Room 16 (Wall)
  {16, 19447, 1730.840332, -2496.337890, 33.024742, -0.000001, 180.000000, -89.999969}, // Room 16 (Wall)
  {16, 19355, 1756.718750, -2491.607421, 33.024742, 0.000000, 0.000000, -179.999938}, // Room 16 (Wall)
  {16, 19355, 1756.718750, -2494.818847, 33.024742, 0.000000, 0.000000, -179.999938}, // Room 16 (Wall)
  {16, 19379, 1752.270019, -2491.649414, 31.166929, 0.000000, 90.000000, -179.999938}, // Room 16 (Floor)
  {16, 19379, 1741.769287, -2491.649414, 31.166929, 0.000000, 90.000000, -179.999938}, // Room 16 (Floor)
  {16, 19379, 1731.270019, -2491.649414, 31.166929, 0.000000, 90.000000, -179.999938}, // Room 16 (Floor)
  {16, 19447, 1726.119140, -2485.371093, 32.994747, 0.000000, 180.000000, 0.000027}, // Room 16 (Wall)
  {16, 19447, 1726.109375, -2491.536621, 32.994735, 0.000000, 180.000000, 0.000027}, // Room 16 (Wall)
  {16, 19379, 1751.581542, -2485.188476, 34.866989, 0.000000, 90.000000, -179.999938}, // Room 16 (Ceiling)
  {16, 19379, 1741.081054, -2485.188476, 34.866989, 0.000000, 90.000000, -179.999938}, // Room 16 (Ceiling)
  {16, 19379, 1730.581787, -2485.188476, 34.866989, 0.000000, 90.000000, -179.999938}, // Room 16 (Ceiling)
  {16, 19379, 1751.581542, -2491.649414, 34.856986, 0.000000, 90.000000, -179.999938}, // Room 16 (Ceiling)
  {16, 19379, 1741.081054, -2491.649414, 34.856990, 0.000000, 90.000000, -179.999938}, // Room 16 (Ceiling)
  {16, 19379, 1730.581787, -2491.649414, 34.856990, 0.000000, 90.000000, -179.999938}, // Room 16 (Ceiling)
  {16, 19379, 1741.769287, -2485.188476, 31.176929, 0.000000, 90.000000, -179.999938}, // Room 16 (Floor)
  {16, 19379, 1731.270019, -2485.188476, 31.176929, 0.000000, 90.000000, -179.999938}, // Room 16 (Floor)
  {16, 19447, 1751.831542, -2496.337890, 33.024742, -0.000001, 180.000000, -89.999969} // Room 16 (Wall)
};

new const FlatHighAreaPos[][e_flatAreaPos] = {
  // 1st Floor
  {1, 1766.61, -2512.94, 1798.82, -2496.50, 13.71}, // Room 1
  {2, 1766.63, -2496.37, 1798.82, -2479.75, 13.71}, // Room 2
  {3, 1725.41, -2512.94, 1757.62, -2496.50, 13.71}, // Room 3
  {4, 1725.43, -2496.37, 1757.62, -2479.75, 13.71}, // Room 4

  // 2nd Floor
  {5, 1766.61, -2512.94, 1798.82, -2496.50, 19.87}, // Room 5
  {6, 1766.63, -2496.37, 1798.82, -2479.75, 19.87}, // Room 6
  {7, 1725.41, -2512.94, 1757.62, -2496.50, 19.87}, // Room 7
  {8, 1725.43, -2496.37, 1757.62, -2479.75, 19.87}, // Room 8

  // 3rd Floor
  {9, 1766.61, -2512.94, 1798.82, -2496.50, 26.07}, // Room 9
  {10, 1766.63, -2496.37, 1798.82, -2479.75, 26.07}, // Room 10
  {11, 1725.41, -2512.94, 1757.62, -2496.50, 26.07}, // Room 11
  {12, 1725.43, -2496.37, 1757.62, -2479.75, 26.07}, // Room 12

  // 4th Floor
  {13, 1766.61, -2512.94, 1798.82, -2496.50, 32.24}, // Room 13
  {14, 1766.63, -2496.37, 1798.82, -2479.75, 32.24}, // Room 14
  {15, 1725.41, -2512.94, 1757.62, -2496.50, 32.24}, // Room 15
  {16, 1725.43, -2496.37, 1757.62, -2479.75, 32.24} // Room 16
};

new const FlatMediumInterior[][e_flatIntStructure] = {
  {1, 19449, 1431.664672, 1471.025024, 11.550304, 0.000000, 0.000000, 0.000000}, // Room 1 (Wall)
  {1, 19357, 1442.806884, 1466.124511, 11.550304, 0.000000, 0.000000, 90.000000}, // Room 1 (Wall)
  {1, 19357, 1439.617553, 1466.124511, 11.550304, 0.000000, 0.000000, 90.000000}, // Room 1 (Wall)
  {1, 19387, 1436.405883, 1466.124755, 11.550304, 0.000000, 0.000000, 90.000000}, // Room 1 (Wall)
  {1, 19357, 1433.197021, 1466.124511, 11.550304, 0.000000, 0.000000, 90.000000}, // Room 1 (Wall)
  {1, 19449, 1444.326660, 1471.025268, 11.550304, 0.000000, 0.000000, 0.000000}, // Room 1 (Wall)
  {1, 19449, 1444.326660, 1480.594970, 11.550304, 0.000000, 0.000000, 0.000000}, // Room 1 (Wall)
  {1, 19449, 1444.326660, 1490.205566, 11.550304, 0.000000, 0.000000, 0.000000}, // Room 1 (Wall)
  {1, 19449, 1431.664672, 1480.634765, 11.550304, 0.000000, 0.000000, 0.000000}, // Room 1 (Wall)
  {1, 19449, 1431.664672, 1490.255004, 11.550304, 0.000000, 0.000000, 0.000000}, // Room 1 (Wall)
  {1, 19357, 1436.386474, 1495.033691, 11.550304, 0.000000, 0.000000, 90.000000}, // Room 1 (Wall)
  {1, 19357, 1439.596679, 1495.033691, 11.550304, 0.000000, 0.000000, 90.000000}, // Room 1 (Wall)
  {1, 19357, 1442.796386, 1495.033691, 11.550304, 0.000000, 0.000000, 90.000000}, // Room 1 (Wall)
  {1, 19357, 1433.176635, 1495.033691, 11.550304, 0.000000, 0.000000, 90.000000}, // Room 1 (Wall)
  {1, 19379, 1436.962280, 1470.867797, 9.750000, 0.000000, 90.000000, 180.000000}, // Room 1 (Floor)
  {1, 19379, 1436.962280, 1480.498535, 9.750000, 0.000000, 90.000000, 180.000000}, // Room 1 (Floor)
  {1, 19379, 1436.962280, 1490.129394, 9.750000, 0.000000, 90.000000, 180.000000}, // Room 1 (Floor)
  {1, 19462, 1442.633789, 1471.026733, 9.740001, 0.000000, 90.000000, 0.000000}, // Room 1 (Floor)
  {1, 19462, 1442.633789, 1480.646728, 9.740001, 0.000000, 90.000000, 0.000000}, // Room 1 (Floor)
  {1, 19462, 1442.633789, 1490.277832, 9.740001, 0.000000, 90.000000, 0.000000}, // Room 1 (Floor)
  {1, 19379, 1436.962280, 1470.867797, 13.369991, 0.000000, 89.999992, 179.999954}, // Room 1 (Ceiling)
  {1, 19379, 1436.962280, 1480.498535, 13.369991, 0.000000, 89.999992, 179.999954}, // Room 1 (Ceiling)
  {1, 19379, 1436.962280, 1490.129394, 13.369991, 0.000000, 89.999992, 179.999954}, // Room 1 (Ceiling)
  {1, 19462, 1442.633789, 1470.866577, 13.359992, 0.000000, 89.999992, 0.000000}, // Room 1 (Ceiling)
  {1, 19462, 1442.633789, 1480.476562, 13.359992, 0.000000, 89.999992, 0.000000}, // Room 1 (Ceiling)
  {1, 19462, 1442.633789, 1490.127685, 13.359992, 0.000000, 89.999992, 0.000000}, // Room 1 (Ceiling)
  {2, 19449, 1444.474487, 1471.025024, 11.550304, 0.000000, 0.000007, 0.000000}, // Room 2 (Wall)
  {2, 19357, 1455.616699, 1466.124511, 11.550304, 0.000007, 0.000000, 89.999977}, // Room 2 (Wall)
  {2, 19357, 1452.427368, 1466.124511, 11.550304, 0.000007, 0.000000, 89.999977}, // Room 2 (Wall)
  {2, 19387, 1449.215698, 1466.124755, 11.550304, 0.000007, 0.000000, 89.999977}, // Room 2 (Wall)
  {2, 19357, 1446.006835, 1466.124511, 11.550304, 0.000007, 0.000000, 89.999977}, // Room 2 (Wall)
  {2, 19449, 1457.136474, 1471.025268, 11.550304, 0.000000, 0.000007, 0.000000}, // Room 2 (Wall)
  {2, 19449, 1457.136474, 1480.594970, 11.550304, 0.000000, 0.000007, 0.000000}, // Room 2 (Wall)
  {2, 19449, 1457.136474, 1490.205566, 11.550304, 0.000000, 0.000007, 0.000000}, // Room 2 (Wall)
  {2, 19449, 1444.474487, 1480.634765, 11.550304, 0.000000, 0.000007, 0.000000}, // Room 2 (Wall)
  {2, 19449, 1444.474487, 1490.255004, 11.550304, 0.000000, 0.000007, 0.000000}, // Room 2 (Wall)
  {2, 19357, 1449.196289, 1495.033691, 11.550304, 0.000007, 0.000000, 89.999977}, // Room 2 (Wall)
  {2, 19357, 1452.406494, 1495.033691, 11.550304, 0.000007, 0.000000, 89.999977}, // Room 2 (Wall)
  {2, 19357, 1455.606201, 1495.033691, 11.550304, 0.000007, 0.000000, 89.999977}, // Room 2 (Wall)
  {2, 19357, 1445.986450, 1495.033691, 11.550304, 0.000007, 0.000000, 89.999977}, // Room 2 (Wall)
  {2, 19379, 1449.772094, 1470.867797, 9.750000, 0.000000, 89.999992, 179.999954}, // Room 2 (Floor)
  {2, 19379, 1449.772094, 1480.498535, 9.750000, 0.000000, 89.999992, 179.999954}, // Room 2 (Floor)
  {2, 19379, 1449.772094, 1490.129394, 9.750000, 0.000000, 89.999992, 179.999954}, // Room 2 (Floor)
  {2, 19462, 1455.443603, 1471.026733, 9.740001, 0.000000, 89.999992, 0.000000}, // Room 2 (Floor)
  {2, 19462, 1455.443603, 1480.646728, 9.740001, 0.000000, 89.999992, 0.000000}, // Room 2 (Floor)
  {2, 19462, 1455.443603, 1490.277832, 9.740001, 0.000000, 89.999992, 0.000000}, // Room 2 (Floor)
  {2, 19379, 1449.772094, 1470.867797, 13.369991, 0.000000, 89.999984, 179.999908}, // Room 2 (Ceiling)
  {2, 19379, 1449.772094, 1480.498535, 13.369991, 0.000000, 89.999984, 179.999908}, // Room 2 (Ceiling)
  {2, 19379, 1449.772094, 1490.129394, 13.369991, 0.000000, 89.999984, 179.999908}, // Room 2 (Ceiling)
  {2, 19462, 1455.443603, 1470.866577, 13.359992, 0.000000, 89.999984, 0.000000}, // Room 2 (Ceiling)
  {2, 19462, 1455.443603, 1480.496582, 13.359992, 0.000000, 89.999984, 0.000000}, // Room 2 (Ceiling)
  {2, 19462, 1455.443603, 1490.127685, 13.359992, 0.000000, 90.000000, 0.000000}, // Room 2 (Ceiling)
  {3, 19449, 1441.126586, 1451.145874, 11.550304, 0.000000, 0.000000, 179.999771}, // Room 3 (Wall)
  {3, 19357, 1429.984375, 1456.046386, 11.550304, -0.000000, -0.000000, -90.000038}, // Room 3 (Wall)
  {3, 19357, 1433.173706, 1456.046386, 11.550304, -0.000000, -0.000000, -90.000038}, // Room 3 (Wall)
  {3, 19387, 1436.385375, 1456.046142, 11.550304, -0.000000, -0.000000, -90.000038}, // Room 3 (Wall)
  {3, 19357, 1439.594238, 1456.046386, 11.550304, -0.000000, -0.000000, -90.000038}, // Room 3 (Wall)
  {3, 19449, 1428.464599, 1451.145629, 11.550304, 0.000000, 0.000000, 179.999771}, // Room 3 (Wall)
  {3, 19449, 1428.464599, 1441.575927, 11.550304, 0.000000, 0.000000, 179.999771}, // Room 3 (Wall)
  {3, 19449, 1428.464599, 1431.965332, 11.550304, 0.000000, 0.000000, 179.999771}, // Room 3 (Wall)
  {3, 19449, 1441.126586, 1441.536132, 11.550304, 0.000000, 0.000000, 179.999771}, // Room 3 (Wall)
  {3, 19449, 1441.126586, 1431.915893, 11.550304, 0.000000, 0.000000, 179.999771}, // Room 3 (Wall)
  {3, 19357, 1436.404785, 1427.137207, 11.550304, -0.000000, -0.000000, -90.000038}, // Room 3 (Wall)
  {3, 19357, 1433.194580, 1427.137207, 11.550304, -0.000000, -0.000000, -90.000038}, // Room 3 (Wall)
  {3, 19357, 1429.994873, 1427.137207, 11.550304, -0.000000, -0.000000, -90.000038}, // Room 3 (Wall)
  {3, 19357, 1439.614624, 1427.137207, 11.550304, -0.000000, -0.000000, -90.000038}, // Room 3 (Wall)
  {3, 19379, 1435.828979, 1451.303100, 9.750000, -0.000000, 90.000000, -0.000137}, // Room 3 (Floor)
  {3, 19379, 1435.828979, 1441.672363, 9.750000, -0.000000, 90.000000, -0.000137}, // Room 3 (Floor)
  {3, 19379, 1435.828979, 1432.041503, 9.750000, -0.000000, 90.000000, -0.000137}, // Room 3 (Floor)
  {3, 19462, 1430.157470, 1451.144165, 9.740001, 0.000000, 90.000000, 179.999771}, // Room 3 (Floor)
  {3, 19462, 1430.157470, 1441.524169, 9.740001, 0.000000, 90.000000, 179.999771}, // Room 3 (Floor)
  {3, 19462, 1430.157470, 1431.893066, 9.740001, 0.000000, 90.000000, 179.999771}, // Room 3 (Floor)
  {3, 19379, 1435.828979, 1451.303100, 13.369991, -0.000000, 89.999992, -0.000183}, // Room 3 (Ceiling)
  {3, 19379, 1435.828979, 1441.672363, 13.369991, -0.000000, 89.999992, -0.000183}, // Room 3 (Ceiling)
  {3, 19379, 1435.828979, 1432.041503, 13.369991, -0.000000, 89.999992, -0.000183}, // Room 3 (Ceiling)
  {3, 19462, 1430.157470, 1451.304321, 13.359992, 0.000000, 89.999992, 179.999771}, // Room 3 (Ceiling)
  {3, 19462, 1430.157470, 1441.694335, 13.359992, 0.000000, 89.999992, 179.999771}, // Room 3 (Ceiling)
  {3, 19462, 1430.157470, 1432.063232, 13.359992, 0.000000, 89.999992, 179.999771}, // Room 3 (Ceiling)
  {4, 19449, 1453.938110, 1451.145874, 11.550304, 0.000000, -0.000007, 179.999725}, // Room 4 (Wall)
  {4, 19357, 1442.795898, 1456.046386, 11.550304, -0.000007, -0.000000, -90.000015}, // Room 4 (Wall)
  {4, 19357, 1445.985229, 1456.046386, 11.550304, -0.000007, -0.000000, -90.000015}, // Room 4 (Wall)
  {4, 19387, 1449.196899, 1456.046142, 11.550304, -0.000007, -0.000000, -90.000015}, // Room 4 (Wall)
  {4, 19357, 1452.405761, 1456.046386, 11.550304, -0.000007, -0.000000, -90.000015}, // Room 4 (Wall)
  {4, 19449, 1441.276123, 1451.145629, 11.550304, 0.000000, -0.000007, 179.999725}, // Room 4 (Wall)
  {4, 19449, 1441.276123, 1441.575927, 11.550304, 0.000000, -0.000007, 179.999725}, // Room 4 (Wall)
  {4, 19449, 1441.276123, 1431.965332, 11.550304, 0.000000, -0.000007, 179.999725}, // Room 4 (Wall)
  {4, 19449, 1453.938110, 1441.536132, 11.550304, 0.000000, -0.000007, 179.999725}, // Room 4 (Wall)
  {4, 19449, 1453.938110, 1431.915893, 11.550304, 0.000000, -0.000007, 179.999725}, // Room 4 (Wall)
  {4, 19357, 1449.216308, 1427.137207, 11.550304, -0.000007, -0.000000, -90.000015}, // Room 4 (Wall)
  {4, 19357, 1446.006103, 1427.137207, 11.550304, -0.000007, -0.000000, -90.000015}, // Room 4 (Wall)
  {4, 19357, 1442.806396, 1427.137207, 11.550304, -0.000007, -0.000000, -90.000015}, // Room 4 (Wall)
  {4, 19357, 1452.426147, 1427.137207, 11.550304, -0.000007, -0.000000, -90.000015}, // Room 4 (Wall)
  {4, 19379, 1448.640502, 1451.303100, 9.750000, -0.000000, 90.000007, -0.000137}, // Room 4 (Floor)
  {4, 19379, 1448.640502, 1441.672363, 9.750000, -0.000000, 90.000007, -0.000137}, // Room 4 (Floor)
  {4, 19379, 1448.640502, 1432.041503, 9.750000, -0.000000, 90.000007, -0.000137}, // Room 4 (Floor)
  {4, 19462, 1442.968994, 1451.144165, 9.740001, 0.000000, 89.999992, 179.999725}, // Room 4 (Floor)
  {4, 19462, 1442.968994, 1441.524169, 9.740001, 0.000000, 89.999992, 179.999725}, // Room 4 (Floor)
  {4, 19462, 1442.968994, 1431.893066, 9.740001, 0.000000, 89.999992, 179.999725}, // Room 4 (Floor)
  {4, 19379, 1448.640502, 1451.303100, 13.369991, -0.000000, 90.000000, -0.000183}, // Room 4 (Ceiling)
  {4, 19379, 1448.640502, 1441.672363, 13.369991, -0.000000, 90.000000, -0.000183}, // Room 4 (Ceiling)
  {4, 19379, 1448.640502, 1432.041503, 13.369991, -0.000000, 90.000000, -0.000183}, // Room 4 (Ceiling)
  {4, 19462, 1442.968994, 1451.304321, 13.359992, 0.000000, 89.999984, 179.999725}, // Room 4 (Ceiling)
  {4, 19462, 1442.968994, 1441.694335, 13.359992, 0.000000, 89.999984, 179.999725}, // Room 4 (Ceiling)
  {4, 19462, 1442.968994, 1432.063232, 13.359992, 0.000000, 89.999984, 179.999725}, // Room 4 (Ceiling)
  {5, 19449, 1464.763793, 1453.280639, 17.310300, -0.000007, -0.000015, -90.000183}, // Room 5 (Wall)
  {5, 19357, 1459.863281, 1442.138427, 17.310300, -0.000015, 0.000007, 0.000152}, // Room 5 (Wall)
  {5, 19357, 1459.863281, 1445.327758, 17.310300, -0.000015, 0.000007, 0.000152}, // Room 5 (Wall)
  {5, 19387, 1459.863525, 1448.539428, 17.310300, -0.000015, 0.000007, 0.000152}, // Room 5 (Wall)
  {5, 19357, 1459.863281, 1451.748291, 17.310300, -0.000015, 0.000007, 0.000152}, // Room 5 (Wall)
  {5, 19449, 1464.764038, 1440.618652, 17.310300, -0.000007, -0.000015, -90.000183}, // Room 5 (Wall)
  {5, 19449, 1474.333740, 1440.618652, 17.310300, -0.000007, -0.000015, -90.000183}, // Room 5 (Wall)
  {5, 19449, 1483.944335, 1440.618652, 17.310300, -0.000007, -0.000015, -90.000183}, // Room 5 (Wall)
  {5, 19449, 1474.373535, 1453.280639, 17.310300, -0.000007, -0.000015, -90.000183}, // Room 5 (Wall)
  {5, 19449, 1483.993774, 1453.280639, 17.310300, -0.000007, -0.000015, -90.000183}, // Room 5 (Wall)
  {5, 19357, 1488.772460, 1448.558837, 17.310300, -0.000015, 0.000007, 0.000152}, // Room 5 (Wall)
  {5, 19357, 1488.772460, 1445.348632, 17.310300, -0.000015, 0.000007, 0.000152}, // Room 5 (Wall)
  {5, 19357, 1488.772460, 1442.148925, 17.310300, -0.000015, 0.000007, 0.000152}, // Room 5 (Wall)
  {5, 19357, 1488.772460, 1451.768676, 17.310300, -0.000015, 0.000007, 0.000152}, // Room 5 (Wall)
  {5, 19379, 1464.606567, 1447.983032, 15.509996, 0.000007, 90.000015, 89.999862}, // Room 5 (Floor)
  {5, 19379, 1474.237304, 1447.983032, 15.509996, 0.000007, 90.000015, 89.999862}, // Room 5 (Floor)
  {5, 19379, 1483.868164, 1447.983032, 15.509996, 0.000007, 90.000015, 89.999862}, // Room 5 (Floor)
  {5, 19462, 1464.765502, 1442.311523, 15.499998, -0.000007, 89.999984, -90.000183}, // Room 5 (Floor)
  {5, 19462, 1474.385498, 1442.311523, 15.499998, -0.000007, 89.999984, -90.000183}, // Room 5 (Floor)
  {5, 19462, 1484.016601, 1442.311523, 15.499998, -0.000007, 89.999984, -90.000183}, // Room 5 (Floor)
  {5, 19379, 1464.606567, 1447.983032, 19.129987, 0.000007, 90.000007, 89.999816}, // Room 5 (Ceiling)
  {5, 19379, 1474.237304, 1447.983032, 19.129987, 0.000007, 90.000007, 89.999816}, // Room 5 (Ceiling)
  {5, 19379, 1483.868164, 1447.983032, 19.129987, 0.000007, 90.000007, 89.999816}, // Room 5 (Ceiling)
  {5, 19462, 1464.605346, 1442.311523, 19.119989, -0.000007, 89.999977, -90.000183}, // Room 5 (Ceiling)
  {5, 19462, 1474.215332, 1442.311523, 19.119989, -0.000007, 89.999977, -90.000183}, // Room 5 (Ceiling)
  {5, 19462, 1483.846435, 1442.311523, 19.119989, -0.000007, 89.999977, -90.000183}, // Room 5 (Ceiling)
  {6, 19449, 1464.763793, 1440.460815, 17.310300, 0.000000, -0.000015, -90.000205}, // Room 6 (Wall)
  {6, 19357, 1459.863281, 1429.318603, 17.310300, -0.000015, 0.000000, 0.000152}, // Room 6 (Wall)
  {6, 19357, 1459.863281, 1432.507934, 17.310300, -0.000015, 0.000000, 0.000152}, // Room 6 (Wall)
  {6, 19387, 1459.863525, 1435.719604, 17.310300, -0.000015, 0.000000, 0.000152}, // Room 6 (Wall)
  {6, 19357, 1459.863281, 1438.928466, 17.310300, -0.000015, 0.000000, 0.000152}, // Room 6 (Wall)
  {6, 19449, 1464.764038, 1427.798828, 17.310300, 0.000000, -0.000015, -90.000205}, // Room 6 (Wall)
  {6, 19449, 1474.333740, 1427.798828, 17.310300, 0.000000, -0.000015, -90.000205}, // Room 6 (Wall)
  {6, 19449, 1483.944335, 1427.798828, 17.310300, 0.000000, -0.000015, -90.000205}, // Room 6 (Wall)
  {6, 19449, 1474.373535, 1440.460815, 17.310300, 0.000000, -0.000015, -90.000205}, // Room 6 (Wall)
  {6, 19449, 1483.993774, 1440.460815, 17.310300, 0.000000, -0.000015, -90.000205}, // Room 6 (Wall)
  {6, 19357, 1488.772460, 1435.739013, 17.310300, -0.000015, 0.000000, 0.000152}, // Room 6 (Wall)
  {6, 19357, 1488.772460, 1432.528808, 17.310300, -0.000015, 0.000000, 0.000152}, // Room 6 (Wall)
  {6, 19357, 1488.772460, 1429.329101, 17.310300, -0.000015, 0.000000, 0.000152}, // Room 6 (Wall)
  {6, 19357, 1488.772460, 1438.948852, 17.310300, -0.000015, 0.000000, 0.000152}, // Room 6 (Wall)
  {6, 19379, 1464.606567, 1435.163208, 15.509996, -0.000000, 90.000015, 89.999885}, // Room 6 (Floor)
  {6, 19379, 1474.237304, 1435.163208, 15.509996, -0.000000, 90.000015, 89.999885}, // Room 6 (Floor)
  {6, 19379, 1483.868164, 1435.163208, 15.509996, -0.000000, 90.000015, 89.999885}, // Room 6 (Floor)
  {6, 19462, 1464.765502, 1429.491699, 15.499998, 0.000000, 89.999984, -90.000205}, // Room 6 (Floor)
  {6, 19462, 1474.385498, 1429.491699, 15.499998, 0.000000, 89.999984, -90.000205}, // Room 6 (Floor)
  {6, 19462, 1484.016601, 1429.491699, 15.499998, 0.000000, 89.999984, -90.000205}, // Room 6 (Floor)
  {6, 19379, 1464.606567, 1435.163208, 19.129987, -0.000000, 90.000007, 89.999839}, // Room 6 (Ceiling)
  {6, 19379, 1474.237304, 1435.163208, 19.129987, -0.000000, 90.000007, 89.999839}, // Room 6 (Ceiling)
  {6, 19379, 1483.868164, 1435.163208, 19.129987, -0.000000, 90.000007, 89.999839}, // Room 6 (Ceiling)
  {6, 19462, 1464.605346, 1429.491699, 19.119989, 0.000000, 89.999977, -90.000205}, // Room 6 (Ceiling)
  {6, 19462, 1474.215332, 1429.491699, 19.119989, 0.000000, 89.999977, -90.000205}, // Room 6 (Ceiling)
  {6, 19462, 1483.846435, 1429.491699, 19.119989, 0.000000, 89.999977, -90.000205}, // Room 6 (Ceiling)
  {7, 19449, 1444.899536, 1443.818115, 17.310300, -0.000007, -0.000015, 89.999832}, // Room 7 (Wall)
  {7, 19357, 1449.800048, 1454.960327, 17.310300, -0.000015, 0.000007, -179.999877}, // Room 7 (Wall)
  {7, 19357, 1449.800048, 1451.770996, 17.310300, -0.000015, 0.000007, -179.999877}, // Room 7 (Wall)
  {7, 19387, 1449.799804, 1448.559326, 17.310300, -0.000015, 0.000007, -179.999877}, // Room 7 (Wall)
  {7, 19357, 1449.800048, 1445.350463, 17.310300, -0.000015, 0.000007, -179.999877}, // Room 7 (Wall)
  {7, 19449, 1444.899291, 1456.480102, 17.310300, -0.000007, -0.000015, 89.999832}, // Room 7 (Wall)
  {7, 19449, 1435.329589, 1456.480102, 17.310300, -0.000007, -0.000015, 89.999832}, // Room 7 (Wall)
  {7, 19449, 1425.718994, 1456.480102, 17.310300, -0.000007, -0.000015, 89.999832}, // Room 7 (Wall)
  {7, 19449, 1435.289794, 1443.818115, 17.310300, -0.000007, -0.000015, 89.999832}, // Room 7 (Wall)
  {7, 19449, 1425.669555, 1443.818115, 17.310300, -0.000007, -0.000015, 89.999832}, // Room 7 (Wall)
  {7, 19357, 1420.890869, 1448.539916, 17.310300, -0.000015, 0.000007, -179.999877}, // Room 7 (Wall)
  {7, 19357, 1420.890869, 1451.750122, 17.310300, -0.000015, 0.000007, -179.999877}, // Room 7 (Wall)
  {7, 19357, 1420.890869, 1454.949829, 17.310300, -0.000015, 0.000007, -179.999877}, // Room 7 (Wall)
  {7, 19357, 1420.890869, 1445.330078, 17.310300, -0.000015, 0.000007, -179.999877}, // Room 7 (Wall)
  {7, 19379, 1445.056762, 1449.115722, 15.509996, 0.000007, 90.000015, -90.000038}, // Room 7 (Floor)
  {7, 19379, 1435.426025, 1449.115722, 15.509996, 0.000007, 90.000015, -90.000038}, // Room 7 (Floor)
  {7, 19379, 1425.795166, 1449.115722, 15.509996, 0.000007, 90.000015, -90.000038}, // Room 7 (Floor)
  {7, 19462, 1444.897827, 1454.787231, 15.499998, -0.000007, 89.999984, 89.999832}, // Room 7 (Floor)
  {7, 19462, 1435.277832, 1454.787231, 15.499998, -0.000007, 89.999984, 89.999832}, // Room 7 (Floor)
  {7, 19462, 1425.646728, 1454.787231, 15.499998, -0.000007, 89.999984, 89.999832}, // Room 7 (Ceiling)
  {7, 19379, 1445.056762, 1449.115722, 19.129987, 0.000007, 90.000007, -90.000083}, // Room 7 (Ceiling)
  {7, 19379, 1435.426025, 1449.115722, 19.129987, 0.000007, 90.000007, -90.000083}, // Room 7 (Ceiling)
  {7, 19379, 1425.795166, 1449.115722, 19.129987, 0.000007, 90.000007, -90.000083}, // Room 7 (Ceiling)
  {7, 19462, 1445.057983, 1454.787231, 19.119989, -0.000007, 89.999977, 89.999832}, // Room 7 (Ceiling)
  {7, 19462, 1435.447998, 1454.787231, 19.119989, -0.000007, 89.999977, 89.999832}, // Room 7 (Ceiling)
  {7, 19462, 1425.816894, 1454.787231, 19.119989, -0.000007, 89.999977, 89.999832}, // Room 7 (Ceiling)
  {8, 19449, 1444.899536, 1430.978637, 17.310300, 0.000000, -0.000015, 89.999809}, // Room 8 (Wall)
  {8, 19357, 1449.800048, 1442.120849, 17.310300, -0.000015, 0.000000, -179.999832}, // Room 8 (Wall)
  {8, 19357, 1449.800048, 1438.931518, 17.310300, -0.000015, 0.000000, -179.999832}, // Room 8 (Wall)
  {8, 19387, 1449.799804, 1435.719848, 17.310300, -0.000015, 0.000000, -179.999832}, // Room 8 (Wall)
  {8, 19357, 1449.800048, 1432.510986, 17.310300, -0.000015, 0.000000, -179.999832}, // Room 8 (Wall)
  {8, 19449, 1444.899291, 1443.640625, 17.310300, 0.000000, -0.000015, 89.999809}, // Room 8 (Wall)
  {8, 19449, 1435.329589, 1443.640625, 17.310300, 0.000000, -0.000015, 89.999809}, // Room 8 (Wall)
  {8, 19449, 1425.718994, 1443.640625, 17.310300, 0.000000, -0.000015, 89.999809}, // Room 8 (Wall)
  {8, 19449, 1435.289794, 1430.978637, 17.310300, 0.000000, -0.000015, 89.999809}, // Room 8 (Wall)
  {8, 19449, 1425.669555, 1430.978637, 17.310300, 0.000000, -0.000015, 89.999809}, // Room 8 (Wall)
  {8, 19357, 1420.890869, 1435.700439, 17.310300, -0.000015, 0.000000, -179.999832}, // Room 8 (Wall)
  {8, 19357, 1420.890869, 1438.910644, 17.310300, -0.000015, 0.000000, -179.999832}, // Room 8 (Wall)
  {8, 19357, 1420.890869, 1442.110351, 17.310300, -0.000015, 0.000000, -179.999832}, // Room 8 (Wall)
  {8, 19357, 1420.890869, 1432.490600, 17.310300, -0.000015, 0.000000, -179.999832}, // Room 8 (Wall)
  {8, 19379, 1445.056762, 1436.276245, 15.509996, -0.000000, 90.000015, -90.000015}, // Room 8 (Floor)
  {8, 19379, 1435.426025, 1436.276245, 15.509996, -0.000000, 90.000015, -90.000015}, // Room 8 (Floor)
  {8, 19379, 1425.795166, 1436.276245, 15.509996, -0.000000, 90.000015, -90.000015}, // Room 8 (Floor)
  {8, 19462, 1444.897827, 1441.947753, 15.499998, 0.000000, 89.999984, 89.999809}, // Room 8 (Floor)
  {8, 19462, 1435.277832, 1441.947753, 15.499998, 0.000000, 89.999984, 89.999809}, // Room 8 (Floor)
  {8, 19462, 1425.646728, 1441.947753, 15.499998, 0.000000, 89.999984, 89.999809}, // Room 8 (Floor)
  {8, 19379, 1445.056762, 1436.276245, 19.129987, -0.000000, 90.000007, -90.000061}, // Room 8 (Ceiling)
  {8, 19379, 1435.426025, 1436.276245, 19.129987, -0.000000, 90.000007, -90.000061}, // Room 8 (Ceiling)
  {8, 19379, 1425.795166, 1436.276245, 19.129987, -0.000000, 90.000007, -90.000061}, // Room 8 (Ceiling)
  {8, 19462, 1445.057983, 1441.947753, 19.119989, 0.000000, 89.999977, 89.999809}, // Room 8 (Ceiling)
  {8, 19462, 1435.447998, 1441.947753, 19.119989, 0.000000, 89.999977, 89.999809}, // Room 8 (Ceiling)
  {8, 19462, 1425.816894, 1441.947753, 19.119989, 0.000000, 89.999977, 89.999809}, // Room 8 (Ceiling)
  {9, 19449, 1464.743774, 1453.280639, 23.170299, -0.000007, -0.000015, -90.000183}, // Room 9 (Wall)
  {9, 19357, 1459.843261, 1442.138427, 23.170299, -0.000015, 0.000007, 0.000152}, // Room 9 (Wall)
  {9, 19357, 1459.843261, 1445.327758, 23.170299, -0.000015, 0.000007, 0.000152}, // Room 9 (Wall)
  {9, 19387, 1459.843505, 1448.539428, 23.170299, -0.000015, 0.000007, 0.000152}, // Room 9 (Wall)
  {9, 19357, 1459.843261, 1451.748291, 23.170299, -0.000015, 0.000007, 0.000152}, // Room 9 (Wall)
  {9, 19449, 1464.744018, 1440.618652, 23.170299, -0.000007, -0.000015, -90.000183}, // Room 9 (Wall)
  {9, 19449, 1474.313720, 1440.618652, 23.170299, -0.000007, -0.000015, -90.000183}, // Room 9 (Wall)
  {9, 19449, 1483.924316, 1440.618652, 23.170299, -0.000007, -0.000015, -90.000183}, // Room 9 (Wall)
  {9, 19449, 1474.353515, 1453.280639, 23.170299, -0.000007, -0.000015, -90.000183}, // Room 9 (Wall)
  {9, 19449, 1483.973754, 1453.280639, 23.170299, -0.000007, -0.000015, -90.000183}, // Room 9 (Wall)
  {9, 19357, 1488.752441, 1448.558837, 23.170299, -0.000015, 0.000007, 0.000152}, // Room 9 (Wall)
  {9, 19357, 1488.752441, 1445.348632, 23.170299, -0.000015, 0.000007, 0.000152}, // Room 9 (Wall)
  {9, 19357, 1488.752441, 1442.148925, 23.170299, -0.000015, 0.000007, 0.000152}, // Room 9 (Wall)
  {9, 19357, 1488.752441, 1451.768676, 23.170299, -0.000015, 0.000007, 0.000152}, // Room 9 (Wall)
  {9, 19379, 1464.586547, 1447.983032, 21.369995, 0.000007, 90.000015, 89.999862}, // Room 9 (Floor)
  {9, 19379, 1474.217285, 1447.983032, 21.369995, 0.000007, 90.000015, 89.999862}, // Room 9 (Floor)
  {9, 19379, 1483.848144, 1447.983032, 21.369995, 0.000007, 90.000015, 89.999862}, // Room 9 (Floor)
  {9, 19462, 1464.745483, 1442.311523, 21.359996, -0.000007, 89.999984, -90.000183}, // Room 9 (Floor)
  {9, 19462, 1474.365478, 1442.311523, 21.359996, -0.000007, 89.999984, -90.000183}, // Room 9 (Floor)
  {9, 19462, 1483.996582, 1442.311523, 21.359996, -0.000007, 89.999984, -90.000183}, // Room 9 (Floor)
  {9, 19379, 1464.586547, 1447.983032, 24.989986, 0.000007, 90.000007, 89.999816}, // Room 9 (Ceiling)
  {9, 19379, 1474.217285, 1447.983032, 24.989986, 0.000007, 90.000007, 89.999816}, // Room 9 (Ceiling)
  {9, 19379, 1483.848144, 1447.983032, 24.989986, 0.000007, 90.000007, 89.999816}, // Room 9 (Ceiling)
  {9, 19462, 1464.585327, 1442.311523, 24.979988, -0.000007, 89.999977, -90.000183}, // Room 9 (Ceiling)
  {9, 19462, 1474.195312, 1442.311523, 24.979988, -0.000007, 89.999977, -90.000183}, // Room 9 (Ceiling)
  {9, 19462, 1483.826416, 1442.311523, 24.979988, -0.000007, 89.999977, -90.000183}, // Room 9 (Ceiling)
  {10, 19449, 1464.743774, 1440.469604, 23.140298, -0.000015, -0.000015, -90.000160}, // Room 10 (Wall)
  {10, 19357, 1459.843261, 1429.327392, 23.140298, -0.000015, 0.000015, 0.000152}, // Room 10 (Wall)
  {10, 19357, 1459.843261, 1432.516723, 23.140298, -0.000015, 0.000015, 0.000152}, // Room 10 (Wall)
  {10, 19387, 1459.843505, 1435.728393, 23.140298, -0.000015, 0.000015, 0.000152}, // Room 10 (Wall)
  {10, 19357, 1459.843261, 1438.937255, 23.140298, -0.000015, 0.000015, 0.000152}, // Room 10 (Wall)
  {10, 19449, 1464.744018, 1427.807617, 23.140298, -0.000015, -0.000015, -90.000160}, // Room 10 (Wall)
  {10, 19449, 1474.313720, 1427.807617, 23.140298, -0.000015, -0.000015, -90.000160}, // Room 10 (Wall)
  {10, 19449, 1483.924316, 1427.807617, 23.140298, -0.000015, -0.000015, -90.000160}, // Room 10 (Wall)
  {10, 19449, 1474.353515, 1440.469604, 23.140298, -0.000015, -0.000015, -90.000160}, // Room 10 (Wall)
  {10, 19449, 1483.973754, 1440.469604, 23.140298, -0.000015, -0.000015, -90.000160}, // Room 10 (Wall)
  {10, 19357, 1488.752441, 1435.747802, 23.140298, -0.000015, 0.000015, 0.000152}, // Room 10 (Wall)
  {10, 19357, 1488.752441, 1432.537597, 23.140298, -0.000015, 0.000015, 0.000152}, // Room 10 (Wall)
  {10, 19357, 1488.752441, 1429.337890, 23.140298, -0.000015, 0.000015, 0.000152}, // Room 10 (Wall)
  {10, 19357, 1488.752441, 1438.957641, 23.140298, -0.000015, 0.000015, 0.000152}, // Room 10 (Wall)
  {10, 19379, 1464.586547, 1435.171997, 21.339994, 0.000015, 90.000015, 89.999839}, // Room 10 (Floor)
  {10, 19379, 1474.217285, 1435.171997, 21.339994, 0.000015, 90.000015, 89.999839}, // Room 10 (Floor)
  {10, 19379, 1483.848144, 1435.171997, 21.339994, 0.000015, 90.000015, 89.999839}, // Room 10 (Floor)
  {10, 19462, 1464.745483, 1429.500488, 21.329996, -0.000015, 89.999984, -90.000160}, // Room 10 (Floor)
  {10, 19462, 1474.365478, 1429.500488, 21.329996, -0.000015, 89.999984, -90.000160}, // Room 10 (Floor)
  {10, 19462, 1483.996582, 1429.500488, 21.329996, -0.000015, 89.999984, -90.000160}, // Room 10 (Floor)
  {10, 19379, 1464.586547, 1435.171997, 24.959985, 0.000015, 90.000007, 89.999794}, // Room 10 (Ceiling)
  {10, 19379, 1474.217285, 1435.171997, 24.959985, 0.000015, 90.000007, 89.999794}, // Room 10 (Ceiling)
  {10, 19379, 1483.848144, 1435.171997, 24.959985, 0.000015, 90.000007, 89.999794}, // Room 10 (Ceiling)
  {10, 19462, 1464.585327, 1429.500488, 24.949987, -0.000015, 89.999977, -90.000160}, // Room 10 (Ceiling)
  {10, 19462, 1474.195312, 1429.500488, 24.949987, -0.000015, 89.999977, -90.000160}, // Room 10 (Ceiling)
  {10, 19462, 1483.826416, 1429.500488, 24.949987, -0.000015, 89.999977, -90.000160}, // Room 10 (Ceiling)
  {11, 19449, 1444.909667, 1443.828979, 23.140298, -0.000030, -0.000000, 89.999595}, // Room 11 (Wall)
  {11, 19357, 1449.810180, 1454.971191, 23.140298, 0.000000, 0.000030, -179.999771}, // Room 11 (Wall)
  {11, 19357, 1449.810180, 1451.781860, 23.140298, 0.000000, 0.000030, -179.999771}, // Room 11 (Wall)
  {11, 19387, 1449.809936, 1448.570190, 23.140298, 0.000000, 0.000030, -179.999771}, // Room 11 (Wall)
  {11, 19357, 1449.810180, 1445.361328, 23.140298, 0.000000, 0.000030, -179.999771}, // Room 11 (Wall)
  {11, 19449, 1444.909423, 1456.490966, 23.140298, -0.000030, -0.000000, 89.999595}, // Room 11 (Wall)
  {11, 19449, 1435.339721, 1456.490966, 23.140298, -0.000030, -0.000000, 89.999595}, // Room 11 (Wall)
  {11, 19449, 1425.729125, 1456.490966, 23.140298, -0.000030, -0.000000, 89.999595}, // Room 11 (Wall)
  {11, 19449, 1435.299926, 1443.828979, 23.140298, -0.000030, -0.000000, 89.999595}, // Room 11 (Wall)
  {11, 19449, 1425.679687, 1443.828979, 23.140298, -0.000030, -0.000000, 89.999595}, // Room 11 (Wall)
  {11, 19357, 1420.901000, 1448.550781, 23.140298, 0.000000, 0.000030, -179.999771}, // Room 11 (Wall)
  {11, 19357, 1420.901000, 1451.760986, 23.140298, 0.000000, 0.000030, -179.999771}, // Room 11 (Wall)
  {11, 19357, 1420.901000, 1454.960693, 23.140298, 0.000000, 0.000030, -179.999771}, // Room 11 (Wall)
  {11, 19357, 1420.901000, 1445.340942, 23.140298, 0.000000, 0.000030, -179.999771}, // Room 11 (Wall)
  {11, 19379, 1445.066894, 1449.126586, 21.339994, 0.000030, 90.000000, -90.000495}, // Room 11 (Floor)
  {11, 19379, 1435.436157, 1449.126586, 21.339994, 0.000030, 90.000000, -90.000495}, // Room 11 (Floor)
  {11, 19379, 1425.805297, 1449.126586, 21.339994, 0.000030, 90.000000, -90.000495}, // Room 11 (Floor)
  {11, 19462, 1444.907958, 1454.798095, 21.329996, -0.000030, 90.000000, 89.999595}, // Room 11 (Floor)
  {11, 19462, 1435.287963, 1454.798095, 21.329996, -0.000030, 90.000000, 89.999595}, // Room 11 (Floor)
  {11, 19462, 1425.656860, 1454.798095, 21.329996, -0.000030, 90.000000, 89.999595}, // Room 11 (Floor)
  {11, 19379, 1445.066894, 1449.126586, 24.959985, 0.000030, 89.999992, -90.000541}, // Room 11 (Ceiling)
  {11, 19379, 1435.436157, 1449.126586, 24.959985, 0.000030, 89.999992, -90.000541}, // Room 11 (Ceiling)
  {11, 19379, 1425.805297, 1449.126586, 24.959985, 0.000030, 89.999992, -90.000541}, // Room 11 (Ceiling)
  {11, 19462, 1445.068115, 1454.798095, 24.949987, -0.000030, 89.999992, 89.999595}, // Room 11 (Ceiling)
  {11, 19462, 1435.458129, 1454.798095, 24.949987, -0.000030, 89.999992, 89.999595}, // Room 11 (Ceiling)
  {11, 19462, 1425.827026, 1454.798095, 24.949987, -0.000030, 89.999992, 89.999595}, // Room 11 (Ceiling)
  {12, 19449, 1444.909667, 1430.988647, 23.140298, -0.000038, -0.000000, 89.999618}, // Room 12 (Wall)
  {12, 19357, 1449.810180, 1442.130859, 23.140298, 0.000000, 0.000038, -179.999816}, // Room 12 (Wall)
  {12, 19357, 1449.810180, 1438.941528, 23.140298, 0.000000, 0.000038, -179.999816}, // Room 12 (Wall)
  {12, 19387, 1449.809936, 1435.729858, 23.140298, 0.000000, 0.000038, -179.999816}, // Room 12 (Wall)
  {12, 19357, 1449.810180, 1432.520996, 23.140298, 0.000000, 0.000038, -179.999816}, // Room 12 (Wall)
  {12, 19449, 1444.909423, 1443.650634, 23.140298, -0.000038, -0.000000, 89.999618}, // Room 12 (Wall)
  {12, 19449, 1435.339721, 1443.650634, 23.140298, -0.000038, -0.000000, 89.999618}, // Room 12 (Wall)
  {12, 19449, 1425.729125, 1443.650634, 23.140298, -0.000038, -0.000000, 89.999618}, // Room 12 (Wall)
  {12, 19449, 1435.299926, 1430.988647, 23.140298, -0.000038, -0.000000, 89.999618}, // Room 12 (Wall)
  {12, 19449, 1425.679687, 1430.988647, 23.140298, -0.000038, -0.000000, 89.999618}, // Room 12 (Wall)
  {12, 19357, 1420.901000, 1435.710449, 23.140298, 0.000000, 0.000038, -179.999816}, // Room 12 (Wall)
  {12, 19357, 1420.901000, 1438.920654, 23.140298, 0.000000, 0.000038, -179.999816}, // Room 12 (Wall)
  {12, 19357, 1420.901000, 1442.120361, 23.140298, 0.000000, 0.000038, -179.999816}, // Room 12 (Wall)
  {12, 19357, 1420.901000, 1432.500610, 23.140298, 0.000000, 0.000038, -179.999816}, // Room 12 (Wall)
  {12, 19379, 1445.066894, 1436.286254, 21.339994, 0.000038, 90.000000, -90.000518}, // Room 12 (Floor)
  {12, 19379, 1435.436157, 1436.286254, 21.339994, 0.000038, 90.000000, -90.000518}, // Room 12 (Floor)
  {12, 19379, 1425.805297, 1436.286254, 21.339994, 0.000038, 90.000000, -90.000518}, // Room 12 (Floor)
  {12, 19462, 1444.907958, 1441.957763, 21.329996, -0.000038, 90.000000, 89.999618}, // Room 12 (Floor)
  {12, 19462, 1435.287963, 1441.957763, 21.329996, -0.000038, 90.000000, 89.999618}, // Room 12 (Floor)
  {12, 19462, 1425.656860, 1441.957763, 21.329996, -0.000038, 90.000000, 89.999618}, // Room 12 (Floor)
  {12, 19379, 1445.066894, 1436.286254, 24.959985, 0.000038, 89.999992, -90.000564}, // Room 12 (Ceiling)
  {12, 19379, 1435.436157, 1436.286254, 24.959985, 0.000038, 89.999992, -90.000564}, // Room 12 (Ceiling)
  {12, 19379, 1425.805297, 1436.286254, 24.959985, 0.000038, 89.999992, -90.000564}, // Room 12 (Ceiling)
  {12, 19462, 1445.068115, 1441.957763, 24.949987, -0.000038, 89.999992, 89.999618}, // Room 12 (Ceiling)
  {12, 19462, 1435.458129, 1441.957763, 24.949987, -0.000038, 89.999992, 89.999618}, // Room 12 (Ceiling)
  {12, 19462, 1425.827026, 1441.957763, 24.949987, -0.000038, 89.999992, 89.999618}, // Room 12 (Ceiling)
  {13, 19449, 1464.758300, 1453.974975, 28.940301, -0.000013, 0.000007, -90.000579}, // Room 13 (Wall)
  {13, 19357, 1459.857666, 1442.832885, 28.940301, 0.000007, 0.000013, 0.000335}, // Room 13 (Wall)
  {13, 19357, 1459.857666, 1446.022094, 28.940301, 0.000007, 0.000013, 0.000335}, // Room 13 (Wall)
  {13, 19387, 1459.857910, 1449.233886, 28.940301, 0.000007, 0.000013, 0.000335}, // Room 13 (Wall)
  {13, 19357, 1459.857666, 1452.442626, 28.940301, 0.000007, 0.000013, 0.000335}, // Room 13 (Wall)
  {13, 19449, 1464.758544, 1441.313110, 28.940301, -0.000013, 0.000007, -90.000579}, // Room 13 (Wall)
  {13, 19449, 1474.328125, 1441.313110, 28.940301, -0.000013, 0.000007, -90.000579}, // Room 13 (Wall)
  {13, 19449, 1483.938842, 1441.312988, 28.940301, -0.000013, 0.000007, -90.000579}, // Room 13 (Wall)
  {13, 19449, 1474.368164, 1453.975097, 28.940301, -0.000013, 0.000007, -90.000579}, // Room 13 (Wall)
  {13, 19449, 1483.988037, 1453.974975, 28.940301, -0.000013, 0.000007, -90.000579}, // Room 13 (Wall)
  {13, 19357, 1488.766845, 1449.253295, 28.940301, 0.000007, 0.000013, 0.000335}, // Room 13 (Wall)
  {13, 19357, 1488.766845, 1446.043090, 28.940301, 0.000007, 0.000013, 0.000335}, // Room 13 (Wall)
  {13, 19357, 1488.766845, 1442.843383, 28.940301, 0.000007, 0.000013, 0.000335}, // Room 13 (Wall)
  {13, 19357, 1488.766845, 1452.463134, 28.940301, 0.000007, 0.000013, 0.000335}, // Room 13 (Wall)
  {13, 19379, 1464.600830, 1448.677612, 27.139997, 0.000013, 90.000000, 89.999374}, // Room 13 (Floor)
  {13, 19379, 1474.231933, 1448.677612, 27.139997, 0.000013, 90.000000, 89.999374}, // Room 13 (Floor)
  {13, 19379, 1483.862792, 1448.677612, 27.139997, 0.000013, 90.000000, 89.999374}, // Room 13 (Floor)
  {13, 19462, 1464.760009, 1443.005981, 27.129999, -0.000013, 90.000000, -90.000579}, // Room 13 (Floor)
  {13, 19462, 1474.379882, 1443.005981, 27.129999, -0.000013, 90.000000, -90.000579}, // Room 13 (Floor)
  {13, 19462, 1484.010986, 1443.005981, 27.129999, -0.000013, 90.000000, -90.000579}, // Room 13 (Floor)
  {13, 19379, 1464.600830, 1448.677612, 30.759988, 0.000013, 89.999992, 89.999313}, // Room 13 (Ceiling)
  {13, 19379, 1474.231933, 1448.677612, 30.759988, 0.000013, 89.999992, 89.999313}, // Room 13 (Ceiling)
  {13, 19379, 1483.862792, 1448.677612, 30.759988, 0.000013, 89.999992, 89.999313}, // Room 13 (Ceiling)
  {13, 19462, 1464.599853, 1443.005981, 30.749990, -0.000013, 89.999992, -90.000579}, // Room 13 (Ceiling)
  {13, 19462, 1474.209716, 1443.005859, 30.749990, -0.000013, 89.999992, -90.000579}, // Room 13 (Ceiling)
  {13, 19462, 1483.840820, 1443.005859, 30.749990, -0.000013, 89.999992, -90.000579}, // Room 13 (Ceiling)
  {14, 19449, 1464.758300, 1441.162231, 28.940301, -0.000005, 0.000007, -90.000602}, // Room 14 (Wall)
  {14, 19357, 1459.857666, 1430.020141, 28.940301, 0.000007, 0.000005, 0.000335}, // Room 14 (Wall)
  {14, 19357, 1459.857666, 1433.209350, 28.940301, 0.000007, 0.000005, 0.000335}, // Room 14 (Wall)
  {14, 19387, 1459.857910, 1436.421142, 28.940301, 0.000007, 0.000005, 0.000335}, // Room 14 (Wall)
  {14, 19357, 1459.857666, 1439.629882, 28.940301, 0.000007, 0.000005, 0.000335}, // Room 14 (Wall)
  {14, 19449, 1464.758544, 1428.500366, 28.940301, -0.000005, 0.000007, -90.000602}, // Room 14 (Wall)
  {14, 19449, 1474.328125, 1428.500366, 28.940301, -0.000005, 0.000007, -90.000602}, // Room 14 (Wall)
  {14, 19449, 1483.938842, 1428.500244, 28.940301, -0.000005, 0.000007, -90.000602}, // Room 14 (Wall)
  {14, 19449, 1474.368164, 1441.162353, 28.940301, -0.000005, 0.000007, -90.000602}, // Room 14 (Wall)
  {14, 19449, 1483.988037, 1441.162231, 28.940301, -0.000005, 0.000007, -90.000602}, // Room 14 (Wall)
  {14, 19357, 1488.766845, 1436.440551, 28.940301, 0.000007, 0.000005, 0.000335}, // Room 14 (Wall)
  {14, 19357, 1488.766845, 1433.230346, 28.940301, 0.000007, 0.000005, 0.000335}, // Room 14 (Wall)
  {14, 19357, 1488.766845, 1430.030639, 28.940301, 0.000007, 0.000005, 0.000335}, // Room 14 (Wall)
  {14, 19357, 1488.766845, 1439.650390, 28.940301, 0.000007, 0.000005, 0.000335}, // Room 14 (Wall)
  {14, 19379, 1464.600830, 1435.864868, 27.139997, 0.000005, 90.000000, 89.999397}, // Room 14 (Floor)
  {14, 19379, 1474.231933, 1435.864868, 27.139997, 0.000005, 90.000000, 89.999397}, // Room 14 (Floor)
  {14, 19379, 1483.862792, 1435.864868, 27.139997, 0.000005, 90.000000, 89.999397}, // Room 14 (Floor)
  {14, 19462, 1464.760009, 1430.193237, 27.129999, -0.000005, 90.000000, -90.000602}, // Room 14 (Floor)
  {14, 19462, 1474.379882, 1430.193237, 27.129999, -0.000005, 90.000000, -90.000602}, // Room 14 (Floor)
  {14, 19462, 1484.010986, 1430.193237, 27.129999, -0.000005, 90.000000, -90.000602}, // Room 14 (Floor)
  {14, 19379, 1464.600830, 1435.864868, 30.759988, 0.000005, 89.999992, 89.999336}, // Room 14 (Ceiling)
  {14, 19379, 1474.231933, 1435.864868, 30.759988, 0.000005, 89.999992, 89.999336}, // Room 14 (Ceiling)
  {14, 19379, 1483.862792, 1435.864868, 30.759988, 0.000005, 89.999992, 89.999336}, // Room 14 (Ceiling)
  {14, 19462, 1464.599853, 1430.193237, 30.749990, -0.000005, 89.999992, -90.000602}, // Room 14 (Ceiling)
  {14, 19462, 1474.209716, 1430.193115, 30.749990, -0.000005, 89.999992, -90.000602}, // Room 14 (Ceiling)
  {14, 19462, 1483.840820, 1430.193115, 30.749990, -0.000005, 89.999992, -90.000602}, // Room 14 (Ceiling)
  {15, 19449, 1444.909667, 1444.519165, 28.940301, -0.000030, -0.000000, 89.999595}, // Room 15 (Wall)
  {15, 19357, 1449.810180, 1455.661376, 28.940301, 0.000000, 0.000030, -179.999771}, // Room 15 (Wall)
  {15, 19357, 1449.810180, 1452.472045, 28.940301, 0.000000, 0.000030, -179.999771}, // Room 15 (Wall)
  {15, 19387, 1449.809936, 1449.260375, 28.940301, 0.000000, 0.000030, -179.999771}, // Room 15 (Wall)
  {15, 19357, 1449.810180, 1446.051513, 28.940301, 0.000000, 0.000030, -179.999771}, // Room 15 (Wall)
  {15, 19449, 1444.909423, 1457.181152, 28.940301, -0.000030, -0.000000, 89.999595}, // Room 15 (Wall)
  {15, 19449, 1435.339721, 1457.181152, 28.940301, -0.000030, -0.000000, 89.999595}, // Room 15 (Wall)
  {15, 19449, 1425.729125, 1457.181152, 28.940301, -0.000030, -0.000000, 89.999595}, // Room 15 (Wall)
  {15, 19449, 1435.299926, 1444.519165, 28.940301, -0.000030, -0.000000, 89.999595}, // Room 15 (Wall)
  {15, 19449, 1425.679687, 1444.519165, 28.940301, -0.000030, -0.000000, 89.999595}, // Room 15 (Wall)
  {15, 19357, 1420.901000, 1449.240966, 28.940301, 0.000000, 0.000030, -179.999771}, // Room 15 (Wall)
  {15, 19357, 1420.901000, 1452.451171, 28.940301, 0.000000, 0.000030, -179.999771}, // Room 15 (Wall)
  {15, 19357, 1420.901000, 1455.650878, 28.940301, 0.000000, 0.000030, -179.999771}, // Room 15 (Wall)
  {15, 19357, 1420.901000, 1446.031127, 28.940301, 0.000000, 0.000030, -179.999771}, // Room 15 (Wall)
  {15, 19379, 1445.066894, 1449.816772, 27.139997, 0.000030, 90.000000, -90.000495}, // Room 15 (Floor)
  {15, 19379, 1435.436157, 1449.816772, 27.139997, 0.000030, 90.000000, -90.000495}, // Room 15 (Floor)
  {15, 19379, 1425.805297, 1449.816772, 27.139997, 0.000030, 90.000000, -90.000495}, // Room 15 (Floor)
  {15, 19462, 1444.907958, 1455.488281, 27.129999, -0.000030, 90.000000, 89.999595}, // Room 15 (Floor)
  {15, 19462, 1435.287963, 1455.488281, 27.129999, -0.000030, 90.000000, 89.999595}, // Room 15 (Floor)
  {15, 19462, 1425.656860, 1455.488281, 27.129999, -0.000030, 90.000000, 89.999595}, // Room 15 (Floor)
  {15, 19379, 1445.066894, 1449.816772, 30.759988, 0.000030, 89.999992, -90.000541}, // Room 15 (Ceiling)
  {15, 19379, 1435.436157, 1449.816772, 30.759988, 0.000030, 89.999992, -90.000541}, // Room 15 (Ceiling)
  {15, 19379, 1425.805297, 1449.816772, 30.759988, 0.000030, 89.999992, -90.000541}, // Room 15 (Ceiling)
  {15, 19462, 1445.068115, 1455.488281, 30.749990, -0.000030, 89.999992, 89.999595}, // Room 15 (Ceiling)
  {15, 19462, 1435.458129, 1455.488281, 30.749990, -0.000030, 89.999992, 89.999595}, // Room 15 (Ceiling)
  {15, 19462, 1425.827026, 1455.488281, 30.749990, -0.000030, 89.999992, 89.999595}, // Room 15 (Ceiling)
  {16, 19449, 1444.909667, 1431.688232, 28.940301, -0.000022, 0.000000, 89.999572}, // Room 16 (Wall)
  {16, 19357, 1449.810180, 1442.830444, 28.940301, 0.000000, 0.000022, -179.999725}, // Room 16 (Wall)
  {16, 19357, 1449.810180, 1439.641113, 28.940301, 0.000000, 0.000022, -179.999725}, // Room 16 (Wall)
  {16, 19387, 1449.809936, 1436.429443, 28.940301, 0.000000, 0.000022, -179.999725}, // Room 16 (Wall)
  {16, 19357, 1449.810180, 1433.220581, 28.940301, 0.000000, 0.000022, -179.999725}, // Room 16 (Wall)
  {16, 19449, 1444.909423, 1444.350219, 28.940301, -0.000022, 0.000000, 89.999572}, // Room 16 (Wall)
  {16, 19449, 1435.339721, 1444.350219, 28.940301, -0.000022, 0.000000, 89.999572}, // Room 16 (Wall)
  {16, 19449, 1425.729125, 1444.350219, 28.940301, -0.000022, 0.000000, 89.999572}, // Room 16 (Wall)
  {16, 19449, 1435.299926, 1431.688232, 28.940301, -0.000022, 0.000000, 89.999572}, // Room 16 (Wall)
  {16, 19449, 1425.679687, 1431.688232, 28.940301, -0.000022, 0.000000, 89.999572}, // Room 16 (Wall)
  {16, 19357, 1420.901000, 1436.410034, 28.940301, 0.000000, 0.000022, -179.999725}, // Room 16 (Wall)
  {16, 19357, 1420.901000, 1439.620239, 28.940301, 0.000000, 0.000022, -179.999725}, // Room 16 (Wall)
  {16, 19357, 1420.901000, 1442.819946, 28.940301, 0.000000, 0.000022, -179.999725}, // Room 16 (Wall)
  {16, 19357, 1420.901000, 1433.200195, 28.940301, 0.000000, 0.000022, -179.999725}, // Room 16 (Wall)
  {16, 19379, 1445.066894, 1436.985839, 27.139997, 0.000022, 90.000000, -90.000473}, // Room 16 (Floor)
  {16, 19379, 1435.436157, 1436.985839, 27.139997, 0.000022, 90.000000, -90.000473}, // Room 16 (Floor)
  {16, 19379, 1425.805297, 1436.985839, 27.139997, 0.000022, 90.000000, -90.000473}, // Room 16 (Floor)
  {16, 19462, 1444.907958, 1442.657348, 27.129999, -0.000022, 90.000000, 89.999572}, // Room 16 (Floor)
  {16, 19462, 1435.287963, 1442.657348, 27.129999, -0.000022, 90.000000, 89.999572}, // Room 16 (Floor)
  {16, 19462, 1425.656860, 1442.657348, 27.129999, -0.000022, 90.000000, 89.999572}, // Room 16 (Floor)
  {16, 19379, 1445.066894, 1436.985839, 30.759988, 0.000022, 89.999992, -90.000518}, // Room 16 (Ceiling)
  {16, 19379, 1435.436157, 1436.985839, 30.759988, 0.000022, 89.999992, -90.000518}, // Room 16 (Ceiling)
  {16, 19379, 1425.805297, 1436.985839, 30.759988, 0.000022, 89.999992, -90.000518}, // Room 16 (Ceiling)
  {16, 19462, 1445.068115, 1442.657348, 30.749990, -0.000022, 89.999992, 89.999572}, // Room 16 (Ceiling)
  {16, 19462, 1435.458129, 1442.657348, 30.749990, -0.000022, 89.999992, 89.999572}, // Room 16 (Ceiling)
  {16, 19462, 1425.827026, 1442.657348, 30.749990, -0.000022, 89.999992, 89.999572} // Room 16 (Ceiling)
};

new const FlatMediumAreaPos[][e_flatAreaPos] = {
  {1, 1432.09, 1465.72, 1444.32, 1495.33, 10.82}, // Room 1
  {2, 1444.47, 1465.66, 1457.53, 1495.52, 10.82}, // Room 2
  {3, 1428.16, 1426.87, 1441.12, 1456.36, 10.82}, // Room 3
  {4, 1441.27, 1426.87, 1454.29, 1456.43, 10.82}, // Room 4
  {5, 1459.42, 1440.61, 1489.06, 1453.46, 16.59}, // Room 5
  {6, 1459.56, 1427.62, 1489.04, 1440.46, 16.59}, // Room 6
  {7, 1420.66, 1443.81, 1450.06, 1456.72, 16.59}, // Room 7
  {8, 1420.66, 1430.70, 1450.19, 1443.64, 16.59}, // Room 8
  {9, 1459.10, 1440.61, 1489.34, 1453.98, 22.41}, // Room 9
  {10, 1459.00, 1427.13, 1489.37, 1440.46, 22.41}, // Room 10
  {11, 1420.09, 1443.83, 1450.33, 1457.19, 22.41}, // Room 11
  {12, 1419.99, 1430.35, 1450.36, 1443.68, 22.41}, // Room 12
  {13, 1459.10, 1441.34, 1489.34, 1454.71, 28.22}, // Room 13
  {14, 1459.00, 1427.86, 1489.37, 1441.20, 28.22}, // Room 14
  {15, 1420.11, 1444.55, 1450.36, 1457.91, 28.22}, // Room 15
  {16, 1420.01, 1431.06, 1450.39, 1444.40, 28.22} // Room 16
};

new const FlatLowInterior[][e_flatIntStructure] = {
  {1, 19449, 1427.383178, 1574.968627, 11.680314, 0.000014, 0.000014, 89.999954}, // Room 1
  {1, 19357, 1420.963256, 1574.968627, 11.680314, 0.000014, 0.000014, 89.999954}, // Room 1
  {1, 19449, 1427.383178, 1558.937255, 11.680314, 0.000022, 0.000014, 89.999931}, // Room 1
  {1, 19357, 1420.963256, 1558.937255, 11.680314, 0.000022, 0.000014, 89.999931}, // Room 1
  {1, 19449, 1419.452392, 1570.237915, 11.680314, 0.000000, 0.000000, 0.000000}, // Room 1
  {1, 19357, 1419.460937, 1560.615966, 11.680314, 0.000000, 0.000007, 0.000000}, // Room 1
  {1, 19357, 1419.460937, 1563.825683, 11.680314, 0.000000, 0.000007, 0.000000}, // Room 1
  {1, 19449, 1432.092285, 1570.247436, 11.680314, 0.000000, 0.000000, 0.000000}, // Room 1
  {1, 19387, 1432.092163, 1563.825683, 11.680314, 0.000000, 0.000000, 0.000000}, // Room 1
  {1, 19357, 1432.092163, 1560.625854, 11.680314, 0.000000, 0.000000, 0.000000}, // Room 1
  {1, 19379, 1424.776977, 1570.092651, 9.850314, 0.000000, 90.000000, 0.000000}, // Room 1
  {1, 19370, 1421.215209, 1563.672851, 9.850314, 0.000000, 90.000000, 0.000000}, // Room 1
  {1, 19370, 1421.215209, 1560.462158, 9.850314, 0.000000, 90.000000, 0.000000}, // Room 1
  {1, 19370, 1424.715820, 1563.672851, 9.850314, 0.000000, 90.000007, 0.000000}, // Room 1
  {1, 19370, 1424.715820, 1560.462158, 9.850314, 0.000000, 90.000007, 0.000000}, // Room 1
  {1, 19370, 1428.187988, 1563.672851, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 1
  {1, 19370, 1428.187988, 1560.462158, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 1
  {1, 19370, 1431.680175, 1563.672851, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 1
  {1, 19370, 1431.680175, 1560.462158, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 1
  {1, 19370, 1431.759521, 1570.085693, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 1
  {1, 19370, 1431.759521, 1566.875000, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 1
  {1, 19370, 1431.759521, 1573.296508, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 1
  {1, 19379, 1424.776977, 1570.092651, 13.350349, 0.000000, 90.000007, 0.000000}, // Room 1
  {1, 19370, 1421.215209, 1563.672851, 13.350349, 0.000000, 90.000007, 0.000000}, // Room 1
  {1, 19370, 1421.215209, 1560.462158, 13.350349, 0.000000, 90.000007, 0.000000}, // Room 1
  {1, 19370, 1424.715820, 1563.672851, 13.350349, 0.000000, 90.000015, 0.000000}, // Room 1
  {1, 19370, 1424.715820, 1560.462158, 13.350349, 0.000000, 90.000015, 0.000000}, // Room 1
  {1, 19370, 1428.187988, 1563.672851, 13.350349, 0.000000, 90.000022, 0.000000}, // Room 1
  {1, 19370, 1428.187988, 1560.462158, 13.350349, 0.000000, 90.000022, 0.000000}, // Room 1
  {1, 19370, 1431.680175, 1563.672851, 13.350349, 0.000000, 90.000030, 0.000000}, // Room 1
  {1, 19370, 1431.680175, 1560.462158, 13.350349, 0.000000, 90.000030, 0.000000}, // Room 1
  {1, 19370, 1431.759521, 1570.085693, 13.350349, 0.000000, 90.000038, 0.000000}, // Room 1
  {1, 19370, 1431.759521, 1566.875000, 13.350349, 0.000000, 90.000038, 0.000000}, // Room 1
  {1, 19370, 1431.759521, 1573.296508, 13.350349, 0.000000, 90.000038, 0.000000}, // Room 1
  {2, 19449, 1427.383178, 1591.024291, 11.680314, 0.000029, 0.000014, 89.999908}, // Room 2
  {2, 19357, 1420.963256, 1591.024291, 11.680314, 0.000029, 0.000014, 89.999908}, // Room 2
  {2, 19449, 1427.383178, 1574.992919, 11.680314, 0.000037, 0.000014, 89.999885}, // Room 2
  {2, 19357, 1420.963256, 1574.992919, 11.680314, 0.000037, 0.000014, 89.999885}, // Room 2
  {2, 19449, 1419.452392, 1586.293579, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 2
  {2, 19357, 1419.460937, 1576.671630, 11.680314, 0.000000, 0.000022, 0.000000}, // Room 2
  {2, 19357, 1419.460937, 1579.881347, 11.680314, 0.000000, 0.000022, 0.000000}, // Room 2
  {2, 19449, 1432.092285, 1586.303100, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 2
  {2, 19387, 1432.092163, 1579.881347, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 2
  {2, 19357, 1432.092163, 1576.681518, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 2
  {2, 19379, 1424.776977, 1586.148315, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 2
  {2, 19370, 1421.215209, 1579.728515, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 2
  {2, 19370, 1421.215209, 1576.517822, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 2
  {2, 19370, 1424.715820, 1579.728515, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 2
  {2, 19370, 1424.715820, 1576.517822, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 2
  {2, 19370, 1428.187988, 1579.728515, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 2
  {2, 19370, 1428.187988, 1576.517822, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 2
  {2, 19370, 1431.680175, 1579.728515, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 2
  {2, 19370, 1431.680175, 1576.517822, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 2
  {2, 19370, 1431.759521, 1586.141357, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 2
  {2, 19370, 1431.759521, 1582.930664, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 2
  {2, 19370, 1431.759521, 1589.352172, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 2
  {2, 19379, 1424.776977, 1586.148315, 13.350349, 0.000000, 90.000022, 0.000000}, // Room 2
  {2, 19370, 1421.215209, 1579.728515, 13.350349, 0.000000, 90.000022, 0.000000}, // Room 2
  {2, 19370, 1421.215209, 1576.517822, 13.350349, 0.000000, 90.000022, 0.000000}, // Room 2
  {2, 19370, 1424.715820, 1579.728515, 13.350349, 0.000000, 90.000030, 0.000000}, // Room 2
  {2, 19370, 1424.715820, 1576.517822, 13.350349, 0.000000, 90.000030, 0.000000}, // Room 2
  {2, 19370, 1428.187988, 1579.728515, 13.350349, 0.000000, 90.000038, 0.000000}, // Room 2
  {2, 19370, 1428.187988, 1576.517822, 13.350349, 0.000000, 90.000038, 0.000000}, // Room 2
  {2, 19370, 1431.680175, 1579.728515, 13.350349, 0.000000, 90.000045, 0.000000}, // Room 2
  {2, 19370, 1431.680175, 1576.517822, 13.350349, 0.000000, 90.000045, 0.000000}, // Room 2
  {2, 19370, 1431.759521, 1586.141357, 13.350349, 0.000000, 90.000053, 0.000000}, // Room 2
  {2, 19370, 1431.759521, 1582.930664, 13.350349, 0.000000, 90.000053, 0.000000}, // Room 2
  {2, 19370, 1431.759521, 1589.352172, 13.350349, 0.000000, 90.000053, 0.000000}, // Room 2
  {3, 19449, 1427.383178, 1607.059082, 11.680314, 0.000037, 0.000014, 89.999885}, // Room 3
  {3, 19357, 1420.963256, 1607.059082, 11.680314, 0.000037, 0.000014, 89.999885}, // Room 3
  {3, 19449, 1427.383178, 1591.027709, 11.680314, 0.000044, 0.000014, 89.999862}, // Room 3
  {3, 19357, 1420.963256, 1591.027709, 11.680314, 0.000044, 0.000014, 89.999862}, // Room 3
  {3, 19449, 1419.452392, 1602.328369, 11.680314, 0.000000, 0.000022, 0.000000}, // Room 3
  {3, 19357, 1419.460937, 1592.706420, 11.680314, 0.000000, 0.000029, 0.000000}, // Room 3
  {3, 19357, 1419.460937, 1595.916137, 11.680314, 0.000000, 0.000029, 0.000000}, // Room 3
  {3, 19449, 1432.092285, 1602.337890, 11.680314, 0.000000, 0.000022, 0.000000}, // Room 3
  {3, 19387, 1432.092163, 1595.916137, 11.680314, 0.000000, 0.000022, 0.000000}, // Room 3
  {3, 19357, 1432.092163, 1592.716308, 11.680314, 0.000000, 0.000022, 0.000000}, // Room 3
  {3, 19379, 1424.776977, 1602.183105, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 3
  {3, 19370, 1421.215209, 1595.763305, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 3
  {3, 19370, 1421.215209, 1592.552612, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 3
  {3, 19370, 1424.715820, 1595.763305, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 3
  {3, 19370, 1424.715820, 1592.552612, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 3
  {3, 19370, 1428.187988, 1595.763305, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 3
  {3, 19370, 1428.187988, 1592.552612, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 3
  {3, 19370, 1431.680175, 1595.763305, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 3
  {3, 19370, 1431.680175, 1592.552612, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 3
  {3, 19370, 1431.759521, 1602.176147, 9.850314, 0.000000, 90.000053, 0.000000}, // Room 3
  {3, 19370, 1431.759521, 1598.965454, 9.850314, 0.000000, 90.000053, 0.000000}, // Room 3
  {3, 19370, 1431.759521, 1605.386962, 9.850314, 0.000000, 90.000053, 0.000000}, // Room 3
  {3, 19379, 1424.776977, 1602.183105, 13.350349, 0.000000, 90.000030, 0.000000}, // Room 3
  {3, 19370, 1421.215209, 1595.763305, 13.350349, 0.000000, 90.000030, 0.000000}, // Room 3
  {3, 19370, 1421.215209, 1592.552612, 13.350349, 0.000000, 90.000030, 0.000000}, // Room 3
  {3, 19370, 1424.715820, 1595.763305, 13.350349, 0.000000, 90.000038, 0.000000}, // Room 3
  {3, 19370, 1424.715820, 1592.552612, 13.350349, 0.000000, 90.000038, 0.000000}, // Room 3
  {3, 19370, 1428.187988, 1595.763305, 13.350349, 0.000000, 90.000045, 0.000000}, // Room 3
  {3, 19370, 1428.187988, 1592.552612, 13.350349, 0.000000, 90.000045, 0.000000}, // Room 3
  {3, 19370, 1431.680175, 1595.763305, 13.350349, 0.000000, 90.000053, 0.000000}, // Room 3
  {3, 19370, 1431.680175, 1592.552612, 13.350349, 0.000000, 90.000053, 0.000000}, // Room 3
  {3, 19370, 1431.759521, 1602.176147, 13.350349, 0.000000, 90.000061, 0.000000}, // Room 3
  {3, 19370, 1431.759521, 1598.965454, 13.350349, 0.000000, 90.000061, 0.000000}, // Room 3
  {3, 19370, 1431.759521, 1605.386962, 13.350349, 0.000000, 90.000061, 0.000000}, // Room 3
  {4, 19449, 1437.263793, 1570.247436, 11.680314, 0.000000, 0.000007, 0.000000}, // Room 4
  {4, 19387, 1437.263671, 1563.825683, 11.680314, 0.000000, 0.000007, 0.000000}, // Room 4
  {4, 19357, 1437.263671, 1560.625854, 11.680314, 0.000000, 0.000007, 0.000000}, // Room 4
  {4, 19449, 1445.195312, 1574.958496, 11.680314, 0.000029, 0.000014, 89.999908}, // Room 4
  {4, 19357, 1438.775390, 1574.958496, 11.680314, 0.000029, 0.000014, 89.999908}, // Room 4
  {4, 19449, 1445.195312, 1558.927124, 11.680314, 0.000037, 0.000014, 89.999885}, // Room 4
  {4, 19357, 1438.775390, 1558.927124, 11.680314, 0.000037, 0.000014, 89.999885}, // Room 4
  {4, 19449, 1449.915039, 1570.237915, 11.680314, 0.000000, 0.000007, 0.000000}, // Room 4
  {4, 19357, 1449.923583, 1560.615966, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 4
  {4, 19357, 1449.923583, 1563.825683, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 4
  {4, 19379, 1441.187377, 1570.092651, 9.850314, 0.000000, 90.000007, 0.000000}, // Room 4
  {4, 19370, 1437.625610, 1563.672851, 9.850314, 0.000000, 90.000007, 0.000000}, // Room 4
  {4, 19370, 1437.625610, 1560.462158, 9.850314, 0.000000, 90.000007, 0.000000}, // Room 4
  {4, 19370, 1441.126220, 1563.672851, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 4
  {4, 19370, 1441.126220, 1560.462158, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 4
  {4, 19370, 1444.598388, 1563.672851, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 4
  {4, 19370, 1444.598388, 1560.462158, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 4
  {4, 19370, 1448.090576, 1563.672851, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 4
  {4, 19370, 1448.090576, 1560.462158, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 4
  {4, 19370, 1448.169921, 1570.085693, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 4
  {4, 19370, 1448.169921, 1566.875000, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 4
  {4, 19370, 1448.169921, 1573.296508, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 4
  {4, 19379, 1441.187377, 1570.092651, 13.360334, 0.000000, 90.000015, 0.000000}, // Room 4
  {4, 19370, 1437.625610, 1563.672851, 13.360334, 0.000000, 90.000015, 0.000000}, // Room 4
  {4, 19370, 1437.625610, 1560.462158, 13.360334, 0.000000, 90.000015, 0.000000}, // Room 4
  {4, 19370, 1441.126220, 1563.672851, 13.360334, 0.000000, 90.000022, 0.000000}, // Room 4
  {4, 19370, 1441.126220, 1560.462158, 13.360334, 0.000000, 90.000022, 0.000000}, // Room 4
  {4, 19370, 1444.598388, 1563.672851, 13.360334, 0.000000, 90.000030, 0.000000}, // Room 4
  {4, 19370, 1444.598388, 1560.462158, 13.360334, 0.000000, 90.000030, 0.000000}, // Room 4
  {4, 19370, 1448.090576, 1563.672851, 13.360334, 0.000000, 90.000038, 0.000000}, // Room 4
  {4, 19370, 1448.090576, 1560.462158, 13.360334, 0.000000, 90.000038, 0.000000}, // Room 4
  {4, 19370, 1448.169921, 1570.085693, 13.360334, 0.000000, 90.000045, 0.000000}, // Room 4
  {4, 19370, 1448.169921, 1566.875000, 13.360334, 0.000000, 90.000045, 0.000000}, // Room 4
  {4, 19370, 1448.169921, 1573.296508, 13.360334, 0.000000, 90.000045, 0.000000}, // Room 4
  {5, 19449, 1437.263793, 1586.281860, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 5
  {5, 19387, 1437.263671, 1579.860107, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 5
  {5, 19357, 1437.263671, 1576.660278, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 5
  {5, 19449, 1445.195312, 1590.992919, 11.680314, 0.000037, 0.000014, 89.999885}, // Room 5
  {5, 19357, 1438.775390, 1590.992919, 11.680314, 0.000037, 0.000014, 89.999885}, // Room 5
  {5, 19449, 1445.195312, 1574.961547, 11.680314, 0.000044, 0.000014, 89.999862}, // Room 5
  {5, 19357, 1438.775390, 1574.961547, 11.680314, 0.000044, 0.000014, 89.999862}, // Room 5
  {5, 19449, 1449.915039, 1586.272338, 11.680314, 0.000000, 0.000014, 0.000000}, // Room 5
  {5, 19357, 1449.923583, 1576.650390, 11.680314, 0.000000, 0.000022, 0.000000}, // Room 5
  {5, 19357, 1449.923583, 1579.860107, 11.680314, 0.000000, 0.000022, 0.000000}, // Room 5
  {5, 19379, 1441.187377, 1586.127075, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 5
  {5, 19370, 1437.625610, 1579.707275, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 5
  {5, 19370, 1437.625610, 1576.496582, 9.850314, 0.000000, 90.000015, 0.000000}, // Room 5
  {5, 19370, 1441.126220, 1579.707275, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 5
  {5, 19370, 1441.126220, 1576.496582, 9.850314, 0.000000, 90.000022, 0.000000}, // Room 5
  {5, 19370, 1444.598388, 1579.707275, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 5
  {5, 19370, 1444.598388, 1576.496582, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 5
  {5, 19370, 1448.090576, 1579.707275, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 5
  {5, 19370, 1448.090576, 1576.496582, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 5
  {5, 19370, 1448.169921, 1586.120117, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 5
  {5, 19370, 1448.169921, 1582.909423, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 5
  {5, 19370, 1448.169921, 1589.330932, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 5
  {5, 19379, 1441.187377, 1586.127075, 13.360334, 0.000000, 90.000022, 0.000000}, // Room 5
  {5, 19370, 1437.625610, 1579.707275, 13.360334, 0.000000, 90.000022, 0.000000}, // Room 5
  {5, 19370, 1437.625610, 1576.496582, 13.360334, 0.000000, 90.000022, 0.000000}, // Room 5
  {5, 19370, 1441.126220, 1579.707275, 13.360334, 0.000000, 90.000030, 0.000000}, // Room 5
  {5, 19370, 1441.126220, 1576.496582, 13.360334, 0.000000, 90.000030, 0.000000}, // Room 5
  {5, 19370, 1444.598388, 1579.707275, 13.360334, 0.000000, 90.000038, 0.000000}, // Room 5
  {5, 19370, 1444.598388, 1576.496582, 13.360334, 0.000000, 90.000038, 0.000000}, // Room 5
  {5, 19370, 1448.090576, 1579.707275, 13.360334, 0.000000, 90.000045, 0.000000}, // Room 5
  {5, 19370, 1448.090576, 1576.496582, 13.360334, 0.000000, 90.000045, 0.000000}, // Room 5
  {5, 19370, 1448.169921, 1586.120117, 13.360334, 0.000000, 90.000053, 0.000000}, // Room 5
  {5, 19370, 1448.169921, 1582.909423, 13.360334, 0.000000, 90.000053, 0.000000}, // Room 5
  {5, 19370, 1448.169921, 1589.330932, 13.360334, 0.000000, 90.000053, 0.000000}, // Room 5
  {6, 19449, 1437.263793, 1602.343505, 11.680314, 0.000000, 0.000029, 0.000000}, // Room 6
  {6, 19387, 1437.263671, 1595.921752, 11.680314, 0.000000, 0.000029, 0.000000}, // Room 6
  {6, 19357, 1437.263671, 1592.721923, 11.680314, 0.000000, 0.000029, 0.000000}, // Room 6
  {6, 19449, 1445.195312, 1607.054565, 11.680314, 0.000052, 0.000014, 89.999839}, // Room 6
  {6, 19357, 1438.775390, 1607.054565, 11.680314, 0.000052, 0.000014, 89.999839}, // Room 6
  {6, 19449, 1445.195312, 1591.023193, 11.680314, 0.000059, 0.000014, 89.999816}, // Room 6
  {6, 19357, 1438.775390, 1591.023193, 11.680314, 0.000059, 0.000014, 89.999816}, // Room 6
  {6, 19449, 1449.915039, 1602.333984, 11.680314, 0.000000, 0.000029, 0.000000}, // Room 6
  {6, 19357, 1449.923583, 1592.712036, 11.680314, 0.000000, 0.000037, 0.000000}, // Room 6
  {6, 19357, 1449.923583, 1595.921752, 11.680314, 0.000000, 0.000037, 0.000000}, // Room 6
  {6, 19379, 1441.187377, 1602.188720, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 6
  {6, 19370, 1437.625610, 1595.768920, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 6
  {6, 19370, 1437.625610, 1592.558227, 9.850314, 0.000000, 90.000030, 0.000000}, // Room 6
  {6, 19370, 1441.126220, 1595.768920, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 6
  {6, 19370, 1441.126220, 1592.558227, 9.850314, 0.000000, 90.000038, 0.000000}, // Room 6
  {6, 19370, 1444.598388, 1595.768920, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 6
  {6, 19370, 1444.598388, 1592.558227, 9.850314, 0.000000, 90.000045, 0.000000}, // Room 6
  {6, 19370, 1448.090576, 1595.768920, 9.850314, 0.000000, 90.000053, 0.000000}, // Room 6
  {6, 19370, 1448.090576, 1592.558227, 9.850314, 0.000000, 90.000053, 0.000000}, // Room 6
  {6, 19370, 1448.169921, 1602.181762, 9.850314, 0.000000, 90.000061, 0.000000}, // Room 6
  {6, 19370, 1448.169921, 1598.971069, 9.850314, 0.000000, 90.000061, 0.000000}, // Room 6
  {6, 19370, 1448.169921, 1605.392578, 9.850314, 0.000000, 90.000061, 0.000000}, // Room 6
  {6, 19379, 1441.187377, 1602.188720, 13.360334, 0.000000, 90.000038, 0.000000}, // Room 6
  {6, 19370, 1437.625610, 1595.768920, 13.360334, 0.000000, 90.000038, 0.000000}, // Room 6
  {6, 19370, 1437.625610, 1592.558227, 13.360334, 0.000000, 90.000038, 0.000000}, // Room 6
  {6, 19370, 1441.126220, 1595.768920, 13.360334, 0.000000, 90.000045, 0.000000}, // Room 6
  {6, 19370, 1441.126220, 1592.558227, 13.360334, 0.000000, 90.000045, 0.000000}, // Room 6
  {6, 19370, 1444.598388, 1595.768920, 13.360334, 0.000000, 90.000053, 0.000000}, // Room 6
  {6, 19370, 1444.598388, 1592.558227, 13.360334, 0.000000, 90.000053, 0.000000}, // Room 6
  {6, 19370, 1448.090576, 1595.768920, 13.360334, 0.000000, 90.000061, 0.000000}, // Room 6
  {6, 19370, 1448.090576, 1592.558227, 13.360334, 0.000000, 90.000061, 0.000000}, // Room 6
  {6, 19370, 1448.169921, 1602.181762, 13.360334, 0.000000, 90.000068, 0.000000}, // Room 6
  {6, 19370, 1448.169921, 1598.971069, 13.360334, 0.000000, 90.000068, 0.000000}, // Room 6
  {6, 19370, 1448.169921, 1605.392578, 13.360334, 0.000000, 90.000068, 0.000000}, // Room 6
  {7, 19449, 1427.383178, 1575.659301, 17.485359, 0.000022, 0.000014, 89.999931}, // Room 7
  {7, 19357, 1420.963256, 1575.659301, 17.485359, 0.000022, 0.000014, 89.999931}, // Room 7
  {7, 19449, 1427.383178, 1559.627929, 17.485359, 0.000029, 0.000014, 89.999908}, // Room 7
  {7, 19357, 1420.963256, 1559.627929, 17.485359, 0.000029, 0.000014, 89.999908}, // Room 7
  {7, 19449, 1419.452392, 1570.928588, 17.485359, 0.000000, 0.000007, 0.000000}, // Room 7
  {7, 19357, 1419.460937, 1561.306640, 17.485359, 0.000000, 0.000014, 0.000000}, // Room 7
  {7, 19357, 1419.460937, 1564.516357, 17.485359, 0.000000, 0.000014, 0.000000}, // Room 7
  {7, 19449, 1432.092285, 1570.938110, 17.485359, 0.000000, 0.000007, 0.000000}, // Room 7
  {7, 19387, 1432.092163, 1564.516357, 17.485359, 0.000000, 0.000007, 0.000000}, // Room 7
  {7, 19357, 1432.092163, 1561.316528, 17.485359, 0.000000, 0.000007, 0.000000}, // Room 7
  {7, 19379, 1424.776977, 1570.783325, 15.655364, 0.000000, 90.000007, 0.000000}, // Room 7
  {7, 19370, 1421.215209, 1564.363525, 15.655364, 0.000000, 90.000007, 0.000000}, // Room 7
  {7, 19370, 1421.215209, 1561.152832, 15.655364, 0.000000, 90.000007, 0.000000}, // Room 7
  {7, 19370, 1424.715820, 1564.363525, 15.655364, 0.000000, 90.000015, 0.000000}, // Room 7
  {7, 19370, 1424.715820, 1561.152832, 15.655364, 0.000000, 90.000015, 0.000000}, // Room 7
  {7, 19370, 1428.187988, 1564.363525, 15.655364, 0.000000, 90.000022, 0.000000}, // Room 7
  {7, 19370, 1428.187988, 1561.152832, 15.655364, 0.000000, 90.000022, 0.000000}, // Room 7
  {7, 19370, 1431.680175, 1564.363525, 15.655364, 0.000000, 90.000030, 0.000000}, // Room 7
  {7, 19370, 1431.680175, 1561.152832, 15.655364, 0.000000, 90.000030, 0.000000}, // Room 7
  {7, 19370, 1431.759521, 1570.776367, 15.655364, 0.000000, 90.000038, 0.000000}, // Room 7
  {7, 19370, 1431.759521, 1567.565673, 15.655364, 0.000000, 90.000038, 0.000000}, // Room 7
  {7, 19370, 1431.759521, 1573.987182, 15.655364, 0.000000, 90.000038, 0.000000}, // Room 7
  {7, 19379, 1424.776977, 1570.783325, 19.155395, 0.000000, 90.000015, 0.000000}, // Room 7
  {7, 19370, 1421.215209, 1564.363525, 19.155395, 0.000000, 90.000015, 0.000000}, // Room 7
  {7, 19370, 1421.215209, 1561.152832, 19.155395, 0.000000, 90.000015, 0.000000}, // Room 7
  {7, 19370, 1424.715820, 1564.363525, 19.155395, 0.000000, 90.000022, 0.000000}, // Room 7
  {7, 19370, 1424.715820, 1561.152832, 19.155395, 0.000000, 90.000022, 0.000000}, // Room 7
  {7, 19370, 1428.187988, 1564.363525, 19.155395, 0.000000, 90.000030, 0.000000}, // Room 7
  {7, 19370, 1428.187988, 1561.152832, 19.155395, 0.000000, 90.000030, 0.000000}, // Room 7
  {7, 19370, 1431.680175, 1564.363525, 19.155395, 0.000000, 90.000038, 0.000000}, // Room 7
  {7, 19370, 1431.680175, 1561.152832, 19.155395, 0.000000, 90.000038, 0.000000}, // Room 7
  {7, 19370, 1431.759521, 1570.776367, 19.155395, 0.000000, 90.000045, 0.000000}, // Room 7
  {7, 19370, 1431.759521, 1567.565673, 19.155395, 0.000000, 90.000045, 0.000000}, // Room 7
  {7, 19370, 1431.759521, 1573.987182, 19.155395, 0.000000, 90.000045, 0.000000}, // Room 7
  {8, 19449, 1427.383178, 1591.713867, 17.490362, 0.000037, 0.000014, 89.999885}, // Room 8
  {8, 19357, 1420.963256, 1591.713867, 17.490362, 0.000037, 0.000014, 89.999885}, // Room 8
  {8, 19449, 1427.383178, 1575.682495, 17.490362, 0.000044, 0.000014, 89.999862}, // Room 8
  {8, 19357, 1420.963256, 1575.682495, 17.490362, 0.000044, 0.000014, 89.999862}, // Room 8
  {8, 19449, 1419.452392, 1586.983154, 17.490362, 0.000000, 0.000022, 0.000000}, // Room 8
  {8, 19357, 1419.460937, 1577.361206, 17.490362, 0.000000, 0.000029, 0.000000}, // Room 8
  {8, 19357, 1419.460937, 1580.570922, 17.490362, 0.000000, 0.000029, 0.000000}, // Room 8
  {8, 19449, 1432.092285, 1586.992675, 17.490362, 0.000000, 0.000022, 0.000000}, // Room 8
  {8, 19387, 1432.092163, 1580.570922, 17.490362, 0.000000, 0.000022, 0.000000}, // Room 8
  {8, 19357, 1432.092163, 1577.371093, 17.490362, 0.000000, 0.000022, 0.000000}, // Room 8
  {8, 19379, 1424.776977, 1586.837890, 15.660363, 0.000000, 90.000022, 0.000000}, // Room 8
  {8, 19370, 1421.215209, 1580.418090, 15.660363, 0.000000, 90.000022, 0.000000}, // Room 8
  {8, 19370, 1421.215209, 1577.207397, 15.660363, 0.000000, 90.000022, 0.000000}, // Room 8
  {8, 19370, 1424.715820, 1580.418090, 15.660363, 0.000000, 90.000030, 0.000000}, // Room 8
  {8, 19370, 1424.715820, 1577.207397, 15.660363, 0.000000, 90.000030, 0.000000}, // Room 8
  {8, 19370, 1428.187988, 1580.418090, 15.660363, 0.000000, 90.000038, 0.000000}, // Room 8
  {8, 19370, 1428.187988, 1577.207397, 15.660363, 0.000000, 90.000038, 0.000000}, // Room 8
  {8, 19370, 1431.680175, 1580.418090, 15.660363, 0.000000, 90.000045, 0.000000}, // Room 8
  {8, 19370, 1431.680175, 1577.207397, 15.660363, 0.000000, 90.000045, 0.000000}, // Room 8
  {8, 19370, 1431.759521, 1586.830932, 15.660363, 0.000000, 90.000053, 0.000000}, // Room 8
  {8, 19370, 1431.759521, 1583.620239, 15.660363, 0.000000, 90.000053, 0.000000}, // Room 8
  {8, 19370, 1431.759521, 1590.041748, 15.660363, 0.000000, 90.000053, 0.000000}, // Room 8
  {8, 19379, 1424.776977, 1586.837890, 19.160398, 0.000000, 90.000030, 0.000000}, // Room 8
  {8, 19370, 1421.215209, 1580.418090, 19.160398, 0.000000, 90.000030, 0.000000}, // Room 8
  {8, 19370, 1421.215209, 1577.207397, 19.160398, 0.000000, 90.000030, 0.000000}, // Room 8
  {8, 19370, 1424.715820, 1580.418090, 19.160398, 0.000000, 90.000038, 0.000000}, // Room 8
  {8, 19370, 1424.715820, 1577.207397, 19.160398, 0.000000, 90.000038, 0.000000}, // Room 8
  {8, 19370, 1428.187988, 1580.418090, 19.160398, 0.000000, 90.000045, 0.000000}, // Room 8
  {8, 19370, 1428.187988, 1577.207397, 19.160398, 0.000000, 90.000045, 0.000000}, // Room 8
  {8, 19370, 1431.680175, 1580.418090, 19.160398, 0.000000, 90.000053, 0.000000}, // Room 8
  {8, 19370, 1431.680175, 1577.207397, 19.160398, 0.000000, 90.000053, 0.000000}, // Room 8
  {8, 19370, 1431.759521, 1586.830932, 19.160398, 0.000000, 90.000061, 0.000000}, // Room 8
  {8, 19370, 1431.759521, 1583.620239, 19.160398, 0.000000, 90.000061, 0.000000}, // Room 8
  {8, 19370, 1431.759521, 1590.041748, 19.160398, 0.000000, 90.000061, 0.000000}, // Room 8
  {9, 19449, 1427.383178, 1607.754638, 17.490362, 0.000045, 0.000014, 89.999862}, // Room 9
  {9, 19357, 1420.963256, 1607.754638, 17.490362, 0.000045, 0.000014, 89.999862}, // Room 9
  {9, 19449, 1427.383178, 1591.723266, 17.490362, 0.000051, 0.000014, 89.999839}, // Room 9
  {9, 19357, 1420.963256, 1591.723266, 17.490362, 0.000051, 0.000014, 89.999839}, // Room 9
  {9, 19449, 1419.452392, 1603.023925, 17.490362, 0.000000, 0.000029, 0.000000}, // Room 9
  {9, 19357, 1419.460937, 1593.401977, 17.490362, 0.000000, 0.000037, 0.000000}, // Room 9
  {9, 19357, 1419.460937, 1596.611694, 17.490362, 0.000000, 0.000037, 0.000000}, // Room 9
  {9, 19449, 1432.092285, 1603.033447, 17.490362, 0.000000, 0.000029, 0.000000}, // Room 9
  {9, 19387, 1432.092163, 1596.611694, 17.490362, 0.000000, 0.000029, 0.000000}, // Room 9
  {9, 19357, 1432.092163, 1593.411865, 17.490362, 0.000000, 0.000029, 0.000000}, // Room 9
  {9, 19379, 1424.776977, 1602.878662, 15.660363, 0.000000, 90.000030, 0.000000}, // Room 9
  {9, 19370, 1421.215209, 1596.458862, 15.660363, 0.000000, 90.000030, 0.000000}, // Room 9
  {9, 19370, 1421.215209, 1593.248168, 15.660363, 0.000000, 90.000030, 0.000000}, // Room 9
  {9, 19370, 1424.715820, 1596.458862, 15.660363, 0.000000, 90.000038, 0.000000}, // Room 9
  {9, 19370, 1424.715820, 1593.248168, 15.660363, 0.000000, 90.000038, 0.000000}, // Room 9
  {9, 19370, 1428.187988, 1596.458862, 15.660363, 0.000000, 90.000045, 0.000000}, // Room 9
  {9, 19370, 1428.187988, 1593.248168, 15.660363, 0.000000, 90.000045, 0.000000}, // Room 9
  {9, 19370, 1431.680175, 1596.458862, 15.660363, 0.000000, 90.000053, 0.000000}, // Room 9
  {9, 19370, 1431.680175, 1593.248168, 15.660363, 0.000000, 90.000053, 0.000000}, // Room 9
  {9, 19370, 1431.759521, 1602.871704, 15.660363, 0.000000, 90.000061, 0.000000}, // Room 9
  {9, 19370, 1431.759521, 1599.661010, 15.660363, 0.000000, 90.000061, 0.000000}, // Room 9
  {9, 19370, 1431.759521, 1606.082519, 15.660363, 0.000000, 90.000061, 0.000000}, // Room 9
  {9, 19379, 1424.776977, 1602.878662, 19.160398, 0.000000, 90.000038, 0.000000}, // Room 9
  {9, 19370, 1421.215209, 1596.458862, 19.160398, 0.000000, 90.000038, 0.000000}, // Room 9
  {9, 19370, 1421.215209, 1593.248168, 19.160398, 0.000000, 90.000038, 0.000000}, // Room 9
  {9, 19370, 1424.715820, 1596.458862, 19.160398, 0.000000, 90.000045, 0.000000}, // Room 9
  {9, 19370, 1424.715820, 1593.248168, 19.160398, 0.000000, 90.000045, 0.000000}, // Room 9
  {9, 19370, 1428.187988, 1596.458862, 19.160398, 0.000000, 90.000053, 0.000000}, // Room 9
  {9, 19370, 1428.187988, 1593.248168, 19.160398, 0.000000, 90.000053, 0.000000}, // Room 9
  {9, 19370, 1431.680175, 1596.458862, 19.160398, 0.000000, 90.000061, 0.000000}, // Room 9
  {9, 19370, 1431.680175, 1593.248168, 19.160398, 0.000000, 90.000061, 0.000000}, // Room 9
  {9, 19370, 1431.759521, 1602.871704, 19.160398, 0.000000, 90.000068, 0.000000}, // Room 9
  {9, 19370, 1431.759521, 1599.661010, 19.160398, 0.000000, 90.000068, 0.000000}, // Room 9
  {9, 19370, 1431.759521, 1606.082519, 19.160398, 0.000000, 90.000068, 0.000000}, // Room 9
  {10, 19449, 1437.263793, 1570.940917, 17.480339, 0.000000, 0.000045, 0.000000}, // Room 10
  {10, 19387, 1437.263671, 1564.519165, 17.480339, 0.000000, 0.000045, 0.000000}, // Room 10
  {10, 19357, 1437.263671, 1561.319335, 17.480339, 0.000000, 0.000045, 0.000000}, // Room 10
  {10, 19449, 1445.195312, 1575.651977, 17.480339, 0.000068, 0.000015, 89.999794}, // Room 10
  {10, 19357, 1438.775390, 1575.651977, 17.480339, 0.000068, 0.000015, 89.999794}, // Room 10
  {10, 19449, 1445.195312, 1559.620605, 17.480339, 0.000075, 0.000015, 89.999771}, // Room 10
  {10, 19357, 1438.775390, 1559.620605, 17.480339, 0.000075, 0.000015, 89.999771}, // Room 10
  {10, 19449, 1449.915039, 1570.931396, 17.480339, 0.000000, 0.000045, 0.000000}, // Room 10
  {10, 19357, 1449.923583, 1561.309448, 17.480339, 0.000000, 0.000052, 0.000000}, // Room 10
  {10, 19357, 1449.923583, 1564.519165, 17.480339, 0.000000, 0.000052, 0.000000}, // Room 10
  {10, 19379, 1441.187377, 1570.786132, 15.650338, 0.000000, 90.000045, 0.000000}, // Room 10
  {10, 19370, 1437.625610, 1564.366333, 15.650338, 0.000000, 90.000045, 0.000000}, // Room 10
  {10, 19370, 1437.625610, 1561.155639, 15.650338, 0.000000, 90.000045, 0.000000}, // Room 10
  {10, 19370, 1441.126220, 1564.366333, 15.650338, 0.000000, 90.000053, 0.000000}, // Room 10
  {10, 19370, 1441.126220, 1561.155639, 15.650338, 0.000000, 90.000053, 0.000000}, // Room 10
  {10, 19370, 1444.598388, 1564.366333, 15.650338, 0.000000, 90.000061, 0.000000}, // Room 10
  {10, 19370, 1444.598388, 1561.155639, 15.650338, 0.000000, 90.000061, 0.000000}, // Room 10
  {10, 19370, 1448.090576, 1564.366333, 15.650338, 0.000000, 90.000068, 0.000000}, // Room 10
  {10, 19370, 1448.090576, 1561.155639, 15.650338, 0.000000, 90.000068, 0.000000}, // Room 10
  {10, 19370, 1448.169921, 1570.779174, 15.650338, 0.000000, 90.000076, 0.000000}, // Room 10
  {10, 19370, 1448.169921, 1567.568481, 15.650338, 0.000000, 90.000076, 0.000000}, // Room 10
  {10, 19370, 1448.169921, 1573.989990, 15.650338, 0.000000, 90.000076, 0.000000}, // Room 10
  {10, 19379, 1441.187377, 1570.786132, 19.160358, 0.000000, 90.000053, 0.000000}, // Room 10
  {10, 19370, 1437.625610, 1564.366333, 19.160358, 0.000000, 90.000053, 0.000000}, // Room 10
  {10, 19370, 1437.625610, 1561.155639, 19.160358, 0.000000, 90.000053, 0.000000}, // Room 10
  {10, 19370, 1441.126220, 1564.366333, 19.160358, 0.000000, 90.000061, 0.000000}, // Room 10
  {10, 19370, 1441.126220, 1561.155639, 19.160358, 0.000000, 90.000061, 0.000000}, // Room 10
  {10, 19370, 1444.598388, 1564.366333, 19.160358, 0.000000, 90.000068, 0.000000}, // Room 10
  {10, 19370, 1444.598388, 1561.155639, 19.160358, 0.000000, 90.000068, 0.000000}, // Room 10
  {10, 19370, 1448.090576, 1564.366333, 19.160358, 0.000000, 90.000076, 0.000000}, // Room 10
  {10, 19370, 1448.090576, 1561.155639, 19.160358, 0.000000, 90.000076, 0.000000}, // Room 10
  {10, 19370, 1448.169921, 1570.779174, 19.160358, 0.000000, 90.000083, 0.000000}, // Room 10
  {10, 19370, 1448.169921, 1567.568481, 19.160358, 0.000000, 90.000083, 0.000000}, // Room 10
  {10, 19370, 1448.169921, 1573.989990, 19.160358, 0.000000, 90.000083, 0.000000}, // Room 10
  {11, 19387, 1437.263671, 1580.552612, 17.480339, 0.000000, 0.000037, 0.000000}, // Room 11
  {11, 19357, 1437.263671, 1577.352783, 17.480339, 0.000000, 0.000037, 0.000000}, // Room 11
  {11, 19449, 1445.195312, 1591.685424, 17.480339, 0.000060, 0.000015, 89.999816}, // Room 11
  {11, 19357, 1438.775390, 1591.685424, 17.480339, 0.000060, 0.000015, 89.999816}, // Room 11
  {11, 19449, 1445.195312, 1575.654052, 17.480339, 0.000067, 0.000015, 89.999794}, // Room 11
  {11, 19357, 1438.775390, 1575.654052, 17.480339, 0.000067, 0.000015, 89.999794}, // Room 11
  {11, 19449, 1449.915039, 1586.964843, 17.480339, 0.000000, 0.000037, 0.000000}, // Room 11
  {11, 19357, 1449.923583, 1577.342895, 17.480339, 0.000000, 0.000044, 0.000000}, // Room 11
  {11, 19357, 1449.923583, 1580.552612, 17.480339, 0.000000, 0.000044, 0.000000}, // Room 11
  {11, 19379, 1441.187377, 1586.819580, 15.650338, 0.000000, 90.000038, 0.000000}, // Room 11
  {11, 19370, 1437.625610, 1580.399780, 15.650338, 0.000000, 90.000038, 0.000000}, // Room 11
  {11, 19370, 1437.625610, 1577.189086, 15.650338, 0.000000, 90.000038, 0.000000}, // Room 11
  {11, 19370, 1441.126220, 1580.399780, 15.650338, 0.000000, 90.000045, 0.000000}, // Room 11
  {11, 19370, 1441.126220, 1577.189086, 15.650338, 0.000000, 90.000045, 0.000000}, // Room 11
  {11, 19370, 1444.598388, 1580.399780, 15.650338, 0.000000, 90.000053, 0.000000}, // Room 11
  {11, 19370, 1444.598388, 1577.189086, 15.650338, 0.000000, 90.000053, 0.000000}, // Room 11
  {11, 19370, 1448.090576, 1580.399780, 15.650338, 0.000000, 90.000061, 0.000000}, // Room 11
  {11, 19370, 1448.090576, 1577.189086, 15.650338, 0.000000, 90.000061, 0.000000}, // Room 11
  {11, 19370, 1448.169921, 1586.812622, 15.650338, 0.000000, 90.000068, 0.000000}, // Room 11
  {11, 19370, 1448.169921, 1583.601928, 15.650338, 0.000000, 90.000068, 0.000000}, // Room 11
  {11, 19370, 1448.169921, 1590.023437, 15.650338, 0.000000, 90.000068, 0.000000}, // Room 11
  {11, 19379, 1441.187377, 1586.819580, 19.160358, 0.000000, 90.000045, 0.000000}, // Room 11
  {11, 19370, 1437.625610, 1580.399780, 19.160358, 0.000000, 90.000045, 0.000000}, // Room 11
  {11, 19370, 1437.625610, 1577.189086, 19.160358, 0.000000, 90.000045, 0.000000}, // Room 11
  {11, 19370, 1441.126220, 1580.399780, 19.160358, 0.000000, 90.000053, 0.000000}, // Room 11
  {11, 19370, 1441.126220, 1577.189086, 19.160358, 0.000000, 90.000053, 0.000000}, // Room 11
  {11, 19370, 1444.598388, 1580.399780, 19.160358, 0.000000, 90.000061, 0.000000}, // Room 11
  {11, 19370, 1444.598388, 1577.189086, 19.160358, 0.000000, 90.000061, 0.000000}, // Room 11
  {11, 19370, 1448.090576, 1580.399780, 19.160358, 0.000000, 90.000068, 0.000000}, // Room 11
  {11, 19370, 1448.090576, 1577.189086, 19.160358, 0.000000, 90.000068, 0.000000}, // Room 11
  {11, 19370, 1448.169921, 1586.812622, 19.160358, 0.000000, 90.000076, 0.000000}, // Room 11
  {11, 19370, 1448.169921, 1583.601928, 19.160358, 0.000000, 90.000076, 0.000000}, // Room 11
  {11, 19370, 1448.169921, 1590.023437, 19.160358, 0.000000, 90.000076, 0.000000}, // Room 11
  {11, 19449, 1437.263793, 1586.974365, 17.480339, 0.000000, 0.000037, 0.000000}, // Room 11
  {12, 19449, 1437.263793, 1603.035034, 17.480339, 0.000000, 0.000029, 0.000000}, // Room 12
  {12, 19387, 1437.263671, 1596.613281, 17.480339, 0.000000, 0.000029, 0.000000}, // Room 12
  {12, 19357, 1437.263671, 1593.413452, 17.480339, 0.000000, 0.000029, 0.000000}, // Room 12
  {12, 19449, 1445.195312, 1607.746093, 17.480339, 0.000052, 0.000014, 89.999839}, // Room 12
  {12, 19357, 1438.775390, 1607.746093, 17.480339, 0.000052, 0.000014, 89.999839}, // Room 12
  {12, 19449, 1445.195312, 1591.714721, 17.480339, 0.000059, 0.000014, 89.999816}, // Room 12
  {12, 19357, 1438.775390, 1591.714721, 17.480339, 0.000059, 0.000014, 89.999816}, // Room 12
  {12, 19449, 1449.915039, 1603.025512, 17.480339, 0.000000, 0.000029, 0.000000}, // Room 12
  {12, 19357, 1449.923583, 1593.403564, 17.480339, 0.000000, 0.000037, 0.000000}, // Room 12
  {12, 19357, 1449.923583, 1596.613281, 17.480339, 0.000000, 0.000037, 0.000000}, // Room 12
  {12, 19379, 1441.187377, 1602.880249, 15.650338, 0.000000, 90.000030, 0.000000}, // Room 12
  {12, 19370, 1437.625610, 1596.460449, 15.650338, 0.000000, 90.000030, 0.000000}, // Room 12
  {12, 19370, 1437.625610, 1593.249755, 15.650338, 0.000000, 90.000030, 0.000000}, // Room 12
  {12, 19370, 1441.126220, 1596.460449, 15.650338, 0.000000, 90.000038, 0.000000}, // Room 12
  {12, 19370, 1441.126220, 1593.249755, 15.650338, 0.000000, 90.000038, 0.000000}, // Room 12
  {12, 19370, 1444.598388, 1596.460449, 15.650338, 0.000000, 90.000045, 0.000000}, // Room 12
  {12, 19370, 1444.598388, 1593.249755, 15.650338, 0.000000, 90.000045, 0.000000}, // Room 12
  {12, 19370, 1448.090576, 1596.460449, 15.650338, 0.000000, 90.000053, 0.000000}, // Room 12
  {12, 19370, 1448.090576, 1593.249755, 15.650338, 0.000000, 90.000053, 0.000000}, // Room 12
  {12, 19370, 1448.169921, 1602.873291, 15.650338, 0.000000, 90.000061, 0.000000}, // Room 12
  {12, 19370, 1448.169921, 1599.662597, 15.650338, 0.000000, 90.000061, 0.000000}, // Room 12
  {12, 19370, 1448.169921, 1606.084106, 15.650338, 0.000000, 90.000061, 0.000000}, // Room 12
  {12, 19379, 1441.187377, 1602.880249, 19.160358, 0.000000, 90.000038, 0.000000}, // Room 12
  {12, 19370, 1437.625610, 1596.460449, 19.160358, 0.000000, 90.000038, 0.000000}, // Room 12
  {12, 19370, 1437.625610, 1593.249755, 19.160358, 0.000000, 90.000038, 0.000000}, // Room 12
  {12, 19370, 1441.126220, 1596.460449, 19.160358, 0.000000, 90.000045, 0.000000}, // Room 12
  {12, 19370, 1441.126220, 1593.249755, 19.160358, 0.000000, 90.000045, 0.000000}, // Room 12
  {12, 19370, 1444.598388, 1596.460449, 19.160358, 0.000000, 90.000053, 0.000000}, // Room 12
  {12, 19370, 1444.598388, 1593.249755, 19.160358, 0.000000, 90.000053, 0.000000}, // Room 12
  {12, 19370, 1448.090576, 1596.460449, 19.160358, 0.000000, 90.000061, 0.000000}, // Room 12
  {12, 19370, 1448.090576, 1593.249755, 19.160358, 0.000000, 90.000061, 0.000000}, // Room 12
  {12, 19370, 1448.169921, 1602.873291, 19.160358, 0.000000, 90.000068, 0.000000}, // Room 12
  {12, 19370, 1448.169921, 1599.662597, 19.160358, 0.000000, 90.000068, 0.000000}, // Room 12
  {12, 19370, 1448.169921, 1606.084106, 19.160358, 0.000000, 90.000068, 0.000000} // Room 12
};

new const FlatLowAreaPos[][e_flatAreaPos] = {
  {1, 1418.79, 1558.10, 1433.18, 1574.96, 10.93}, // Room 1
  {2, 1418.77, 1574.99, 1433.12, 1591.02, 10.93}, // Room 2
  {3, 1418.81, 1591.02, 1433.07, 1607.81, 10.93}, // Room 3
  {4, 1436.33, 1558.10, 1450.72, 1574.96, 10.93}, // Room 4
  {5, 1436.31, 1574.99, 1450.66, 1591.02, 10.93}, // Room 5
  {6, 1436.35, 1591.02, 1450.61, 1607.81, 10.93}, // Room 6
  {7, 1418.79, 1558.79, 1433.18, 1575.65, 16.74}, // Room 7
  {8, 1418.77, 1575.68, 1433.12, 1591.71, 16.74}, // Room 8
  {9, 1418.81, 1591.71, 1433.07, 1608.51, 16.74}, // Room 9
  {10, 1436.46, 1558.79, 1450.85, 1575.65, 16.74}, // Room 10
  {11, 1436.44, 1575.68, 1450.79, 1591.71, 16.74}, // Room 11
  {12, 1436.48, 1591.71, 1450.74, 1608.51, 16.74} // Room 12
};

function OnLoadFlatStructure(flatid) {
  new rows = cache_num_rows(),
    str[128],
    slot = cellmin;

  Iter_Init(FlatStructures);
  for (new i = 0; i < rows; i ++) if ((slot = Iter_Free(FlatStructures[flatid])) != cellmin) {
    Iter_Add(FlatStructures[flatid], slot);

    cache_get_value_int(i, "ID", FlatStructure[flatid][slot][structID]);
    cache_get_value_int(i, "Model", FlatStructure[flatid][slot][structModel]);
    
    cache_get_value(i, "Position", str);
    sscanf(str, "p<|>fff", FlatStructure[flatid][slot][structPos][0], FlatStructure[flatid][slot][structPos][1], FlatStructure[flatid][slot][structPos][2]);

    cache_get_value(i, "Rotation", str);
    sscanf(str, "p<|>fff", FlatStructure[flatid][slot][structRot][0], FlatStructure[flatid][slot][structRot][1], FlatStructure[flatid][slot][structRot][2]);

    cache_get_value(i, "Material", str);
    sscanf(str, "p<|>dd", FlatStructure[flatid][slot][structMaterial], FlatStructure[flatid][slot][structColor]);

    FlatStructure_Refresh(flatid, slot);
  }
  return 1;
}

function OnLoadStaticStructure(flatid) {
  new rows = cache_num_rows(),
    str[128],
    slot = cellmin;
  
  Iter_Init(FlatStaticStructs);
  for (new i = 0; i < rows; i ++) if ((slot = Iter_Free(FlatStaticStructs[flatid])) != cellmin) {
    Iter_Add(FlatStaticStructs[flatid], slot);

    cache_get_value_int(i, "ID", FlatStaticStruct[flatid][slot][structID]);
    cache_get_value_int(i, "Model", FlatStaticStruct[flatid][slot][structModel]);
    
    cache_get_value(i, "Position", str);
    sscanf(str, "p<|>fff", FlatStaticStruct[flatid][slot][structPos][0], FlatStaticStruct[flatid][slot][structPos][1], FlatStaticStruct[flatid][slot][structPos][2]);

    cache_get_value(i, "Rotation", str);
    sscanf(str, "p<|>fff", FlatStaticStruct[flatid][slot][structRot][0], FlatStaticStruct[flatid][slot][structRot][1], FlatStaticStruct[flatid][slot][structRot][2]);

    cache_get_value(i, "Material", str);
    sscanf(str, "p<|>dd", FlatStaticStruct[flatid][slot][structMaterial], FlatStaticStruct[flatid][slot][structColor]);

    FlatStructure_Refresh(flatid, slot, false);
  }
  return 1;
}

function OnFlatStructureCreated(flatid, slot, isCustom) {
  if (!Iter_Contains(FlatStructures[flatid], slot) && !Iter_Contains(FlatStaticStructs[flatid], slot))
    return 0;
  
  if (isCustom) FlatStructure[flatid][slot][structID] = cache_insert_id(), FlatStructure_Save(flatid, slot);
  else FlatStaticStruct[flatid][slot][structID] = cache_insert_id(), FlatStructure_Save(flatid, slot, false);
  return 1;
}

FlatStructure_Create(flatid, modelid, Float:x, Float:y, Float:z, Float:rx = 0.0, Float:ry = 0.0, Float:rz = 0.0, bool:isCustom = true) {
  if (isCustom) {
    new slot;
    
    if (!Iter_Contains(FlatRooms, flatid))
      return 0;
    
    if ((slot = Iter_Free(FlatStructures[flatid])) != cellmin) {
      Iter_Add(FlatStructures[flatid], slot);
      
      FlatStructure[flatid][slot][structModel] = modelid;
      FlatStructure[flatid][slot][structPos][0] = x;
      FlatStructure[flatid][slot][structPos][1] = y;
      FlatStructure[flatid][slot][structPos][2] = z;
      FlatStructure[flatid][slot][structRot][0] = rx;
      FlatStructure[flatid][slot][structRot][1] = ry;
      FlatStructure[flatid][slot][structRot][2] = rz;
      FlatStructure[flatid][slot][structMaterial] = 0;
      FlatStructure[flatid][slot][structColor] = 0;
      
      FlatStructure_Refresh(flatid, slot);

      mysql_tquery(g_SQL, "INSERT INTO `flat_structure` (`Static`) VALUES ('0')", "OnFlatStructureCreated", "ddd", flatid, slot, 1);
      return slot;
    }

    return cellmin;
  } else {
    new slot;
    
    if (!Iter_Contains(FlatRooms, flatid))
      return 0;
    
    if ((slot = Iter_Free(FlatStaticStructs[flatid])) != cellmin) {
      Iter_Add(FlatStaticStructs[flatid], slot);
      
      FlatStaticStruct[flatid][slot][structModel] = modelid;
      FlatStaticStruct[flatid][slot][structPos][0] = x;
      FlatStaticStruct[flatid][slot][structPos][1] = y;
      FlatStaticStruct[flatid][slot][structPos][2] = z;
      FlatStaticStruct[flatid][slot][structRot][0] = rx;
      FlatStaticStruct[flatid][slot][structRot][1] = ry;
      FlatStaticStruct[flatid][slot][structRot][2] = rz;
      FlatStaticStruct[flatid][slot][structMaterial] = 0;
      FlatStaticStruct[flatid][slot][structColor] = 0;
      
      FlatStructure_Refresh(flatid, slot, false);

      mysql_tquery(g_SQL, "INSERT INTO `flat_structure` (`Static`) VALUES ('1')", "OnFlatStructureCreated", "ddd", flatid, slot, 0);
      return slot;
    }

    return cellmin;
  }
}

CreateFlatInterior(flatid, roomid) {
  new flatBase = Flat_ReturnID(flatid), id = cellmin;

  if (flatBase != -1) {
    switch (FlatData[flatBase][flatType]) {
      case FLAT_TYPE_HIGH: {
        for (new i = 0; i < sizeof(FlatHighInterior); i ++) if (FlatHighInterior[i][objRoomID] == roomid) {
          id = FlatStructure_Create(flatid, FlatHighInterior[i][objModel], FlatHighInterior[i][objPosX], FlatHighInterior[i][objPosY], FlatHighInterior[i][objPosZ], FlatHighInterior[i][objRotX], FlatHighInterior[i][objRotY], FlatHighInterior[i][objRotZ], false);
          
          if (id == cellmin) break;
        }

        FlatRoom[flatid][flatRoomAreaPos][0] = FlatHighAreaPos[roomid-1][minX];
        FlatRoom[flatid][flatRoomAreaPos][1] = FlatHighAreaPos[roomid-1][minY];
        FlatRoom[flatid][flatRoomAreaPos][2] = FlatHighAreaPos[roomid-1][maxX];
        FlatRoom[flatid][flatRoomAreaPos][3] = FlatHighAreaPos[roomid-1][maxY];
        FlatRoom[flatid][flatRoomAreaPos][4] = FlatHighAreaPos[roomid-1][zPos];

        #if defined DEBUG_MODE
          printf("[function  CreateFlatInterior]: AreaPos Room ID %d: %f, %f, %f, %f, %f", roomid, FlatHighAreaPos[roomid-1][minX], FlatHighAreaPos[roomid-1][minY], FlatHighAreaPos[roomid-1][maxX], FlatHighAreaPos[roomid-1][maxY], FlatHighAreaPos[roomid-1][zPos]);
        #endif

        FlatRoom_Refresh(flatid);
        FlatRoom_Save(flatid);
      }
      case FLAT_TYPE_MEDIUM: {
        for (new i = 0; i < sizeof(FlatMediumInterior); i ++) if (FlatMediumInterior[i][objRoomID] == roomid) {
          id = FlatStructure_Create(flatid, FlatMediumInterior[i][objModel], FlatMediumInterior[i][objPosX], FlatMediumInterior[i][objPosY], FlatMediumInterior[i][objPosZ], FlatMediumInterior[i][objRotX], FlatMediumInterior[i][objRotY], FlatMediumInterior[i][objRotZ], false);

          if (id == cellmin) break;
        }

        FlatRoom[flatid][flatRoomAreaPos][0] = FlatMediumAreaPos[roomid-1][minX];
        FlatRoom[flatid][flatRoomAreaPos][1] = FlatMediumAreaPos[roomid-1][minY];
        FlatRoom[flatid][flatRoomAreaPos][2] = FlatMediumAreaPos[roomid-1][maxX];
        FlatRoom[flatid][flatRoomAreaPos][3] = FlatMediumAreaPos[roomid-1][maxY];
        FlatRoom[flatid][flatRoomAreaPos][4] = FlatMediumAreaPos[roomid-1][zPos];

        #if defined DEBUG_MODE
          printf("[function  CreateFlatInterior]: AreaPos Room ID %d: %f, %f, %f, %f, %f", roomid, FlatMediumAreaPos[roomid-1][minX], FlatMediumAreaPos[roomid-1][minY], FlatMediumAreaPos[roomid-1][maxX], FlatMediumAreaPos[roomid-1][maxY], FlatMediumAreaPos[roomid-1][zPos]);
        #endif

        FlatRoom_Refresh(flatid);
        FlatRoom_Save(flatid);
      }
      case FLAT_TYPE_LOW: {
        for (new i = 0; i < sizeof(FlatLowInterior); i ++) if (FlatLowInterior[i][objRoomID] == roomid) {
          id = FlatStructure_Create(flatid, FlatLowInterior[i][objModel], FlatLowInterior[i][objPosX], FlatLowInterior[i][objPosY], FlatLowInterior[i][objPosZ], FlatLowInterior[i][objRotX], FlatLowInterior[i][objRotY], FlatLowInterior[i][objRotZ], false);

          if (id == cellmin) break;
        }

        FlatRoom[flatid][flatRoomAreaPos][0] = FlatLowAreaPos[roomid-1][minX];
        FlatRoom[flatid][flatRoomAreaPos][1] = FlatLowAreaPos[roomid-1][minY];
        FlatRoom[flatid][flatRoomAreaPos][2] = FlatLowAreaPos[roomid-1][maxX];
        FlatRoom[flatid][flatRoomAreaPos][3] = FlatLowAreaPos[roomid-1][maxY];
        FlatRoom[flatid][flatRoomAreaPos][4] = FlatLowAreaPos[roomid-1][zPos];

        #if defined DEBUG_MODE
          printf("[function  CreateFlatInterior]: AreaPos Room ID %d: %f, %f, %f, %f, %f", roomid, FlatLowAreaPos[roomid-1][minX], FlatLowAreaPos[roomid-1][minY], FlatLowAreaPos[roomid-1][maxX], FlatLowAreaPos[roomid-1][maxY], FlatLowAreaPos[roomid-1][zPos]);
        #endif

        FlatRoom_Refresh(flatid);
        FlatRoom_Save(flatid);
      }
    }
  }

  return 1;
}

FlatStructure_Refresh(flatid, slot, bool:isCustom = true) {
  if (!Iter_Contains(FlatRooms, flatid))
    return 0;

  if (!Iter_Contains(FlatStructures[flatid], slot) && !Iter_Contains(FlatStaticStructs[flatid], slot))
    return 0;
  
  if (isCustom) {
    if (!IsValidDynamicObject(FlatStructure[flatid][slot][structObject])) {
      FlatStructure[flatid][slot][structObject] = CreateDynamicObject(FlatStructure[flatid][slot][structModel], FlatStructure[flatid][slot][structPos][0], FlatStructure[flatid][slot][structPos][1], FlatStructure[flatid][slot][structPos][2], FlatStructure[flatid][slot][structRot][0], FlatStructure[flatid][slot][structRot][1], FlatStructure[flatid][slot][structRot][2], FlatRoom[flatid][flatRoomWorld], FlatRoom[flatid][flatRoomInterior], -1, STREAMER_OBJECT_SD, 200.00, FlatRoom[flatid][flatRoomArea]);
    }

    FlatStructure_Update(flatid, slot);
    foreach (new i : Player) if (IsPlayerInRangeOfPoint(i, 5.0, FlatStructure[flatid][slot][structPos][0], FlatStructure[flatid][slot][structPos][1], FlatStructure[flatid][slot][structPos][2])) {
      Streamer_Update(i);
    }
  } else {
    if (!IsValidDynamicObject(FlatStaticStruct[flatid][slot][structObject])) {
      FlatStaticStruct[flatid][slot][structObject] = CreateDynamicObject(FlatStaticStruct[flatid][slot][structModel], FlatStaticStruct[flatid][slot][structPos][0], FlatStaticStruct[flatid][slot][structPos][1], FlatStaticStruct[flatid][slot][structPos][2], FlatStaticStruct[flatid][slot][structRot][0], FlatStaticStruct[flatid][slot][structRot][1], FlatStaticStruct[flatid][slot][structRot][2], FlatRoom[flatid][flatRoomWorld], FlatRoom[flatid][flatRoomInterior], -1, STREAMER_OBJECT_SD, 200.00, (FlatStaticStruct[flatid][slot][structModel] == 1502 || FlatStaticStruct[flatid][slot][structModel] == 1536) ? (-1) : (FlatRoom[flatid][flatRoomArea]));
    }

    FlatStructure_Update(flatid, slot, false);
    foreach (new i : Player) if (IsPlayerInRangeOfPoint(i, 5.0, FlatStaticStruct[flatid][slot][structPos][0], FlatStaticStruct[flatid][slot][structPos][1], FlatStaticStruct[flatid][slot][structPos][2])) {
      Streamer_Update(i);
    }
  }

  return 1;
}

FlatStructure_Update(flatid, slot, bool:isCustom = true) {
  if (!Iter_Contains(FlatRooms, flatid))
    return 0;

  if (!Iter_Contains(FlatStructures[flatid], slot) && !Iter_Contains(FlatStaticStructs[flatid], slot))
    return 0;
  
  new objectid;
  if (isCustom) {
    objectid = FlatStructure[flatid][slot][structObject];
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_X, FlatStructure[flatid][slot][structPos][0]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_Y, FlatStructure[flatid][slot][structPos][1]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_Z, FlatStructure[flatid][slot][structPos][2]);

    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_R_X, FlatStructure[flatid][slot][structRot][0]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_R_Y, FlatStructure[flatid][slot][structRot][1]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_R_Z, FlatStructure[flatid][slot][structRot][2]);

    Streamer_SetIntData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_WORLD_ID, FlatRoom[flatid][flatRoomWorld]);
    Streamer_SetIntData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_INTERIOR_ID, FlatRoom[flatid][flatRoomInterior]);

    Streamer_SetIntData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_AREA_ID, FlatRoom[flatid][flatRoomArea]);

    if (FlatStructure[flatid][slot][structMaterial] > 0) {
      if (FlatStructure[flatid][slot][structModel] == 1502 || FlatStructure[flatid][slot][structModel] == 14414) SetDynamicObjectMaterial(FlatStructure[flatid][slot][structObject], 1, GetTModel(FlatStructure[flatid][slot][structMaterial]), GetTXDName(FlatStructure[flatid][slot][structMaterial]), GetTextureName(FlatStructure[flatid][slot][structMaterial]), FlatStructure[flatid][slot][structColor]);
      else SetDynamicObjectMaterial(objectid, 0, GetTModel(FlatStructure[flatid][slot][structMaterial]), GetTXDName(FlatStructure[flatid][slot][structMaterial]), GetTextureName(FlatStructure[flatid][slot][structMaterial]), FlatStructure[flatid][slot][structColor]);
    }
  } else {
    objectid = FlatStaticStruct[flatid][slot][structObject];
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_X, FlatStaticStruct[flatid][slot][structPos][0]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_Y, FlatStaticStruct[flatid][slot][structPos][1]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_Z, FlatStaticStruct[flatid][slot][structPos][2]);

    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_R_X, FlatStaticStruct[flatid][slot][structRot][0]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_R_Y, FlatStaticStruct[flatid][slot][structRot][1]);
    Streamer_SetFloatData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_R_Z, FlatStaticStruct[flatid][slot][structRot][2]);

    Streamer_SetIntData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_WORLD_ID, FlatRoom[flatid][flatRoomWorld]);
    Streamer_SetIntData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_INTERIOR_ID, FlatRoom[flatid][flatRoomInterior]);

    Streamer_SetIntData(STREAMER_TYPE_OBJECT, objectid, E_STREAMER_AREA_ID, (FlatStaticStruct[flatid][slot][structModel] == 1502 || FlatStaticStruct[flatid][slot][structModel] == 1536) ? (-1) : (FlatRoom[flatid][flatRoomArea]));

    if (FlatStaticStruct[flatid][slot][structMaterial] > 0) {
      SetDynamicObjectMaterial(objectid, (FlatStaticStruct[flatid][slot][structModel] == 1502) ? (1) : (0), GetTModel(FlatStaticStruct[flatid][slot][structMaterial]), GetTXDName(FlatStaticStruct[flatid][slot][structMaterial]), GetTextureName(FlatStaticStruct[flatid][slot][structMaterial]), FlatStaticStruct[flatid][slot][structColor]);
    }
  }
  return 1;
}

FlatStructure_Save(flatid, slot, bool:isCustom = true, mode = SAVE_STRUCTURE_ALL) {
  if (!Iter_Contains(FlatRooms, flatid))
    return 0;

  if (!Iter_Contains(FlatStructures[flatid], slot) && !Iter_Contains(FlatStaticStructs[flatid], slot))
    return 0;

  if (isCustom) {
    switch (mode) {
      case SAVE_STRUCTURE_ALL: {
        new query[2024];

        format(query, sizeof(query), "UPDATE `flat_structure` SET `Flatid`='%d', `Model`='%d', `Position`='%.2f|%.2f|%.2f', `Rotation`='%.2f|%.2f|%.2f', `Material`='%d|%d' WHERE `ID`='%d' AND `Static`='0'",
          FlatRoom[flatid][flatRoomID],
          FlatStructure[flatid][slot][structModel],
          FlatStructure[flatid][slot][structPos][0],
          FlatStructure[flatid][slot][structPos][1],
          FlatStructure[flatid][slot][structPos][2],
          FlatStructure[flatid][slot][structRot][0],
          FlatStructure[flatid][slot][structRot][1],
          FlatStructure[flatid][slot][structRot][2],
          FlatStructure[flatid][slot][structMaterial],
          FlatStructure[flatid][slot][structColor],
          FlatStructure[flatid][slot][structID]
        );
        mysql_tquery(g_SQL, query);
      }
      case SAVE_STRUCTURE_MATERIAL: {
        new query[2024];

        format(query, sizeof(query), "UPDATE `flat_structure` SET `Flatid`='%d', `Material`='%d|%d' WHERE `ID`='%d' AND `Static`='0'",
          FlatRoom[flatid][flatRoomID],
          FlatStructure[flatid][slot][structMaterial],
          FlatStructure[flatid][slot][structColor],
          FlatStructure[flatid][slot][structID]
        );
        mysql_tquery(g_SQL, query);
      }
      case SAVE_STRUCTURE_MODEL: {
        new query[2024];

        format(query, sizeof(query), "UPDATE `flat_structure` SET `Flatid`='%d', `Model`='%d' WHERE `ID`='%d' AND `Static`='0'",
          FlatRoom[flatid][flatRoomID],
          FlatStructure[flatid][slot][structModel],
          FlatStructure[flatid][slot][structID]
        );
        mysql_tquery(g_SQL, query);
      }
      case SAVE_STRUCTURE_POS: {
        new query[2024];

        format(query, sizeof(query), "UPDATE `flat_structure` SET `Flatid`='%d', `Position`='%.2f|%.2f|%.2f', `Rotation`='%.2f|%.2f|%.2f' WHERE `ID`='%d' AND `Static`='0'",
          FlatRoom[flatid][flatRoomID],
          FlatStructure[flatid][slot][structPos][0],
          FlatStructure[flatid][slot][structPos][1],
          FlatStructure[flatid][slot][structPos][2],
          FlatStructure[flatid][slot][structRot][0],
          FlatStructure[flatid][slot][structRot][1],
          FlatStructure[flatid][slot][structRot][2],
          FlatStructure[flatid][slot][structID]
        );
        mysql_tquery(g_SQL, query);
      }
    }
  } 
  else 
  {
    switch (mode) {
      case SAVE_STRUCTURE_ALL: {
        new query[2024];

        format(query, sizeof(query), "UPDATE `flat_structure` SET `Flatid`='%d', `Model`='%d', `Position`='%.2f|%.2f|%.2f', `Rotation`='%.2f|%.2f|%.2f', `Material`='%d|%d' WHERE `ID`='%d' AND `Static`='1'",
          FlatRoom[flatid][flatRoomID],
          FlatStaticStruct[flatid][slot][structModel],
          FlatStaticStruct[flatid][slot][structPos][0],
          FlatStaticStruct[flatid][slot][structPos][1],
          FlatStaticStruct[flatid][slot][structPos][2],
          FlatStaticStruct[flatid][slot][structRot][0],
          FlatStaticStruct[flatid][slot][structRot][1],
          FlatStaticStruct[flatid][slot][structRot][2],
          FlatStaticStruct[flatid][slot][structMaterial],
          FlatStaticStruct[flatid][slot][structColor],
          FlatStaticStruct[flatid][slot][structID]
        );
        mysql_tquery(g_SQL, query);
      }
      case SAVE_STRUCTURE_MATERIAL: {
        new query[2024];

        format(query, sizeof(query), "UPDATE `flat_structure` SET `Flatid`='%d', `Material`='%d|%d' WHERE `ID`='%d' AND `Static`='1'",
          FlatRoom[flatid][flatRoomID],
          FlatStaticStruct[flatid][slot][structMaterial],
          FlatStaticStruct[flatid][slot][structColor],
          FlatStaticStruct[flatid][slot][structID]
        );
        mysql_tquery(g_SQL, query);
      }
      case SAVE_STRUCTURE_MODEL: {
        new query[2024];

        format(query, sizeof(query), "UPDATE `flat_structure` SET `Flatid`='%d', `Model`='%d' WHERE `ID`='%d' AND `Static`='1'",
          FlatRoom[flatid][flatRoomID],
          FlatStaticStruct[flatid][slot][structModel],
          FlatStaticStruct[flatid][slot][structID]
        );
        mysql_tquery(g_SQL, query);
      }
      case SAVE_STRUCTURE_POS: {
        new query[2024];

        format(query, sizeof(query), "UPDATE `flat_structure` SET `Flatid`='%d', `Position`='%.2f|%.2f|%.2f', `Rotation`='%.2f|%.2f|%.2f' WHERE `ID`='%d' AND `Static`='1'",
          FlatRoom[flatid][flatRoomID],
          FlatStaticStruct[flatid][slot][structPos][0],
          FlatStaticStruct[flatid][slot][structPos][1],
          FlatStaticStruct[flatid][slot][structPos][2],
          FlatStaticStruct[flatid][slot][structRot][0],
          FlatStaticStruct[flatid][slot][structRot][1],
          FlatStaticStruct[flatid][slot][structRot][2],
          FlatStaticStruct[flatid][slot][structID]
        );
        mysql_tquery(g_SQL, query);
      }
    }
  }

  return 1;
}


FlatStructure_DeleteAll(flatid, bool:isCustom = true) {
  if (Iter_Contains(FlatRooms, flatid)) {
    if (isCustom) {
      foreach (new slot : FlatStructures[flatid]) {
        if (IsValidDynamicObject(FlatStructure[flatid][slot][structObject]))
        DestroyDynamicObject(FlatStructure[flatid][slot][structObject]), FlatStructure[flatid][slot][structObject] = STREAMER_TAG_OBJECT:INVALID_STREAMER_ID;
      
        new query[128];
        mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat_structure` WHERE `ID`='%d' AND `Static`='0'", FlatStructure[flatid][slot][structID]);
        mysql_tquery(g_SQL, query);
        new tmp_FlatStructure[structEnum];
        FlatStructure[flatid][slot] = tmp_FlatStructure;  
      }

      Iter_Clear(FlatStructures[flatid]);
    } else {
      foreach (new slot : FlatStaticStructs[flatid]) {
        if (IsValidDynamicObject(FlatStaticStruct[flatid][slot][structObject]))
          DestroyDynamicObject(FlatStaticStruct[flatid][slot][structObject]), FlatStaticStruct[flatid][slot][structObject] = STREAMER_TAG_OBJECT:INVALID_STREAMER_ID;

        new query[128];
        mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat_structure` WHERE `ID`='%d' AND `Static`='1'", FlatStaticStruct[flatid][slot][structID]);
        mysql_tquery(g_SQL, query);
        new tmp_FlatStaticStruct[structEnum];
        FlatStaticStruct[flatid][slot] = tmp_FlatStaticStruct;
      }

      Iter_Clear(FlatStaticStructs[flatid]);
    }
  }
  return 1;
}

FlatStructure_Delete(flatid, slot, bool:isCustom = true) {
  if (!Iter_Contains(FlatStructures[flatid], slot) && !Iter_Contains(FlatStaticStructs[flatid], slot))
    return 0;

  if (isCustom) {
    if (IsValidDynamicObject(FlatStructure[flatid][slot][structObject]))
      DestroyDynamicObject(FlatStructure[flatid][slot][structObject]), FlatStructure[flatid][slot][structObject] = STREAMER_TAG_OBJECT:INVALID_STREAMER_ID;
    
    new query[128];
    mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat_structure` WHERE `ID`='%d' AND `Static`='0'", FlatStructure[flatid][slot][structID]);
    mysql_tquery(g_SQL, query);
    new tmp_FlatStructure[structEnum];
    FlatStructure[flatid][slot] = tmp_FlatStructure;  

    Iter_Remove(FlatStructures[flatid], slot);
  } else {
    if (IsValidDynamicObject(FlatStaticStruct[flatid][slot][structObject]))
      DestroyDynamicObject(FlatStaticStruct[flatid][slot][structObject]), FlatStaticStruct[flatid][slot][structObject] = STREAMER_TAG_OBJECT:INVALID_STREAMER_ID;

    new query[128];
    mysql_format(g_SQL, query, sizeof(query), "DELETE FROM `flat_structure` WHERE `ID`='%d' AND `Static`='1'", FlatStaticStruct[flatid][slot][structID]);
    mysql_tquery(g_SQL, query);
    new tmp_FlatStaticStruct[structEnum];
    FlatStaticStruct[flatid][slot] = tmp_FlatStaticStruct;

    Iter_Remove(FlatStaticStructs[flatid], slot);
  }

  return 1;
}

FlatStructure_GetCount(flatid) {
  return Iter_Count(FlatStructures[flatid]);
}

FlatStructure_Copy(flatid, slot) {
  new current = FlatStructure[flatid][slot][structObject],
    model,
    Float:curPos[3],
    Float:curRot[3],
    matModel,
    txdName[32],
    textureName[32],
    matColor,
    textureID = 0;

  model = Streamer_GetIntData(STREAMER_TYPE_OBJECT, current, E_STREAMER_MODEL_ID);
  Streamer_GetFloatData(STREAMER_TYPE_OBJECT, current, E_STREAMER_X, curPos[0]);
  Streamer_GetFloatData(STREAMER_TYPE_OBJECT, current, E_STREAMER_Y, curPos[1]);
  Streamer_GetFloatData(STREAMER_TYPE_OBJECT, current, E_STREAMER_Z, curPos[2]);
  Streamer_GetFloatData(STREAMER_TYPE_OBJECT, current, E_STREAMER_R_X, curRot[0]);
  Streamer_GetFloatData(STREAMER_TYPE_OBJECT, current, E_STREAMER_R_Y, curRot[1]);
  Streamer_GetFloatData(STREAMER_TYPE_OBJECT, current, E_STREAMER_R_Z, curRot[2]);

  if (FlatStructure[flatid][slot][structMaterial] > 0) {
    GetDynamicObjectMaterial(current, 0, matModel, txdName, textureName, matColor);
    textureID = FlatStructure[flatid][slot][structMaterial];
  }

  new copyId = FlatStructure_Create(flatid, model, curPos[0], curPos[1], curPos[2], curRot[0], curRot[1], curRot[2], true);

  if (copyId == cellmin)
    return cellmin;

  if (textureID != 0) SetDynamicObjectMaterial(FlatStructure[flatid][copyId][structObject], 0, matModel, txdName, textureName, matColor), FlatStructure[flatid][copyId][structMaterial] = textureID, FlatStructure_Save(flatid, copyId, true, SAVE_STRUCTURE_MATERIAL);

  return copyId;
}

FlatStructure_Show(playerid, flatid, bool:isCustom = true) {
  static
    count = 0,
    info[MAX_FLAT_STRUCTURE + MAX_STATIC_STRUCTURE * 64];

  if (isCustom) {
    format(info, sizeof(info), "Model\tDistance\n");
    foreach (new i : FlatStructures[flatid]) {
      format(info, sizeof(info), "%s%s\t%.2f\n", info, GetStructureNameByModel(FlatStructure[flatid][i][structModel]), GetPlayerDistanceFromPoint(playerid, FlatStructure[flatid][i][structPos][0], FlatStructure[flatid][i][structPos][1], FlatStructure[flatid][i][structPos][2]));
      ListedFlatStructures[playerid][count++] = i;
    }

    Dialog_Show(playerid, Dialog_FlatCustom, DIALOG_STYLE_TABLIST_HEADERS, "Flat Structures", info, "Select", "Back");
  } else {
    format(info, sizeof(info), "Model\tDistance\n");
    foreach (new i : FlatStaticStructs[flatid]) {
      format(info, sizeof(info), "%s"ORANGE_E"Static\t%.2f\n", info, GetPlayerDistanceFromPoint(playerid, FlatStaticStruct[flatid][i][structPos][0], FlatStaticStruct[flatid][i][structPos][1], FlatStaticStruct[flatid][i][structPos][2]));
      ListedFlatStructures[playerid][count++] = i;
    }

    Dialog_Show(playerid, Dialog_FlatStaticStruct, DIALOG_STYLE_TABLIST_HEADERS, "Flat Structures", info, "Select", "Back");
  }

  return 1;
}

Dialog:Dialog_FlatStaticStruct(playerid, response, listitem, inputtext[]) {
  if (!response)
    return Dialog_Show(playerid, Select_FlatStructures, DIALOG_STYLE_LIST, "Select Flat Structure", "Static\nCustom", "Select", "Back");

  new flatid;

  if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
    new slot = ListedFlatStructures[playerid][listitem];
    pData[playerid][pEditStructure] = slot;
    pData[playerid][pEditFlatStructure] = flatid;
    Dialog_Show(playerid, Dialog_FlatStatic, DIALOG_STYLE_LIST, "Edit Flat Structure", "Retexture", "Select", "Back");
  }
  return 1;
}

Dialog:Dialog_FlatStatic(playerid, response, listitem, inputtext[]) {
  if (!response)
    return Dialog_Show(playerid, Select_FlatStructures, DIALOG_STYLE_LIST, "Select Flat Structure", "Static\nCustom", "Select", "Back");

  new flatid;

  if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
    switch (listitem) {
      case 0: {
        Dialog_Show(playerid, Dialog_StaticRetexture, DIALOG_STYLE_INPUT, "Retexture Flat Structure", "Please input the texture name below:\n"YELLOW_E"[model] [txdname] [texture] [opt: alpha] [opt: red] [opt: green] [opt: blue]", "Retexture", "Cancel");
      }
    }
  }
  return 1;
}

Dialog:Dialog_FlatCustom(playerid, response, listitem, inputtext[]) {
  if (!response)
    return Dialog_Show(playerid, Select_FlatStructures, DIALOG_STYLE_LIST, "Select Flat Structure", "Static\nCustom", "Select", "Back");

  new flatid;

  if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
    new slot = ListedFlatStructures[playerid][listitem];
    pData[playerid][pEditStructure] = slot;
    pData[playerid][pEditFlatStructure] = flatid;
    Dialog_Show(playerid, Dialog_EditFlatCustom, DIALOG_STYLE_LIST, "Edit Flat Structure", "Move\nRetexture\nCopy\nDestroy", "Select", "Back");
  }
  return 1;
}

Dialog:Dialog_EditFlatCustom(playerid, response, listitem, inputtext[]) {
  if (!response)
    return Dialog_Show(playerid, Select_FlatStructures, DIALOG_STYLE_LIST, "Select Flat Structure", "Static\nCustom", "Select", "Back");

  new flatid;

  if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
    new slot = pData[playerid][pEditStructure];

    switch (listitem) {
      case 0: {
        pData[playerid][pEditFlatStructure] = flatid;
        EditDynamicObject(playerid, FlatStructure[flatid][slot][structObject]);
        SendCustomMessage(playerid, "BUILDER", "You're now editing %s", GetStructureNameByModel(FlatStructure[flatid][slot][structModel]));
      }
      case 1: {
        pData[playerid][pEditFlatStructure] = flatid;
        Dialog_Show(playerid, Dialog_FlatRetexture, DIALOG_STYLE_INPUT, "Retexture Flat Structure", "Please input the texture name below:\n"YELLOW_E"[model] [txdname] [texture] [opt: alpha] [opt: red] [opt: green] [opt: blue]", "Retexture", "Cancel");
      }
      case 2: {
        new price;

        for (new id = 0; id < sizeof(g_aHouseStructure); id ++) if (g_aHouseStructure[id][e_StructureModel] == FlatStructure[flatid][slot][structModel]) {
          price = g_aHouseStructure[id][e_StructureCost];
        }

        if (pData[playerid][pComponent] < price)
          return Error(playerid, "You need %d Component(s) to copy this structure.", price);

        new copyId = FlatStructure_Copy(flatid, slot);

        if (copyId == cellmin)
          return Error(playerid, "Your flat has reached maximum of structure");
        
        pData[playerid][pComponent] -= price;
        pData[playerid][pEditStructure] = copyId;
        pData[playerid][pEditFlatStructure] = flatid;
        EditDynamicObject(playerid, FlatStructure[flatid][copyId][structObject]);
        SendCustomMessage(playerid, "BUILDER", "You have copied structure for "GREEN_E"%d component(s)", price);
        SendCustomMessage(playerid, "BUILDER", "You're now editing copied object of %s.", GetStructureNameByModel(FlatStructure[flatid][slot][structModel]));
      }
      case 3: {
        SendCustomMessage(playerid, "BUILDER", "You've destroyed %s", GetStructureNameByModel(FlatStructure[flatid][slot][structModel]));
        FlatStructure_Delete(flatid, slot);
      }
    }
  }
  return 1;
}

Dialog:Dialog_FlatRetexture(playerid, response, listitem, inputtext[]) {
  if (response) {
    new flatid;

    if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
      new slot = pData[playerid][pEditStructure];

      new model, color[4];
      new const txdname[32], texture[32];
      if (isnull(inputtext))
        return Dialog_Show(playerid, Dialog_FlatRetexture, DIALOG_STYLE_INPUT, "Retexture Flat Structure", "Please input the texture name below:\n"YELLOW_E"[model] [txdname] [texture] [opt: alpha] [opt: red] [opt: green] [opt: blue]", "Retexture", "Cancel"), Error(playerid, "Invalid input!");

      if (sscanf(inputtext, "ds[32]s[32]D(0)D(0)D(0)D(0)",model,txdname,texture,color[0],color[1],color[2],color[3]))
        return Dialog_Show(playerid, Dialog_FlatRetexture, DIALOG_STYLE_INPUT, "Retexture Flat Structure", "Please input the texture name below:\n"YELLOW_E"[model] [txdname] [texture] [opt: alpha] [opt: red] [opt: green] [opt: blue]", "Retexture", "Cancel"), Error(playerid, "Invalid input!");
      
      if (!IsValidTexture(texture))
        return Dialog_Show(playerid, Dialog_FlatRetexture, DIALOG_STYLE_INPUT, "Retexture Flat Structure", "Please input the texture name below:\n"YELLOW_E"[model] [txdname] [texture] [opt: alpha] [opt: red] [opt: green] [opt: blue]", "Retexture", "Cancel"), Error(playerid, "Invalid texture name!");
      
      if (pData[playerid][pComponent] < 10)
        return Error(playerid, "You need 10 components to retexture the flat structure");
      
      FlatStructure[flatid][slot][structMaterial] = GetTextureIndex(texture);
      FlatStructure[flatid][slot][structColor] = RGBAToInt(color[1], color[2], color[3], color[0]);
      FlatStructure_Refresh(flatid, slot);
      FlatStructure_Save(flatid, slot, true, SAVE_STRUCTURE_MATERIAL);
    }
  }
  return 1;
}

Dialog:Dialog_StaticRetexture(playerid, response, listitem, inputtext[]) {
  if (response) {
    new flatid;

    if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
      new slot = pData[playerid][pEditStructure];

      new model, color[4];
      new const txdname[32], texture[32];
      if (isnull(inputtext))
        return Dialog_Show(playerid, Dialog_StaticRetexture, DIALOG_STYLE_INPUT, "Retexture Flat Structure", "Please input the texture name below:\n"YELLOW_E"[model] [txdname] [texture] [opt: alpha] [opt: red] [opt: green] [opt: blue]", "Retexture", "Cancel"), Error(playerid, "Invalid input!");

      if (sscanf(inputtext, "ds[32]s[32]D(0)D(0)D(0)D(0)",model,txdname,texture,color[0],color[1],color[2],color[3]))
        return Dialog_Show(playerid, Dialog_StaticRetexture, DIALOG_STYLE_INPUT, "Retexture Flat Structure", "Please input the texture name below:\n"YELLOW_E"[model] [txdname] [texture] [opt: alpha] [opt: red] [opt: green] [opt: blue]", "Retexture", "Cancel"), Error(playerid, "Invalid input!");
      
      if (!IsValidTexture(texture))
        return Dialog_Show(playerid, Dialog_StaticRetexture, DIALOG_STYLE_INPUT, "Retexture Flat Structure", "Please input the texture name below:\n"YELLOW_E"[model] [txdname] [texture] [opt: alpha] [opt: red] [opt: green] [opt: blue]", "Retexture", "Cancel"), Error(playerid, "Invalid texture name!");
      
      if (pData[playerid][pComponent] < 10)
        return Error(playerid, "You need 10 components to retexture the flat structure");
      
      FlatStaticStruct[flatid][slot][structMaterial] = GetTextureIndex(texture);
      FlatStaticStruct[flatid][slot][structColor] = RGBAToInt(color[1], color[2], color[3], color[0]);
      FlatStructure_Refresh(flatid, slot, false);
      FlatStructure_Save(flatid, slot, false, SAVE_STRUCTURE_MATERIAL);
    }
  }
  return 1;
}

Dialog:Flat_Structures(playerid,response,listitem,inputtext[]) {
  if (!response)
    return callcmd::flatmenu(playerid);

  new flatid;
  if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
    switch (listitem) {
      case 0: {
        new str[128];
        strcat(str, "Type\tCost (components)\n");
        for (new i = 0; i < sizeof(g_aHouseStructure); i ++) {
          format(str, sizeof(str), "%s\t%d\n", str, g_aHouseStructure[i][e_StructureName], g_aHouseStructure[i][e_StructureCost]);
        }
        Dialog_Show(playerid, Flat_StructureAdd, DIALOG_STYLE_TABLIST_HEADERS, "Flat Structure Modification", str, "Select", "Back");
      }
      case 1: {
        pData[playerid][pEditFlatStructure] = flatid;
        SelectStructureType[playerid] = STRUCTURE_SELECT_EDITOR;
        SelectObject(playerid);
        SendCustomMessage(playerid, "BUILDER", "Please select the structure, you wish to move.");
      }
      case 2: {
        pData[playerid][pEditFlatStructure] = flatid;
        SelectStructureType[playerid] = STRUCTURE_SELECT_RETEXTURE;
        SelectObject(playerid);
        SendCustomMessage(playerid, "BUILDER", "Please select the structure, you wish to retexture.");
      }
      case 3: {
        pData[playerid][pEditFlatStructure] = flatid;
        SelectStructureType[playerid] = STRUCTURE_SELECT_DELETE;
        SelectObject(playerid);
        SendCustomMessage(playerid, "BUILDER", "Please select the structure, you wish to destroy.");
      }
      case 4: {
        pData[playerid][pEditFlatStructure] = flatid;
        SelectStructureType[playerid] = STRUCTURE_SELECT_COPY;
        SelectObject(playerid);
        SendCustomMessage(playerid, "BUILDER", "Please select the structure, you wish to copy.");
      }
      case 5: {
        if (!FlatStructure_GetCount(flatid))
          return Error(playerid, "There are no structures in this flat.");

        pData[playerid][pEditFlatStructure] = flatid;
        Dialog_Show(playerid, Dialog_ConfirmDestroy, DIALOG_STYLE_MSGBOX, "Destroy All Structures", RED_E"WARNING:\n"WHITE_E"Are you sure you want to destroy all structures in this flat?", "Yes", "No");
      }
      case 6: {
        Dialog_Show(playerid, Select_FlatStructures, DIALOG_STYLE_LIST, "Flat Structure List", "Static\nCustom", "Select", "Back");
      }
      case 7: {
        pData[playerid][pEditFurnFlat] = flatid;
        SelectFurnitureType[playerid] = FURNITURE_SELECT_MOVE;
        SelectObject(playerid);
        SendCustomMessage(playerid, "BUILDER", "Plase select the furniture, you wish to move.");
      }
      case 8: {
        pData[playerid][pEditFurnFlat] = flatid;
        SelectFurnitureType[playerid] = FURNITURE_SELECT_DESTROY;
        SelectObject(playerid);
        SendCustomMessage(playerid, "BUILDER", "Plase select the furniture, you wish to destroy.");
      }
      case 9: {
        pData[playerid][pEditFurnFlat] = flatid;
        SelectFurnitureType[playerid] = FURNITURE_SELECT_STORE;
        SelectObject(playerid);
        SendCustomMessage(playerid, "BUILDER", "Plase select the furniture, you wish to store.");
      }
      case 10: {
        FlatFurniture_Show(playerid, flatid);
      }
    }
  }
  return 1;
}

Dialog:Dialog_ConfirmDestroy(playerid,response,listitem,inputtext[]) {
  if (!response)
    return Dialog_Show(playerid, Flat_Structures, DIALOG_STYLE_LIST, "Select Flat Structure", "Add structure\nMove structure\nRetexture structure\nDestroy structure\nCopy structure\nDestroy all structure\nStructure list\nMove furniture\nDestroy furniture\nStore furniture\nFurniture list", "Select", "Back");
  
  new flatid = pData[playerid][pEditFlatStructure];

  if (flatid != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
    FlatStructure_DeleteAll(flatid);
    SendCustomMessage(playerid, "BUILDER", "All structures in this flat have been destroyed.");
  }
  return 1;
}

Dialog:Flat_StructureAdd(playerid,response,listitem,inputtext[]) {
  if (!response)
    return callcmd::flatmenu(playerid);

  new flatid;
  if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
    static
      Float:x,
      Float:y,
      Float:z,
      Float:angle
    ;

    GetPlayerPos(playerid, x, y, z);
    GetPlayerFacingAngle(playerid, angle);

    if (pData[playerid][pComponent] < g_aHouseStructure[listitem][e_StructureCost])
      return Error(playerid, "You need %d component to created %s structure", g_aHouseStructure[listitem][e_StructureCost], g_aHouseStructure[listitem][e_StructureName]);
    
    if (FlatStructure_GetCount(flatid) >= FlatRoom_GetItemsMax(flatid))
      return Error(playerid, "You can only have %d custom structure in your flat.", FlatRoom_GetItemsMax(flatid));
    
    new slot = FlatStructure_Create(flatid, g_aHouseStructure[listitem][e_StructureModel], x+1, y, z, 0.0, 0.0, angle, true);

    if (slot == cellmin)
      return Error(playerid, "You can't create more structure in this flat");
    
    pData[playerid][pComponent] -= g_aHouseStructure[listitem][e_StructureCost];
    pData[playerid][pEditStructure] = slot;
    pData[playerid][pEditFlatStructure] = flatid;
    EditDynamicObject(playerid, FlatStructure[flatid][slot][structObject]);
    SendCustomMessage(playerid, "FLAT", "You've been created "YELLOW_E"%s "WHITE_E"structure for "GREEN_E"%d components", g_aHouseStructure[listitem][e_StructureName], g_aHouseStructure[listitem][e_StructureCost]);
  }
  return 1;
}

Dialog:Select_FlatStructures(playerid,response,listitem,inputtext[]) {
  if (!response)
    return Dialog_Show(playerid, Flat_Structures, DIALOG_STYLE_LIST, "Select Flat Structure", "Add structure\nMove structure\nRetexture structure\nDestroy structure\nCopy structure\nDestroy all structure\nStructure list\nMove furniture\nDestroy furniture\nStore furniture\nFurniture list", "Select", "Back");

  new flatid;
  if ((flatid = FlatRoom_Inside(playerid)) != -1 && (FlatRoom_IsOwner(playerid, flatid) || FlatRoom_IsBuilder(playerid, flatid))) {
    switch (listitem) {
      case 0: {
        FlatStructure_Show(playerid, flatid, false);
      }
      case 1: {
        FlatStructure_Show(playerid, flatid, true);
      }
    }
  }
  return 1;
}

MappingFlat() {
  new tmpobjid1;
  // Flat High
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2507.654785, 12.654688, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2498.020751, 12.654688, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2488.397949, 12.654688, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2478.763916, 12.654688, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2510.866699, 14.474684, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2507.656982, 14.460637, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1767.379760, -2504.446044, 14.460637, 180.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2501.234375, 14.460637, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2498.024658, 14.460637, 0.000000, -0.000009, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2494.828613, 14.474684, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2491.618896, 14.460637, 0.000000, -0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1767.379760, -2488.407958, 14.460637, -0.000004, 0.000000, -180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2485.196289, 14.460637, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2481.986572, 14.460637, 0.000000, -0.000012, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(10008, 1762.435668, -2472.257812, 23.370643, 0.000001, 0.000000, -98.899978, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 10101, "2notherbuildsfe", "Bow_Abpave_Gen", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2507.654785, 16.314699, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(10008, 1762.435668, -2472.257812, 17.200628, 0.000001, 0.000000, -92.299987, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 10101, "2notherbuildsfe", "Bow_Abpave_Gen", 0x00000000);
  tmpobjid1 = CreateDynamicObject(10008, 1762.435668, -2472.257812, 29.580678, 0.000001, 0.000000, -106.899925, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 10101, "2notherbuildsfe", "Bow_Abpave_Gen", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2498.016113, 14.474684, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2501.225585, 14.460637, 0.000000, -0.000004, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1756.910156, -2504.436523, 14.460637, -0.000004, 0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2481.972656, 14.474684, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2510.857910, 14.460637, 0.000000, -0.000014, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2485.182128, 14.460637, 0.000000, -0.000001, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1756.910156, -2488.393066, 14.460637, -0.000004, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2494.814453, 14.460637, 0.000000, -0.000012, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2507.648437, 14.460637, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2491.604980, 14.460637, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2498.020751, 16.314699, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2488.397949, 16.314699, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2478.763916, 16.314699, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.088867, -2512.421386, 11.464689, 90.000000, 0.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2469.143310, 12.654688, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1756.896728, -2478.763916, 11.524682, 180.000000, 180.000000, 180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1767.397949, -2478.763916, 11.524682, 180.000000, 180.000000, 180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2467.374267, 17.494691, 90.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2467.374267, 27.104681, 90.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1767.397949, -2469.151367, 11.524682, 180.000000, 180.000000, 180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1756.896728, -2469.142578, 11.524682, 180.000000, 180.000000, 180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1756.896728, -2478.763916, 22.014780, -0.000004, 360.000000, 0.000007, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1767.397949, -2478.763916, 22.014780, -0.000004, 360.000000, 0.000007, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1767.397949, -2469.151367, 22.014780, -0.000004, 360.000000, 0.000007, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1756.896728, -2469.142578, 22.014780, -0.000004, 360.000000, 0.000007, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1756.896728, -2478.763916, 32.484882, -0.000004, 360.000000, 0.000007, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1767.397949, -2478.763916, 32.484882, -0.000004, 360.000000, 0.000007, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1767.397949, -2469.151367, 32.484882, -0.000004, 360.000000, 0.000007, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1756.896728, -2469.142578, 32.484882, -0.000004, 360.000000, 0.000007, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2511.318359, 18.794757, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2501.684326, 18.794757, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2492.061523, 18.794757, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2482.427490, 18.794757, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2511.318359, 22.454767, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2501.684326, 22.454767, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2492.061523, 22.454767, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2482.427490, 22.454767, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.088867, -2512.551757, 17.604757, 90.000000, 0.000014, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19447, 1756.031738, -2477.708251, 20.600702, 0.000000, 0.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1765.652954, -2477.738281, 20.620698, 0.000000, 0.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19834, 1759.758544, -2476.496337, 19.720706, 0.000000, 0.000000, -42.799991, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00FFFF00);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2511.148193, 24.994762, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2501.514160, 24.994762, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2491.891357, 24.994762, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2482.257324, 24.994762, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2511.148193, 28.654771, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2501.514160, 28.654771, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2491.891357, 28.654771, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2482.257324, 28.654771, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.088867, -2512.552246, 23.804761, 90.000000, 180.000015, -89.999992, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1758.582153, -2477.528076, 26.820716, 0.000000, -0.000001, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19447, 1768.211059, -2477.528076, 26.820716, 0.000000, -0.000001, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19834, 1759.670776, -2476.244384, 25.920711, 0.000000, -0.000000, -42.799987, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00FFFF00);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2511.148193, 31.204792, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2501.514160, 31.204792, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2491.891357, 31.204792, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2482.257324, 31.204792, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 18757, "vcinteriors", "dt_officflr1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2511.148193, 34.864799, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2501.514160, 34.864799, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2491.891357, 34.864799, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2482.257324, 34.864799, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.088867, -2512.532958, 30.014791, 90.000000, 0.000029, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19362, 1757.772827, -2477.608154, 33.020778, 0.000000, -0.000004, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19447, 1767.392089, -2477.608154, 33.010761, 0.000000, -0.000004, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19362, 1759.129028, -2476.322998, 32.990745, 0.000003, -0.000003, -135.299880, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19362, 1759.500854, -2474.878662, 33.010711, 0.000003, -0.000003, 132.799972, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2472.627929, 34.864799, 0.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19376, 1762.237304, -2467.374267, 36.204677, 90.000000, 90.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2494.828613, 20.634695, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2491.618896, 20.620647, 0.000000, -0.000004, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1767.379760, -2488.407958, 20.620647, -0.000004, 0.000001, 179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2485.196289, 20.620647, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2481.986572, 20.620647, 0.000000, -0.000014, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2510.866699, 20.634759, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2507.656982, 20.620712, 0.000000, -0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1767.379760, -2504.446044, 20.620712, -0.000004, 0.000000, -180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2501.234375, 20.620712, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2498.024658, 20.620712, 0.000000, -0.000012, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2498.016113, 20.634723, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2501.225585, 20.620674, 0.000000, -0.000001, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1756.910156, -2504.436523, 20.620674, -0.000004, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2510.857910, 20.620674, 0.000000, -0.000012, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2507.648437, 20.620674, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2481.972656, 20.634723, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2485.182128, 20.620674, 0.000000, 0.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1756.910156, -2488.393066, 20.620674, -0.000004, -0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2494.814453, 20.620674, 0.000000, -0.000009, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2491.604980, 20.620674, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1762.440917, -2477.718261, 20.600702, 0.000000, 0.000000, 89.199989, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1760.086303, -2474.993652, 14.490633, 0.000000, 0.000000, -43.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1757.426635, -2476.116455, 14.470641, 0.000000, 0.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1762.286743, -2474.413818, 14.470641, 0.000000, 0.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1765.145141, -2475.426757, 14.470641, 0.000000, 0.000000, 50.199993, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19428, 1766.996826, -2476.969726, 14.470641, 0.000000, 0.000000, 50.199993, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19447, 1762.178955, -2476.820800, 17.524942, 0.000000, -45.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19447, 1762.178955, -2479.013183, 23.775756, 0.000000, -45.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1761.792236, -2477.528076, 26.820716, 0.000000, -0.000001, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2510.866699, 26.834796, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2507.656982, 26.820749, 0.000000, -0.000004, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1767.379760, -2504.446044, 26.820749, -0.000004, 0.000001, 179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2501.234375, 26.820749, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2498.024658, 26.820749, 0.000000, -0.000014, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2494.828613, 26.834730, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2491.618896, 26.820680, 0.000000, -0.000007, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1767.379760, -2488.407958, 26.820680, -0.000004, 0.000004, 179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2485.196289, 26.820680, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2481.986572, 26.820680, 0.000000, -0.000017, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2498.016113, 26.834764, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2501.225585, 26.820714, 0.000000, 0.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1756.910156, -2504.436523, 26.820714, -0.000004, -0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2510.857910, 26.820714, 0.000000, -0.000009, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2507.648437, 26.820714, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2481.972656, 26.824760, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2485.182128, 26.810710, 0.000000, 0.000001, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1756.910156, -2488.393066, 26.810710, -0.000004, -0.000004, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2494.814453, 26.810710, 0.000000, -0.000007, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2491.604980, 26.810710, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19447, 1762.178955, -2478.810546, 29.892265, 0.000000, -45.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 15034, "genhotelsave", "walp57S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2510.866699, 33.014812, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2507.656982, 33.000762, 0.000000, -0.000007, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1767.379760, -2504.446044, 33.000762, -0.000004, 0.000004, 179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2501.234375, 33.000762, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2498.024658, 33.000762, 0.000000, -0.000017, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2494.828613, 33.004814, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2491.618896, 32.990760, 0.000000, -0.000009, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1767.379760, -2488.407958, 32.990760, -0.000004, 0.000007, 179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.379760, -2485.196289, 32.990760, 0.000000, 180.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1767.388793, -2481.986572, 32.990760, 0.000000, -0.000019, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2498.016113, 33.034805, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2501.225585, 33.020751, 0.000000, 0.000001, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1756.910156, -2504.436523, 33.020751, -0.000004, -0.000004, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2510.857910, 33.020751, 0.000000, -0.000007, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2507.648437, 33.020751, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2481.972656, 33.024742, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2485.182128, 33.010688, 0.000000, 0.000004, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1756.910156, -2488.393066, 33.010688, -0.000004, -0.000007, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.901367, -2494.814453, 33.010688, 0.000000, -0.000004, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19355, 1756.910156, -2491.604980, 33.010688, 0.000000, 180.000000, -179.999938, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19385, 1760.971923, -2477.608154, 33.020778, 0.000000, -0.000004, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14581, "ab_mafiasuitea", "walp45S", 0x00000000);
  tmpobjid1 = CreateDynamicObject(1569, 1761.898559, -2512.325927, 12.750626, 0.000000, 0.000000, 180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14706, "labig2int2", "vegdoor1_int", 0x00000000);
  tmpobjid1 = CreateDynamicObject(1569, 1761.887329, -2512.325927, 12.750626, 0.000000, 0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterial(tmpobjid1, 0, 14706, "labig2int2", "vegdoor1_int", 0x00000000);
  tmpobjid1 = CreateDynamicObject(2714, 1761.779296, -2477.634521, 27.980678, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterialText(tmpobjid1, 0, "3rd Floor", 130, "Fixedsys", 140, 1, 0xFFFFFFFF, 0xFF000000, 1);
  tmpobjid1 = CreateDynamicObject(2714, 1760.999023, -2477.714599, 34.170684, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterialText(tmpobjid1, 0, "4th Floor", 130, "Fixedsys", 140, 1, 0xFFFFFFFF, 0xFF000000, 1);
  tmpobjid1 = CreateDynamicObject(2714, 1762.489624, -2477.832763, 21.720643, 0.000000, 0.000000, -0.799999, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterialText(tmpobjid1, 0, "2nd Floor", 130, "Fixedsys", 140, 1, 0xFFFFFFFF, 0xFF000000, 1);
  tmpobjid1 = CreateDynamicObject(2714, 1760.190795, -2475.065185, 15.630653, 0.000000, 0.000000, 46.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  SetDynamicObjectMaterialText(tmpobjid1, 0, "1st Floor", 130, "Fixedsys", 140, 1, 0xFFFFFFFF, 0xFF000000, 1);
  tmpobjid1 = CreateDynamicObject(3801, 1762.767333, -2474.753662, 15.030630, 0.000000, 0.000000, 275.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1893, 1761.583862, -2481.003173, 16.750648, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1893, 1761.583862, -2507.500244, 16.750648, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1757.275756, -2487.122558, 14.660634, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1757.275756, -2503.126220, 14.660634, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1767.036743, -2505.787841, 14.660634, 0.000000, 0.000000, 180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1767.036743, -2489.733398, 14.660634, 0.000000, 0.000000, 180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1763.580688, -2478.086181, 19.930620, 0.000000, 0.000000, 275.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1893, 1761.583862, -2481.003173, 22.910671, 0.000000, -0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1893, 1761.583862, -2507.500244, 22.910671, 0.000000, -0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1757.275756, -2487.122558, 20.820655, 0.000000, -0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1757.275756, -2503.126220, 20.820655, 0.000000, -0.000001, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1767.036743, -2505.787841, 20.820655, 0.000000, 0.000001, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1767.036743, -2489.733398, 20.820655, 0.000000, 0.000001, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1762.951416, -2477.889892, 26.090648, 0.000001, 0.000000, -84.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1893, 1761.583862, -2481.003173, 29.140701, 0.000000, -0.000004, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1893, 1761.583862, -2507.500244, 29.140701, 0.000000, -0.000004, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1757.275756, -2487.122558, 27.050685, 0.000000, -0.000004, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1757.275756, -2503.126220, 27.050685, 0.000000, -0.000004, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1767.036743, -2505.787841, 27.050685, 0.000000, 0.000004, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1767.036743, -2489.733398, 27.050685, 0.000000, 0.000004, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1762.164306, -2477.958740, 32.290611, 0.000003, 0.000000, -84.999977, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1893, 1761.583862, -2481.003173, 35.320655, 0.000000, -0.000007, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1893, 1761.583862, -2507.500244, 35.320655, 0.000000, -0.000007, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1757.275756, -2487.122558, 33.230644, 0.000000, -0.000007, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1757.275756, -2503.126220, 33.230644, 0.000000, -0.000007, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1767.036743, -2505.787841, 33.230644, 0.000000, 0.000007, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(3801, 1767.036743, -2489.733398, 33.230644, 0.000000, 0.000007, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2253, 1763.909301, -2512.058593, 14.030634, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2245, 1764.489990, -2512.058593, 14.010630, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2258, 1765.721801, -2512.313232, 14.750632, 0.000000, 0.000000, 180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2961, 1760.122924, -2512.332275, 14.450639, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2282, 1758.600585, -2511.832763, 14.440632, 0.000000, 0.000000, 180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(19935, 1764.234863, -2512.069091, 12.720626, 0.000000, 0.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2811, 1759.836425, -2512.000732, 12.700624, 0.000000, 0.000000, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2270, 1759.711914, -2476.232421, 14.100629, 0.000000, 0.000000, 45.699993, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2256, 1764.761962, -2475.235839, 14.930630, 0.000000, 0.000000, -39.900009, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2258, 1765.721801, -2512.423339, 20.920667, 0.000000, 0.000012, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2282, 1758.600585, -2511.942871, 20.610670, 0.000000, 0.000012, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2811, 1759.836425, -2512.110839, 18.870660, 0.000000, -0.000012, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2270, 1762.810058, -2511.931152, 19.750694, 0.000000, 0.000000, -180.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2258, 1765.721801, -2512.423339, 27.100688, 0.000000, 0.000014, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2282, 1758.600585, -2511.942871, 26.790691, 0.000000, 0.000014, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2811, 1759.836425, -2512.110839, 25.050682, 0.000000, -0.000014, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2270, 1762.810058, -2511.931152, 25.930715, 0.000000, 0.000001, 179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2258, 1765.721801, -2512.423339, 33.340713, 0.000000, 0.000017, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2282, 1758.600585, -2511.942871, 33.030715, 0.000000, 0.000017, -179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2811, 1759.836425, -2512.110839, 31.290708, 0.000000, -0.000017, 0.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2270, 1762.810058, -2511.931152, 32.170742, 0.000000, 0.000004, 179.999984, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  // tmpobjid1 = CreateDynamicObject(3666, 1798.820556, -2496.501220, 12.664672, -0.000012, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 1 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1798.820556, -2496.372070, 12.664672, -0.000007, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 2 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1798.820556, -2512.948242, 12.664672, -0.000012, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 1 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1766.618408, -2512.948242, 12.664672, -0.000012, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 1 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1766.625610, -2496.501220, 12.924682, -0.000009, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 1 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1766.635620, -2496.372070, 12.924682, -0.000004, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 2 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1798.820556, -2479.747314, 12.664672, -0.000007, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 2 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1757.622070, -2496.501220, 12.914678, -0.000014, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 3 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1766.635620, -2479.752197, 12.924682, -0.000004, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 2 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1757.622070, -2496.372070, 12.914678, -0.000009, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 4 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1757.622070, -2512.948242, 12.914678, -0.000014, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 3 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1725.419921, -2512.948242, 12.914678, -0.000014, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 3 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1725.427124, -2496.501220, 13.174689, -0.000012, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 3 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1725.437133, -2496.372070, 13.174689, -0.000007, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 4 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1757.622070, -2479.747314, 12.914678, -0.000009, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 4 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1725.437133, -2479.752197, 13.174689, -0.000007, 180.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);// Room 4 (MinX)
  tmpobjid1 = CreateDynamicObject(18981, 1779.953247, -2498.075927, 18.060632, 0.000000, 90.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(18981, 1744.333129, -2498.075927, 18.150627, 0.000000, 90.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(18981, 1779.953247, -2498.075927, 24.230714, -0.000007, 90.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(18981, 1744.333129, -2498.075927, 24.320709, -0.000007, 90.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(18981, 1779.953247, -2498.075927, 30.360755, -0.000009, 90.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(18981, 1744.333129, -2498.075927, 30.450750, -0.000009, 90.000000, 90.000000, -1, FLAT_HIGH_INTERIOR, -1, 50.00, 50.00);

  // Flat Medium
  tmpobjid1 = CreateDynamicObject(19387, 1457.302368, 1461.088623, 11.550304, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1457.307617, 1457.885375, 11.550304, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1457.307617, 1464.284912, 11.550304, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1455.627563, 1465.964599, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1452.417236, 1465.964599, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1449.217163, 1465.964599, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1446.017089, 1465.964599, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1442.806884, 1465.954589, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1439.596923, 1465.954589, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1436.386230, 1465.944580, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1433.177368, 1465.944580, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1431.664672, 1464.304321, 11.550304, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1431.664672, 1461.094238, 11.550304, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1431.664672, 1457.884277, 11.550304, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1433.217407, 1456.194458, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1436.417236, 1456.194458, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1439.628540, 1456.194458, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1442.828369, 1456.194458, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1446.038574, 1456.194458, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1449.237182, 1456.194458, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1452.448364, 1456.194458, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1455.627807, 1456.194458, 11.550304, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1436.732543, 1458.609008, 9.340312, 90.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1436.732543, 1463.538940, 9.340312, 90.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1446.723144, 1458.609008, 9.340312, 90.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1446.733032, 1463.538940, 9.340312, 90.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1456.732421, 1463.538940, 9.340312, 90.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1456.712524, 1458.609008, 9.340312, 90.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1432.251953, 1458.609008, 13.790341, 89.999992, 89.999992, -89.999992, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1432.251953, 1463.538940, 13.790341, 89.999992, 89.999992, -89.999992, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1442.242553, 1458.609008, 13.790341, 89.999992, 89.999992, -89.999992, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1442.252441, 1463.538940, 13.790341, 89.999992, 89.999992, -89.999992, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.251831, 1463.538940, 13.790341, 89.999992, 89.999992, -89.999992, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.231933, 1458.609008, 13.790341, 89.999992, 89.999992, -89.999992, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.298095, 1434.131347, 15.100333, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.368164, 1434.131347, 15.100333, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.298095, 1444.121948, 15.100333, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.368164, 1444.131835, 15.100333, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.368164, 1454.131225, 15.100333, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.298095, 1454.111328, 15.100333, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1454.830688, 1456.641723, 17.350351, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1458.033935, 1456.646972, 17.350351, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1451.634399, 1456.646972, 17.350351, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.954711, 1454.966918, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.954711, 1451.756591, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1449.954711, 1448.556518, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.954711, 1445.356445, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.964721, 1442.146240, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.964721, 1438.936279, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1449.974731, 1435.725585, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.974731, 1432.516723, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1451.614990, 1431.004028, 17.350351, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1454.825073, 1431.004028, 17.350351, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1458.035034, 1431.004028, 17.350351, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1432.556762, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1459.724853, 1435.756591, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1438.967895, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1442.167724, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1445.377929, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1459.724853, 1448.576538, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1451.787719, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1454.967163, 17.350351, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.310791, 1433.750732, 19.590383, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.380859, 1433.750732, 19.590383, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.310791, 1443.741333, 19.590383, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.380859, 1443.751220, 19.590383, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.380859, 1453.750610, 19.590383, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.310791, 1453.730712, 19.590383, 89.999992, 173.225967, -83.225975, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.278076, 1432.861083, 20.930316, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.348144, 1432.861083, 20.930316, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.278076, 1442.851684, 20.930316, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.348144, 1442.861572, 20.930316, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.348144, 1452.860961, 20.930316, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.278076, 1452.841064, 20.930316, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1454.830688, 1456.651733, 23.180347, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1458.033935, 1456.656982, 23.180347, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1451.634399, 1456.656982, 23.180347, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.954711, 1454.976928, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.954711, 1451.766601, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1449.954711, 1448.566528, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.954711, 1445.366455, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.964721, 1442.156250, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.964721, 1438.946289, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1449.974731, 1435.735595, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.974731, 1432.526733, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1451.614990, 1431.014038, 23.180347, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1454.825073, 1431.014038, 23.180347, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1458.035034, 1431.014038, 23.180347, 0.000029, 0.000007, 89.999877, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1432.566772, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1459.724853, 1435.766601, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1438.977905, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1442.177734, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1445.387939, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1459.724853, 1448.586547, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1451.797729, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1454.977172, 23.180347, 0.000007, -0.000029, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.310791, 1433.690673, 25.420379, 89.999992, 176.601181, -86.601173, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.380859, 1433.690673, 25.420379, 89.999992, 176.601181, -86.601173, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.310791, 1443.681274, 25.420379, 89.999992, 176.601181, -86.601173, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.380859, 1443.691162, 25.420379, 89.999992, 176.601181, -86.601173, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.380859, 1453.720092, 25.420379, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.310791, 1453.700195, 25.420379, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.298095, 1433.312500, 26.730321, 89.999992, 179.973526, -89.973373, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.368164, 1433.312500, 26.730321, 89.999992, 179.973526, -89.973373, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.298095, 1443.303100, 26.730321, 89.999992, 179.973526, -89.973373, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.368164, 1443.312988, 26.730321, 89.999992, 179.973526, -89.973373, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.368164, 1453.312377, 26.730321, 89.999992, 179.973526, -89.973373, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.298095, 1453.292480, 26.730321, 89.999992, 179.973526, -89.973373, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16640, "a51", "ws_stationfloor", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1454.830688, 1457.342407, 28.970342, 0.000045, 0.000007, 89.999832, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1458.033935, 1457.347656, 28.970342, 0.000045, 0.000007, 89.999832, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1451.634399, 1457.347656, 28.970342, 0.000045, 0.000007, 89.999832, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.954711, 1455.667602, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.954711, 1452.457275, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1449.954711, 1449.257202, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.954711, 1446.057128, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.964721, 1442.846923, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.964721, 1439.636962, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1449.974731, 1436.426269, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1449.974731, 1433.217407, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1451.614990, 1431.704711, 28.970342, 0.000045, 0.000007, 89.999832, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1454.825073, 1431.704711, 28.970342, 0.000045, 0.000007, 89.999832, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1458.035034, 1431.704711, 28.970342, 0.000045, 0.000007, 89.999832, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1433.257446, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1459.724853, 1436.457275, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1439.668579, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1442.868408, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1446.078613, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1459.724853, 1449.277221, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1452.488403, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19357, 1459.724853, 1455.667846, 28.970342, 0.000007, -0.000045, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 8130, "vgsschurch", "vgschurchwall04_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.310791, 1433.290283, 31.210374, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.380859, 1433.290283, 31.210374, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.310791, 1443.280883, 31.210374, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.380859, 1443.290771, 31.210374, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1452.380859, 1453.290161, 31.210374, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1457.310791, 1453.270263, 31.210374, 89.999992, 179.149383, -89.149330, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18663, 1454.834960, 1457.242065, 30.160320, 0.000000, 0.000000, 90.699996, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterialText(tmpobjid1, 0, "4th\nFloor", 140, "Calibri", 80, 1, 0xFFFFFFFF, 0x00000000, 1);
  tmpobjid1 = CreateDynamicObject(18663, 1454.853515, 1456.541748, 24.370319, 0.000000, 0.000000, 90.699996, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterialText(tmpobjid1, 0, "3rd\nFloor", 140, "Calibri", 80, 1, 0xFFFFFFFF, 0x00000000, 1);
  tmpobjid1 = CreateDynamicObject(18663, 1454.853515, 1456.541748, 18.550319, 0.000000, 0.000000, 90.699996, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterialText(tmpobjid1, 0, "2nd\nFloor", 140, "Calibri", 80, 1, 0xFFFFFFFF, 0x00000000, 1);
  tmpobjid1 = CreateDynamicObject(18663, 1457.196899, 1461.141235, 12.730324, 0.000000, 0.000000, -0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterialText(tmpobjid1, 0, "1st\nFloor", 140, "Calibri", 80, 1, 0xFFFFFFFF, 0x00000000, 1);
  tmpobjid1 = CreateDynamicObject(1569, 1431.854248, 1461.105102, 9.830294, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 14706, "labig2int2", "vegdoor1_int", 0x00000000);
  tmpobjid1 = CreateDynamicObject(1569, 1431.854248, 1461.095336, 9.830294, 0.000000, 0.000000, -90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 14706, "labig2int2", "vegdoor1_int", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19368, 1430.316406, 1459.499389, 10.750317, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 18996, "mattextures", "sampblack", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19368, 1430.316406, 1462.680419, 10.750317, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 18996, "mattextures", "sampblack", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19368, 1430.316406, 1461.089843, 12.400314, 0.000000, 90.000000, 180.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 18996, "mattextures", "sampblack", 0x00000000);
  tmpobjid1 = CreateDynamicObject(14596, 1458.578613, 1463.184448, 20.520292, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  // tmpobjid1 = CreateDynamicObject(1215, 1431.395629, 1465.594360, 10.370295, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 1 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1441.126586, 1456.436401, 9.960296, 0.000000, -0.000007, 179.999725, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 3 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1457.537475, 1465.669555, 10.370305, 0.000000, 0.000007, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 2 (Min Y)
  // tmpobjid1 = CreateDynamicObject(1215, 1431.395629, 1495.334838, 10.370295, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 1 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1457.537475, 1495.333374, 10.370305, 0.000000, 0.000007, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 2 (MaxX)
  tmpobjid1 = CreateDynamicObject(2251, 1432.082397, 1458.996337, 10.690320, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2251, 1432.082397, 1463.136718, 10.690320, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(631, 1456.541381, 1459.313110, 10.740298, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(631, 1456.541381, 1462.894409, 10.740298, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(19174, 1457.198486, 1464.049316, 11.710311, 0.000000, 0.000000, 270.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2276, 1456.708374, 1458.338867, 11.710311, 0.000000, 0.000000, 270.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2282, 1456.708374, 1457.088989, 10.580308, 0.000000, 0.000000, 270.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2273, 1432.282470, 1458.914672, 11.820310, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2266, 1432.282470, 1457.395019, 10.700309, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2255, 1432.282470, 1463.695190, 11.130311, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2287, 1432.282470, 1464.994750, 10.360310, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2251, 1452.755859, 1456.220825, 16.480310, 0.000000, 0.000000, -90.000038, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2251, 1456.896240, 1456.220825, 16.480310, 0.000000, 0.000000, -90.000038, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(631, 1453.072631, 1431.761840, 16.530288, 0.000000, 0.000000, -90.000038, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(631, 1456.653930, 1431.761840, 16.530288, 0.000000, 0.000000, -90.000038, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(19174, 1457.808837, 1431.104736, 17.500301, 0.000000, 0.000000, 179.999862, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2276, 1452.098388, 1431.594848, 17.500301, 0.000000, 0.000000, 179.999862, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2282, 1450.848510, 1431.594848, 16.370300, 0.000000, 0.000000, 179.999862, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2273, 1452.674194, 1456.020751, 17.610300, 0.000000, 0.000000, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2266, 1451.154541, 1456.020751, 16.490299, 0.000000, 0.000000, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2255, 1457.454711, 1456.020751, 16.920299, 0.000000, 0.000000, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2287, 1458.754272, 1456.020751, 16.150299, 0.000000, 0.000000, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2270, 1454.858276, 1431.594848, 17.500301, 0.000000, 0.000000, 179.999862, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2251, 1452.755859, 1456.270874, 22.270311, -0.000022, 0.000000, -89.999969, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2251, 1456.896240, 1456.270874, 22.270311, -0.000022, 0.000000, -89.999969, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(631, 1453.072631, 1431.761840, 22.320289, -0.000014, 0.000000, -89.999992, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(631, 1456.653930, 1431.761840, 22.320289, -0.000014, 0.000000, -89.999992, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(19174, 1457.808837, 1431.104736, 23.290302, 0.000000, -0.000014, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2276, 1452.098388, 1431.594848, 23.290302, 0.000000, -0.000014, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2282, 1450.848510, 1431.594848, 22.160301, 0.000000, -0.000014, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2273, 1452.674194, 1456.070800, 23.400302, 0.000000, 0.000022, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2266, 1451.154541, 1456.070800, 22.280300, 0.000000, 0.000022, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2255, 1457.454711, 1456.070800, 22.710300, 0.000000, 0.000022, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2287, 1458.754272, 1456.070800, 21.940301, 0.000000, 0.000022, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2270, 1454.858276, 1431.594848, 23.290302, 0.000000, -0.000014, 179.999771, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2251, 1452.755859, 1456.929565, 28.080307, -0.000022, 0.000000, -89.999969, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2251, 1456.896240, 1456.929565, 28.080307, -0.000022, 0.000000, -89.999969, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(631, 1453.072631, 1432.470581, 28.130285, -0.000022, 0.000000, -89.999969, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(631, 1456.653930, 1432.470581, 28.130285, -0.000022, 0.000000, -89.999969, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(19174, 1457.808837, 1431.813476, 29.100297, 0.000000, -0.000022, 179.999725, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2276, 1452.098388, 1432.303588, 29.100297, 0.000000, -0.000022, 179.999725, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2282, 1450.848510, 1432.303588, 27.970296, 0.000000, -0.000022, 179.999725, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2273, 1452.674194, 1456.729492, 29.210298, 0.000000, 0.000022, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2266, 1451.154541, 1456.729492, 28.090295, 0.000000, 0.000022, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2255, 1457.454711, 1456.729492, 28.520296, 0.000000, 0.000022, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2287, 1458.754272, 1456.729492, 27.750297, 0.000000, 0.000022, -0.000037, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(2270, 1454.858276, 1432.303588, 29.100297, 0.000000, -0.000022, 179.999725, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  // tmpobjid1 = CreateDynamicObject(1215, 1444.474487, 1465.722900, 10.100295, 0.000000, 0.000014, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 2 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1444.474487, 1495.286376, 10.350291, 0.000000, 0.000014, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 2 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1444.326660, 1495.296875, 10.350291, 0.000000, 0.000007, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 1 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1444.326660, 1465.723144, 10.100295, 0.000000, 0.000007, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 1 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1441.276123, 1456.436157, 9.960296, 0.000000, -0.000014, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 4 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1428.164306, 1456.366699, 9.900296, 0.000000, 0.000000, -90.000038, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 3 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1428.164306, 1426.863891, 9.900296, 0.000000, 0.000000, -90.000038, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 3 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1441.126586, 1426.876220, 9.860298, 0.000000, -0.000007, 179.999725, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 3 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1441.276123, 1426.875610, 9.860298, 0.000000, -0.000014, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 4 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1454.296997, 1426.875610, 9.860298, 0.000000, -0.000014, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 4 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1454.296997, 1456.424804, 9.860298, 0.000000, -0.000014, 179.999679, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 4 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.424926, 1440.460815, 15.600296, -0.000007, -0.000014, -90.000183, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 6 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.425170, 1440.618652, 15.600296, -0.000014, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 5 (MinX)
  tmpobjid1 = CreateDynamicObject(18981, 1472.141479, 1441.408325, 26.480007, 0.000012, 90.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // penyangga lantai 4
  // tmpobjid1 = CreateDynamicObject(1215, 1459.442749, 1453.461059, 15.890301, -0.000007, -0.000014, -90.000183, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 5 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.095092, 1427.628784, 15.670297, 0.000000, -0.000014, -90.000205, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 6 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.064453, 1453.591430, 15.890306, -0.000007, -0.000014, -90.000183, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 5 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.044067, 1440.460815, 15.710289, -0.000007, -0.000014, -90.000183, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 6 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.044677, 1440.618652, 15.710289, -0.000014, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 5 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.563964, 1427.628784, 15.670297, 0.000000, -0.000014, -90.000205, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 6 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.191162, 1443.818115, 15.800295, 0.000000, -0.000014, 89.999809, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 7 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.190917, 1443.640625, 15.800295, 0.000007, -0.000014, 89.999786, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 8 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.069702, 1456.720336, 15.670296, -0.000007, -0.000014, 89.999832, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 7 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.659179, 1456.720336, 15.670296, -0.000007, -0.000014, 89.999832, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 7 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.669921, 1443.818115, 15.690292, 0.000000, -0.000014, 89.999809, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 7 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.669311, 1443.640625, 15.690292, 0.000007, -0.000014, 89.999786, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 8 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.669311, 1430.700683, 15.690292, 0.000007, -0.000014, 89.999786, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 8 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.310424, 1430.700683, 15.690292, 0.000007, -0.000014, 89.999786, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 8 (MinY)
  tmpobjid1 = CreateDynamicObject(18981, 1472.131591, 1440.647583, 20.720043, 0.000012, 90.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // penyangga lantai 3
  tmpobjid1 = CreateDynamicObject(18981, 1471.821166, 1440.727783, 14.860038, 0.000012, 90.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // penyangga lantai 2
  tmpobjid1 = CreateDynamicObject(18981, 1437.572998, 1443.608032, 14.890037, 0.000012, 90.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // penyangga lantai 2
  tmpobjid1 = CreateDynamicObject(18981, 1437.532836, 1443.608032, 20.670043, 0.000012, 90.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // penyangga lantai 3
  tmpobjid1 = CreateDynamicObject(18981, 1437.532836, 1444.228637, 26.490060, 0.000012, 90.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // penyangga lantai 4
  // tmpobjid1 = CreateDynamicObject(1215, 1459.102416, 1441.200317, 27.600305, -0.000007, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 14 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.102416, 1440.469604, 21.600288, -0.000012, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 10 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.102661, 1440.618652, 21.630289, -0.000003, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 9 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.003662, 1427.137207, 21.630283, -0.000014, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 10 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.366943, 1427.137207, 21.630283, -0.000014, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 10 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.375366, 1440.618652, 21.370290, -0.000000, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 9 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.374755, 1440.469604, 21.340290, -0.000009, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 10 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.344360, 1453.981323, 21.570293, -0.000007, -0.000014, -90.000183, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 9 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.034301, 1453.981323, 21.570293, -0.000007, -0.000014, -90.000183, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 9 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.102661, 1441.349365, 27.630306, 0.000000, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 13 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.003662, 1427.867919, 27.630300, -0.000009, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 14 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.366943, 1427.867919, 27.630300, -0.000009, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 14 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.375366, 1441.349365, 27.370307, 0.000003, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 13 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.374755, 1441.200317, 27.340307, -0.000003, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 14 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1489.344360, 1454.712036, 27.570310, -0.000000, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 13 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1459.034301, 1454.712036, 27.570310, -0.000000, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 13 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.118164, 1444.401977, 27.700307, -0.000003, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 16 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.118408, 1444.551025, 27.730308, 0.000003, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 15 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.019409, 1431.069580, 27.730302, -0.000007, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 16 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.382690, 1431.069580, 27.730302, -0.000007, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 16 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.391113, 1444.551025, 27.470310, 0.000004, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 15 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.390502, 1444.401977, 27.440309, -0.000001, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 16 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.360107, 1457.913696, 27.670312, 0.000000, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 15 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.050048, 1457.913696, 27.670312, 0.000000, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 15 (MaxY)
  tmpobjid1 = CreateDynamicObject(3785, 1457.480957, 1461.133300, 12.600313, 0.000000, 0.000000, 0.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(1893, 1440.783935, 1460.556274, 13.840321, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); 
  // tmpobjid1 = CreateDynamicObject(1215, 1420.092651, 1443.682495, 21.990293, -0.000009, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 12 (MaxY)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.092895, 1443.831542, 22.020294, -0.000000, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 11 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1419.993896, 1430.350097, 22.020288, -0.000012, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 12 (MinX)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.357177, 1430.350097, 22.020288, -0.000012, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 12 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.365600, 1443.831542, 21.760295, 0.000000, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 11 (MinY)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.364990, 1443.682495, 21.730295, -0.000007, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 12 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1450.334594, 1457.194213, 21.960298, -0.000003, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 11 (MaxX)
  // tmpobjid1 = CreateDynamicObject(1215, 1420.024536, 1457.194213, 21.960298, -0.000003, -0.000014, -90.000160, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00); // Room 11 (MaxY)
  tmpobjid1 = CreateDynamicObject(1893, 1448.774291, 1460.556274, 13.840321, 0.000000, 0.000000, 90.000000, -1, FLAT_MEDIUM_INTERIOR, -1, 50.00, 50.00);

  // Flat Low
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1563.830322, 9.450303, 90.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1573.818969, 9.450303, 90.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1583.808593, 9.450303, 90.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1593.808105, 9.450303, 90.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1434.723144, 1558.925903, 11.680314, 0.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19443, 1436.382934, 1558.925903, 11.680314, 0.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19443, 1432.992431, 1558.925903, 11.680314, 0.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1432.272338, 1560.615966, 11.680314, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1432.272338, 1563.825683, 11.680314, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1432.272338, 1570.247436, 11.680314, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1432.272338, 1576.667114, 11.680314, 0.000000, 0.000014, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1432.272338, 1579.877075, 11.680314, 0.000000, 0.000014, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1432.272338, 1586.298828, 11.680314, 0.000000, 0.000014, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1432.272338, 1592.709716, 11.680314, 0.000000, 0.000022, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1432.272338, 1595.919433, 11.680314, 0.000000, 0.000022, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1432.272338, 1602.341186, 11.680314, 0.000000, 0.000022, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1603.807495, 9.450303, 90.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1437.083862, 1560.615966, 11.680314, 0.000000, 0.000014, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1437.083862, 1563.825683, 11.680314, 0.000000, 0.000014, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1437.083862, 1570.247436, 11.680314, 0.000000, 0.000014, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1437.083862, 1576.647705, 11.680314, 0.000000, 0.000029, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1437.083862, 1579.857421, 11.680314, 0.000000, 0.000029, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1437.083862, 1586.279174, 11.680314, 0.000000, 0.000029, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1437.083862, 1592.709716, 11.680314, 0.000000, 0.000045, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1437.083862, 1595.919433, 11.680314, 0.000000, 0.000045, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1437.083862, 1602.341186, 11.680314, 0.000000, 0.000045, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1434.723144, 1607.246948, 11.680314, 0.000014, 0.000000, 89.999954, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19443, 1436.382934, 1607.246948, 11.680314, 0.000014, 0.000000, 89.999954, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19443, 1432.992431, 1607.246948, 11.680314, 0.000014, 0.000000, 89.999954, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1563.789916, 13.760335, 89.999992, 179.999984, -89.999969, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1573.778564, 13.760335, 89.999992, 179.999984, -89.999969, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1583.768188, 13.760335, 89.999992, 179.999984, -89.999969, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1583.768188, 13.760335, 89.999992, 179.999984, -89.999969, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1593.767700, 13.760335, 89.999992, 179.999984, -89.999969, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1603.767089, 13.760335, 89.999992, 179.999984, -89.999969, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(1569, 1434.633056, 1558.995971, 9.930302, 0.000000, -0.000007, 179.999954, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16093, "a51_ext", "des_backdoor1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(1569, 1434.613769, 1558.995971, 9.930302, 0.000000, 0.000007, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 16093, "a51_ext", "des_backdoor1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1434.024414, 1612.318725, 9.210313, 90.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 18065, "ab_sfammumain", "gun_floor1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1433.374267, 1612.328735, 9.210313, 90.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 18065, "ab_sfammumain", "gun_floor1", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1564.522949, 15.255341, 89.999992, 179.999984, -90.000007, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1574.511596, 15.255341, 89.999992, 179.999984, -90.000007, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1584.501220, 15.255341, 89.999992, 179.999984, -90.000007, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1594.500732, 15.255341, 89.999992, 179.999984, -90.000007, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1434.723144, 1559.618530, 17.485345, 0.000007, 0.000000, 89.999977, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19443, 1436.382934, 1559.618530, 17.485345, 0.000007, 0.000000, 89.999977, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19443, 1432.992431, 1559.618530, 17.485345, 0.000007, 0.000000, 89.999977, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1432.272338, 1561.308593, 17.485345, 0.000000, 0.000007, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1432.272338, 1564.518310, 17.485345, 0.000000, 0.000007, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1432.272338, 1570.940063, 17.485345, 0.000000, 0.000007, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1432.272338, 1577.359741, 17.485345, 0.000000, 0.000022, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1432.272338, 1580.569702, 17.485345, 0.000000, 0.000022, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1432.272338, 1586.991455, 17.485345, 0.000000, 0.000022, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1432.272338, 1593.402343, 17.485345, 0.000000, 0.000029, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1432.272338, 1596.612060, 17.485345, 0.000000, 0.000029, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1432.272338, 1603.033813, 17.485345, 0.000000, 0.000029, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1604.500122, 15.255341, 89.999992, 179.999984, -90.000007, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 10041, "archybuild10", "Upt_Conc floorClean", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1437.083862, 1561.308593, 17.485345, 0.000000, 0.000022, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1437.083862, 1564.518310, 17.485345, 0.000000, 0.000022, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1437.083862, 1570.940063, 17.485345, 0.000000, 0.000022, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1437.083862, 1577.340332, 17.485345, 0.000000, 0.000037, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1437.083862, 1580.550048, 17.485345, 0.000000, 0.000037, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1437.083862, 1586.971801, 17.485345, 0.000000, 0.000037, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19370, 1437.083862, 1593.402343, 17.485345, 0.000000, 0.000051, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1437.083862, 1596.612060, 17.485345, 0.000000, 0.000051, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19462, 1437.083862, 1603.033813, 17.485345, 0.000000, 0.000051, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19387, 1434.723144, 1607.939575, 17.485345, 0.000022, 0.000000, 89.999931, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19443, 1436.382934, 1607.939575, 17.485345, 0.000022, 0.000000, 89.999931, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(19443, 1432.992431, 1607.939575, 17.485345, 0.000022, 0.000000, 89.999931, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 17079, "cuntwland", "ws_tunnelwall2", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1563.731811, 19.565370, 89.999992, 180.000015, -89.999961, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1573.720458, 19.565370, 89.999992, 180.000015, -89.999961, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1583.710083, 19.565370, 89.999992, 180.000015, -89.999961, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1593.709594, 19.565370, 89.999992, 180.000015, -89.999961, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(18766, 1434.682739, 1603.708984, 19.565370, 89.999992, 180.000015, -89.999961, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterial(tmpobjid1, 0, 3967, "cj_airprt", "ceiling_256", 0x00000000);
  tmpobjid1 = CreateDynamicObject(14596, 1438.465332, 1613.603515, 9.050294, 0.000000, 0.000000, 90.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(18981, 1433.833740, 1595.965820, 15.003039, 0.000007, 90.000000, 89.999977, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(18981, 1433.833740, 1570.966918, 15.003039, 0.000007, 90.000000, 89.999977, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  tmpobjid1 = CreateDynamicObject(950, 1434.499145, 1559.921508, 16.285345, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2001, 1433.542114, 1607.367919, 15.735339, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2270, 1434.539184, 1560.211914, 17.565353, 0.000000, 0.000000, 180.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2272, 1435.740112, 1560.221679, 16.935350, 0.000000, 0.000000, 180.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2278, 1433.280151, 1560.201660, 18.135349, 0.000000, 0.000000, 180.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2001, 1433.411987, 1606.677978, 9.915334, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(11706, 1436.513305, 1559.291137, 9.950303, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2840, 1436.464965, 1559.775878, 9.950308, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1264, 1432.826171, 1559.639282, 10.230305, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1442, 1436.230834, 1606.646118, 10.510304, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2672, 1436.030883, 1606.066772, 10.230309, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1264, 1432.826171, 1560.519165, 10.230305, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(1442, 1436.230834, 1607.286499, 16.320306, 0.000000, 0.000007, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(2672, 1436.030883, 1606.707153, 16.040311, 0.000000, 0.000007, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00);
  tmpobjid1 = CreateDynamicObject(11710, 1435.915283, 1607.170776, 11.430299, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterialText(tmpobjid1, 0, "\n\n       1st Floor", 90, "Segoe Keycaps", 40, 0, 0xFFFFFFFF, 0xFF000000, 0);
  tmpobjid1 = CreateDynamicObject(11710, 1435.915283, 1607.871459, 17.180301, 0.000000, 0.000000, 0.000000, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); 
  SetDynamicObjectMaterialText(tmpobjid1, 0, "\n\n       2nd Floor", 90, "Segoe Keycaps", 40, 0, 0xFFFFFFFF, 0xFF000000, 0);
  // tmpobjid1 = CreateDynamicObject(3666, 1418.793334, 1558.107299, 10.290301, 0.000022, 0.000014, 89.999931, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 1 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.053466, 1558.107299, 10.290301, 0.000022, 0.000014, 89.999931, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 1 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.184082, 1574.968627, 10.410314, 0.000014, 0.000014, 89.999954, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 1 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.184082, 1574.992919, 10.410314, 0.000037, 0.000014, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 2 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.763061, 1574.968627, 10.300309, 0.000014, 0.000014, 89.999954, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 1 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.773193, 1574.992919, 10.300308, 0.000037, 0.000014, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 2 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.123779, 1591.024291, 10.430307, 0.000029, 0.000014, 89.999908, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 2 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.813598, 1591.024291, 10.340313, 0.000029, 0.000014, 89.999908, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 2 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.124755, 1591.027709, 10.380311, 0.000044, 0.000014, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 3 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.073486, 1607.979980, 10.430312, 0.000037, 0.000014, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 3 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.643066, 1607.819335, 10.290312, 0.000037, 0.000014, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 3 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.811889, 1591.027709, 10.370308, 0.000044, 0.000014, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 3 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.334106, 1558.107299, 10.290301, 0.000029, 0.000015, 89.999908, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 4 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.594238, 1558.107299, 10.290301, 0.000029, 0.000015, 89.999908, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 4 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.724853, 1574.968627, 10.410314, 0.000022, 0.000015, 89.999931, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 4 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.724853, 1574.992919, 10.410314, 0.000044, 0.000015, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 5 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.303833, 1574.968627, 10.300309, 0.000022, 0.000015, 89.999931, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 4 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.313964, 1574.992919, 10.300308, 0.000044, 0.000015, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 5 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.664550, 1591.024291, 10.430307, 0.000037, 0.000015, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 5 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.354370, 1591.024291, 10.340313, 0.000037, 0.000015, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 5 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.665527, 1591.027709, 10.380311, 0.000051, 0.000015, 89.999839, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 6 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.614257, 1607.979980, 10.430312, 0.000044, 0.000015, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 6 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.183837, 1607.819335, 10.290312, 0.000044, 0.000015, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 6 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.352661, 1591.027709, 10.370308, 0.000051, 0.000015, 89.999839, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 6 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.793334, 1558.797973, 16.110311, 0.000037, 0.000015, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 7 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.053466, 1558.797973, 16.110311, 0.000037, 0.000015, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 7 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.184082, 1575.659301, 16.230323, 0.000030, 0.000015, 89.999908, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 7 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.184082, 1575.683593, 16.230323, 0.000052, 0.000015, 89.999839, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 8 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.763061, 1575.659301, 16.120319, 0.000030, 0.000015, 89.999908, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 7 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.773193, 1575.683593, 16.120319, 0.000052, 0.000015, 89.999839, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 8 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.123779, 1591.714965, 16.250316, 0.000045, 0.000015, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 8 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.813598, 1591.714965, 16.160324, 0.000045, 0.000015, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 8 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.124755, 1591.718383, 16.200321, 0.000059, 0.000015, 89.999816, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 9 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1433.073486, 1608.670654, 16.250322, 0.000052, 0.000015, 89.999839, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 9 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.643066, 1608.510009, 16.110322, 0.000052, 0.000015, 89.999839, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 9 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1418.811889, 1591.718383, 16.190319, 0.000059, 0.000015, 89.999816, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 9 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.463989, 1558.797973, 16.110311, 0.000044, 0.000015, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 10 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.724121, 1558.797973, 16.110311, 0.000044, 0.000015, 89.999862, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 10 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.854736, 1575.659301, 16.230323, 0.000037, 0.000015, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 10 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.854736, 1575.683593, 16.230323, 0.000059, 0.000015, 89.999816, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 11 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.433715, 1575.659301, 16.120319, 0.000037, 0.000015, 89.999885, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 10 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.443847, 1575.683593, 16.120319, 0.000059, 0.000015, 89.999816, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 11 (MinX)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.794433, 1591.714965, 16.250316, 0.000052, 0.000015, 89.999839, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 11 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.484252, 1591.714965, 16.160324, 0.000052, 0.000015, 89.999839, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 11 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.795410, 1591.718383, 16.200321, 0.000066, 0.000015, 89.999794, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 12 (MinY)
  // tmpobjid1 = CreateDynamicObject(3666, 1450.744140, 1608.670654, 16.250322, 0.000059, 0.000015, 89.999816, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 12 (MaxX)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.313720, 1608.510009, 16.110322, 0.000059, 0.000015, 89.999816, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 12 (MaxY)
  // tmpobjid1 = CreateDynamicObject(3666, 1436.482543, 1591.718383, 16.190319, 0.000066, 0.000015, 89.999794, -1, FLAT_LOW_INTERIOR, -1, 50.00, 50.00); // Room 12 (MinX)

  return 1;
}
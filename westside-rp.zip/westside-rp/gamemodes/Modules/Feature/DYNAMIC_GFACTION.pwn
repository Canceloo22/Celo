#define MAX_GFACTION 10

enum gfactioninfo
{
    gfType,
    Float:Fx,
    Float:Fy,
    Float:Fz,
    Text3D:gflabel,
    gfpickup,
    gfint
}:
new gfactiondata[MAX_GFACTION][gfactioninfo]
    Iterator: Garagefaction<MAX_GFACTION>;

Gfaction_Refres(gfid)
{
    if(gid != -1)
    {
        if(IsValidDynamic3DTextLabel(gfactiondata[gfid][gflabel]))
            DestroyDynamic3DTextLabel(gfactiondata[gfid][gflabel]);
        
        if(IsValidDynamicPickup(gfactiondata[gfid][gfpickup]))
            DestroyDynamicPickup(gfactiondata[gfid][gfpickup]);
        
        static 
        string[256];

        new type[128];
        if(gfactiondata[gfid][gfType] == 1)
        {
            type= "LSPD";
        }
        else if(gfactiondata[gfid][gfType] == 2)
        {
            type= "SAMD";
        }
        else if(gfactiondata[gfid][gfType] == 3)
        {
            type= "SAGS";
        }
        else if(gfactiondata[gfid][gfType] == 4)
        {
            type= "SANA";
        }
        else
        {
            type= "Unknow";
        }

        format(string, sizeof(string), "[%d]\n"WHITE_E"Faction : %s\n/spawncarfaction to spawn vehicle garage faction", gfid, gfType);
        gfactiondata[gfid][gfpickup] = CreateDynamicPickup(19197, 23, gfactiondata[gfid][Fx], gfactiondata[gfid][Fy], gfactiondata[gfid][Fz]+0.2, 0, gfactiondata[gfid][gfInt], playerid = -1, Float:streamdistance = STREAMER_PICKUP_SD, STREAMER_TAG_AREA areaid = STREAMER_TAG_AREA -1, priority =0)
    }
}
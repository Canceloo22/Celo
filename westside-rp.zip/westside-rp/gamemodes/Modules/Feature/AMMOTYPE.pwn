new PlayerText:WeaponTD[MAX_PLAYERS][3];
new PlayerText:TypeAmmo[MAX_PLAYERS];
new PlayerText:JumlahAmmo[MAX_PLAYERS];

CreateWeaponAmmoTextdraw(playerid)
{
    WeaponTD[playerid][0] = CreatePlayerTextDraw(playerid, 579.000000, 102.000000, "_");
	PlayerTextDrawFont(playerid, WeaponTD[playerid][0], 1);
	PlayerTextDrawLetterSize(playerid, WeaponTD[playerid][0], 0.704166, 3.800000);
	PlayerTextDrawTextSize(playerid, WeaponTD[playerid][0], 298.500000, 77.000000);
	PlayerTextDrawSetOutline(playerid, WeaponTD[playerid][0], 1);
	PlayerTextDrawSetShadow(playerid, WeaponTD[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, WeaponTD[playerid][0], 2);
	PlayerTextDrawColor(playerid, WeaponTD[playerid][0], -1);
	PlayerTextDrawBackgroundColor(playerid, WeaponTD[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, WeaponTD[playerid][0], 135);
	PlayerTextDrawUseBox(playerid, WeaponTD[playerid][0], 1);
	PlayerTextDrawSetProportional(playerid, WeaponTD[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, WeaponTD[playerid][0], 0);

	WeaponTD[playerid][1] = CreatePlayerTextDraw(playerid, 542.000000, 101.000000, "Type:");
	PlayerTextDrawFont(playerid, WeaponTD[playerid][1], 1);
	PlayerTextDrawLetterSize(playerid, WeaponTD[playerid][1], 0.341666, 1.449999);
	PlayerTextDrawTextSize(playerid, WeaponTD[playerid][1], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, WeaponTD[playerid][1], 1);
	PlayerTextDrawSetShadow(playerid, WeaponTD[playerid][1], 0);
	PlayerTextDrawAlignment(playerid, WeaponTD[playerid][1], 1);
	PlayerTextDrawColor(playerid, WeaponTD[playerid][1], -1);
	PlayerTextDrawBackgroundColor(playerid, WeaponTD[playerid][1], 255);
	PlayerTextDrawBoxColor(playerid, WeaponTD[playerid][1], 50);
	PlayerTextDrawUseBox(playerid, WeaponTD[playerid][1], 0);
	PlayerTextDrawSetProportional(playerid, WeaponTD[playerid][1], 1);
	PlayerTextDrawSetSelectable(playerid, WeaponTD[playerid][1], 0);

	TypeAmmo[playerid] = CreatePlayerTextDraw(playerid, 575.000000, 101.000000, "Normal");
	PlayerTextDrawFont(playerid, TypeAmmo[playerid], 1);
	PlayerTextDrawLetterSize(playerid, TypeAmmo[playerid], 0.341666, 1.449999);
	PlayerTextDrawTextSize(playerid, TypeAmmo[playerid], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, TypeAmmo[playerid], 1);
	PlayerTextDrawSetShadow(playerid, TypeAmmo[playerid], 0);
	PlayerTextDrawAlignment(playerid, TypeAmmo[playerid], 1);
	PlayerTextDrawColor(playerid, TypeAmmo[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, TypeAmmo[playerid], 255);
	PlayerTextDrawBoxColor(playerid, TypeAmmo[playerid], 50);
	PlayerTextDrawUseBox(playerid, TypeAmmo[playerid], 0);
	PlayerTextDrawSetProportional(playerid, TypeAmmo[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, TypeAmmo[playerid], 0);

	WeaponTD[playerid][2] = CreatePlayerTextDraw(playerid, 542.000000, 120.000000, "Ammo:");
	PlayerTextDrawFont(playerid, WeaponTD[playerid][2], 1);
	PlayerTextDrawLetterSize(playerid, WeaponTD[playerid][2], 0.341666, 1.449999);
	PlayerTextDrawTextSize(playerid, WeaponTD[playerid][2], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, WeaponTD[playerid][2], 1);
	PlayerTextDrawSetShadow(playerid, WeaponTD[playerid][2], 0);
	PlayerTextDrawAlignment(playerid, WeaponTD[playerid][2], 1);
	PlayerTextDrawColor(playerid, WeaponTD[playerid][2], -1);
	PlayerTextDrawBackgroundColor(playerid, WeaponTD[playerid][2], 255);
	PlayerTextDrawBoxColor(playerid, WeaponTD[playerid][2], 50);
	PlayerTextDrawUseBox(playerid, WeaponTD[playerid][2], 0);
	PlayerTextDrawSetProportional(playerid, WeaponTD[playerid][2], 1);
	PlayerTextDrawSetSelectable(playerid, WeaponTD[playerid][2], 0);

	JumlahAmmo[playerid] = CreatePlayerTextDraw(playerid, 585.000000, 120.000000, "900");
	PlayerTextDrawFont(playerid, JumlahAmmo[playerid], 1);
	PlayerTextDrawLetterSize(playerid, JumlahAmmo[playerid], 0.341666, 1.449999);
	PlayerTextDrawTextSize(playerid, JumlahAmmo[playerid], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, JumlahAmmo[playerid], 1);
	PlayerTextDrawSetShadow(playerid, JumlahAmmo[playerid], 0);
	PlayerTextDrawAlignment(playerid, JumlahAmmo[playerid], 1);
	PlayerTextDrawColor(playerid, JumlahAmmo[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, JumlahAmmo[playerid], 255);
	PlayerTextDrawBoxColor(playerid, JumlahAmmo[playerid], 50);
	PlayerTextDrawUseBox(playerid, JumlahAmmo[playerid], 0);
	PlayerTextDrawSetProportional(playerid, JumlahAmmo[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, JumlahAmmo[playerid], 0);
}